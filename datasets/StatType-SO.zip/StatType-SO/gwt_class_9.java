package shell_structure;
//ID = 1624218
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.ui.MenuBar;
import com.google.gwt.user.client.ui.VerticalPanel;

public class gwt_class_9 {
	VerticalPanel v1 = new VerticalPanel();
	 Command comm = new Command() {
	  @Override
	  public void execute() {
	                       // How i know that which menu item is cliked
	  }
	 };

	 MenuBar menu = new MenuBar();
	 MenuBar fileBar = new MenuBar(true);
	 MenuBar editBar = new MenuBar(true);
}
