package shell_structure;
//ID = 6810856
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public class xstream_class_7 {
    @XStreamAsAttribute
    private String type;
    private String value;

    public xstream_class_7(String type, String value) {
        this.type = type;
        this.value = value;
    }
    // getters omitted 
}