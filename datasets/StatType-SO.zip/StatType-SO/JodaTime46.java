package jodatime;
//id=16461361
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

public class JodaTime46 {

	public static void main(String[] args) {
		DateTimeZone date = null;
		// TODO Auto-generated method stub
		DateTime dateTime = new DateTime(date);
		dateTime = dateTime.plusDays(1);
	}
}
