package shell_structure;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.Optional;

public class FindJsonKey {
    public static final String JSON = "{\n" +
            "  \"test1\": {\n" +
            "    \"test2\": {\n" +
            "      \"test3\": {\n" +
            "        \"key\": \"value\"\n" +
            "      },\n" +
            "      \"somefields12\": \"some value2\"\n" +
            "    },\n" +
            "    \"somefields\": \"some value\"\n" +
            "  }\n" +
            "}";

    public static void main(String[] args) {

        Gson gson = new GsonBuilder().create();
        JsonObject jsonObject = gson.fromJson(JSON, JsonObject.class);

        Optional
                .ofNullable(jsonObject.getAsJsonObject("test1"))
                .map(test1 -> test1.getAsJsonObject("test2"))
                .map(test2 -> test2.getAsJsonObject("test3"))
                .map(test3 -> test3.get("key"))
                .map(JsonElement::getAsString)
                .ifPresent(key -> {
                    // Do something with key..
                });
    }
}