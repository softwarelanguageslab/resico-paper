package shell_structure;

import org.junit.Assert;

public class ClassShell {

    public static void main(String[] args) {
        Assert.assertEquals("...");
    }
}
