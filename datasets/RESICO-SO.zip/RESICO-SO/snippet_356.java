package com.gxet4n.jfreechart;

import java.io.File;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

public class PieChart_HQL {

    public static void main( String[ ] args )throws Exception {

        DefaultPieDataset dataset = new DefaultPieDataset( );
        DefaultCategoryDataset dataset2 = new DefaultCategoryDataset();
        try {

            SessionFactory sessionFactory = new Configuration().configure().addAnnotatedClass(Mobile_tbl.class).buildSessionFactory();
            Session session = sessionFactory.openSession();
            session.beginTransaction();

            Query<?> query = session.createQuery("FROM Mobile_tbl");
            List<Mobile_tbl> mobiles = (List<Mobile_tbl>)query.list();

            session.close();


            for (Mobile_tbl m : mobiles) {
                dataset.setValue(m.getMobile_brand(), m.getUnit_sale());
            }

            for (Mobile_tbl m : mobiles) {
                dataset2.setValue(m.getUnit_sale(),m.getMobile_brand(),"");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage()); 
        }

        JFreeChart chart = ChartFactory.createPieChart(
                    "Mobile Sales",   // chart title           
                    dataset,          // data           
                    true,             // include legend          
                    true,           
                    false );
        JFreeChart barChart = ChartFactory.createBarChart(
                    "Mobiles Sales",           
                    "Mobile Brand",            
                    "Unit Sale",            
                    dataset2,          
                    PlotOrientation.VERTICAL,           
                    true, true, false);

        int width = 560;    /* Width of the image */
        int height = 370;   /* Height of the image */ 
        File pieChart = new File( "Pie_Chart_HQL.png" );
        ChartUtils.saveChartAsPNG(pieChart, chart, width, height);
        File barchart = new File( "Bar_Chart_HQL.png" );
        ChartUtils.saveChartAsPNG(barchart, barChart, width, height);
    }
}