package shell_structure;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;

public class ClassShell {
  public static void main(String[] args) {
    List<ObjectType1> list1;
    List<ObjectType2> list2;
    Collection<Long> list1field1 = 
    Collections2.transform(list1, 
                            new Function<ObjectType1, Long>() {
                              public Long apply(ObjectType1 input) {
                                return (null == input) ? null : input.field1;
                              }
                            });
    Collection<Long> list2field1 = 
      Collections2.transform(list2, ...);

    // list1.retainAll(list2) based on field1 equivalence
    list1field1.retainAll(list2field1); // this affects the underlying list, ie list1.
  }
}
