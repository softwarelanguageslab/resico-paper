package shell_structure;

import org.joda.time.Days;


public class ClassShell {
    public static void main(String[] args) {

        LocalDate startDate;
        LocalDate endDate;
        // The difference would be exclusive of both dates, 
        // so in most of use cases we may need to increment it by 1
        Days.daysBetween(startDate, endDate).days();
    }
}
