package shell_structure;

import com.google.common.io.BaseEncoding;

public class ClassShell {
    public static void main(String[] args) {
        byte[] CDRIVES = BaseEncoding.base16().lowerCase().decode("E04FD020ea3a6910a2d808002b30309d".toLowerCase());
    }
}
