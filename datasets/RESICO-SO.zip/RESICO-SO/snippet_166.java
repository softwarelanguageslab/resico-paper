package shell_structure;
import org.apache.commons.lang3.text.WordUtils;

public class Main {

    public static void main(String[] args) {

        final String str1 = "HELLO WORLD";
        System.out.println(capitalizeFirstLetter(str1)); // output: Hello World

        final String str2 = "Hello WORLD";
        System.out.println(capitalizeFirstLetter(str2)); // output: Hello World

        final String str3 = "hello world";
        System.out.println(capitalizeFirstLetter(str3)); // output: Hello World

        final String str4 = "heLLo wORld";
        System.out.println(capitalizeFirstLetter(str4)); // output: Hello World
    }

    private static String capitalizeFirstLetter(String str) {
        return WordUtils.capitalizeFully(str);
    }
}