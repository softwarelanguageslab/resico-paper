package shell_structure;

import android.net.Uri;

public class ClassShell {
    public static void main(String[] args) {
        Uri uri = Uri.parse("http://example.com/foo/bar/42?param=true");
        String token = uri.getLastPathSegment();
    }
}
