package shell_structure;
import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomListView extends BaseAdapter { 

    private Activity activity;
    private ArrayList<HashMap<String, String>> data;
    private static LayoutInflater inflater=null; 

    public CustomListView(Activity a, ArrayList<HashMap<String, String>> d) {
        activity = a;
        data=d;
        inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi=convertView;
        if(convertView==null)
            vi = inflater.inflate(R.layout.custom_list_view, null);

            this.textView_team1_name = vi.findViewById(R.id.textView_team1_name);
            this.textView_team2_name = vi.findViewById(R.id.textView_team2_name);
            this.textView_team1_points = vi.findViewById(R.id.textView_team1_points);
            this.textView_team2_points = vi.findViewById(R.id.textView_team2_points);
            this.textView_arrow = vi.findViewById(R.id.textView_arrow);
            this.textView_read_points = vi.findViewById(R.id.textView_read_points);

        HashMap<String, String> singeldata = new HashMap<String, String>();
        singeldata = data.get(position);

        // Setting all values in listview
        textView_team1_name.setText(singeldata.get("team1_name"));
        textView_team2_name.setText(singeldata.get("team2_name"));
        textView_team1_points.setText(singeldata.get("team1_points"));
        textView_team2_points.setText(singeldata.get("team2_points"));
        textView_read_points.setText(singeldata.get("read_points"));
        textView_arrow.setText(singeldata.get("arrow"));
        return vi;
    }
}