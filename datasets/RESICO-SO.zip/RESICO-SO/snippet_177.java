package shell_structure;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

public class FilterApp {

    public static void main(String[] args) {
        // Define your filter
        String[] filterArray = new String[]{"FWORD"};
        // Build a Map with replacements
        Map<String,String> filterMap = new HashMap<>();
        for( String f: filterArray){
            String replacement = f.charAt(0)+StringUtils.leftPad("*", (f.length()-2), '*')+f.charAt(f.length()-1);
            // (?i) means 'CASE_INSENSITIVE' and \\b means 'word boundry'
            filterMap.put("(?i)\\b"+f+"\\b", replacement);
        }
        // Let's do it....
        String result = "This is example message with bad words like FWORD";
        for (Map.Entry<String, String> filter : filterMap.entrySet()) {
            result = result.replaceAll(filter.getKey(), filter.getValue());
        }
        // .. and here is the result
        System.out.println(result);
    }
}