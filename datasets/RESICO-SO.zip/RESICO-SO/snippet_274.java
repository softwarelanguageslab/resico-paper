package shell_structure;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

 public class DateSorter implements Comparator {
     public int compare(Object firstObjToCompare, Object secondObjToCompare) {
        String firstDateString = ((HashMap<String, String>) firstObjToCompare).get("timestamp");
        String secondDateString = ((HashMap<String, String>) secondObjToCompare).get("timestamp");

        if (secondDateString == null || firstDateString == null) {
            return 0;
        }

        // Convert to Dates
        DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
        DateTime firstDate = dtf.parseDateTime(firstDateString);
        DateTime secondDate = dtf.parseDateTime(secondDateString);

        if (firstDate.isAfter(secondDate)) return -1;
        else if (firstDate.isBefore(secondDate)) return 1;
        else return 0;
    }
}