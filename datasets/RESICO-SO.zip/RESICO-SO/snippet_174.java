package shell_structure;

import org.apache.commons.lang3.exception.ExceptionUtils;

public class ClassShell {
    public static void main(String[] args) {
        log.error("Exception : "+ExceptionUtils.getStackTrace(exception));
    }
}
