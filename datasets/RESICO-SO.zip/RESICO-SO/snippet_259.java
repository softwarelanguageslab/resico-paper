package shell_structure;
import com.google.gson.Gson;

class Person {
  private int age = 10;
  private String name = "jigar";
}

public class Main {
  public static void main(String[] args) {
    Person obj = new Person();
    Gson gson = new Gson();
    String json = gson.toJson(obj);
  }
}