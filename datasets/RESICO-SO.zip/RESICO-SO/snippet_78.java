package shell_structure;

import org.springframework.util.StringUtils;

public class ClassShell {
    public static void main(String[] args) {
        StringUtils.countOccurrencesOf(result, "R-");
    }
}
