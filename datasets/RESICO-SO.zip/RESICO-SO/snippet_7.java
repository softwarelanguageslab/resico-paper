package shell_structure;

import org.apache.commons.lang3.StringUtils;


public class ClassShell {

    public String splitURL(String url, String parameter){
        HashMap<String, String> urlMap=new HashMap<String, String>();
        String queryString=StringUtils.substringAfter(url,"?");
        for(String param : queryString.split("&")){
            urlMap.put(StringUtils.substringBefore(param, "="),StringUtils.substringAfter(param, "="));
        }
        return urlMap.get(parameter);
    }
}
