package shell_structure;

import java.util.List;
import org.apache.commons.lang.ArrayUtils;
import com.google.common.base.Functions;
import com.google.common.collect.Lists;
import com.google.common.primitives.Chars;


public class ClassShell {
    public static String[] singleChars(String s) {
        return Lists.transform(Chars.asList(s.toCharArray()),Functions.toStringFunction()).toArray(ArrayUtils.EMPTY_STRING_ARRAY);
    }
}
