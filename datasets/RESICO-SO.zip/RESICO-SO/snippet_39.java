package com.stevej;

import com.google.common.base.CharMatcher;
import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;

public class StackOverflowMain {

  public static void main(String[] args) {

    Splitter extractParams = Splitter.on("rgb").omitEmptyStrings().trimResults();

    Splitter splitParams =
        Splitter.on(CharMatcher.anyOf("(),").or(CharMatcher.WHITESPACE)).omitEmptyStrings()
            .trimResults();

    final String test1 = "rgb(11,44,88)";

    System.out.println("test1");
    for (String param : splitParams.split(Iterables.getOnlyElement(extractParams.split(test1)))) {
      System.out.println("param: [" + param + "]");
    }

    final String test2 = "rgb      ( 111,         444         , 888         )";

    System.out.println("test2");
    for (String param : splitParams.split(Iterables.getOnlyElement(extractParams.split(test2)))) {
      System.out.println("param: [" + param + "]");
    }

  }
}