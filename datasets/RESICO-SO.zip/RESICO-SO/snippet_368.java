package shell_structure;

import org.springframework.web.reactive.function.server.RouterFunctions;

public class ClassShell {
    public static void main(String[] args) {
        RouterFunctions.route().GET().build();
    }
}
