package shell_structure;

import android.text.util.Linkify;

public class ClassShell {
    public static void main(String[] args) {
        Linkify.addLinks(text, Linkify.PHONE_NUMBERS);
    }
}
