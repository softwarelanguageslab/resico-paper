package shell_structure;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ClassShell {

    public static void main(String[] args) {
        JsonParser parser = new JsonParser();
        JsonObject rootObejct = parser.parse(json).getAsJsonObject();
        JsonElement dataElement = rootObejct.get("data");
        LoginResponse response = gson.fromJson(dataElement, LoginResponse.class);
    }
}
