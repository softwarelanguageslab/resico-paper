package shell_structure;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;

import ch.halarious.core.HalResource;
import ch.halarious.core.HalSerializer;
import ch.halarious.core.HalDeserializer;
import ch.halarious.core.HalExclusionStrategy;

public class EntityHalConverter <T> {

    private Gson gson;
    private GsonBuilder builder;

    private Class<T> paramType;


    /* HalConverter<ProgrammeData> halConverter = new HalConverter<>(ProgrammeData.class);
    */
    public EntityHalConverter(Class<T> paramType) {
        builder = new GsonBuilder();
        builder.setExclusionStrategies(new HalExclusionStrategy());
        this.paramType = paramType;
    }


    /* String jsonResult = halConverter.toJson( programmeData );
    */
    public String toJson( T result ) throws JsonParseException{

        builder.registerTypeAdapter(HalResource.class, new HalSerializer());
        gson = builder.create();
        return gson.toJson(result, HalResource.class);
    }


    /* ProgrammeData pcsProg = halConverter.convert( jsonString );
    */
    public T fromJson( String json ) throws JsonParseException {

        builder.registerTypeAdapter( HalResource.class, new HalDeserializer(paramType) );
        gson = builder.create();
        return (T)gson.fromJson( json, HalResource.class );
    }

}