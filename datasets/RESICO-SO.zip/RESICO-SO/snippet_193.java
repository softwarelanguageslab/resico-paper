package shell_structure;

import org.springframework.scheduling.support.CronTrigger;
import org.springframework.scheduling.support.SimpleTriggerContext;


public class ClassShell {
    public static void main(String[] args) {
        CronTrigger trigger = new CronTrigger("0 0 10 * * ?");
        SimpleTriggerContext triggerContext = new SimpleTriggerContext();
        Date testDate = new Date();
        int i = 0;
        while (i++ < 5) {
            triggerContext.update(null, null, testDate);
            testDate = trigger.nextExecutionTime(triggerContext);
            System.out.println(testDate);
        }
    }
}
