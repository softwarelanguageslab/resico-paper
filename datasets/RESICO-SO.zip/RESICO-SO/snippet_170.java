package com.example;

import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

public class LoadContacts {
    private static String yamlLocation="classpath:contacts.yaml";

    public static void main(String[] args) throws IOException {
        Yaml yaml = new Yaml(new Constructor(Collection.class));
        InputStream in = null;
        Collection<Contact> contacts;
        try {
            in = new FileInputStream(new File(yamlLocation));
            contacts = (Collection<Contact>) yaml.load(in);
        } catch (IOException e) {
                final DefaultResourceLoader loader = new DefaultResourceLoader();
                final Resource resource = loader.getResource(yamlLocation);
                in = resource.getInputStream();
                contacts = (Collection<Contact>) yaml.load(in);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    // no-op
                }
            }
        }
        for(Contact contact:contacts){
            System.out.println(contact.name + ":" + contact.address + ":" + contact.age );
        }
    }
}