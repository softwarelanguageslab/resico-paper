package shell_structure;

import com.google.common.base.Joiner;

public class ClassShell {
    public static void main(String[] args) {
        String delimiter = "";
        Joiner.on(delimiter).join(Lists.newArrayList("Your number is ", 47, "!"));
    }
}
