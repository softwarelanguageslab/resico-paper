package shell_structure;

import org.apache.commons.lang3.time.DateFormatUtils;


public class ClassShell {
    public String toDateString(Long date){
        return DateFormatUtils.format(date, "yyy-MM-dd HH:mm");
    }
}
