package shell_structure;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

public class StringToLocalDate {
    public static String DATE_FORMAT_INPUT = "ddMMyyyy";
    public static String DATE_FORMAT_OUTPUT = "yyyy-MM-dd";

    public static void main(String[] args) {
        System.out.println(formatted(convert("21022019")));
    }

    public static String formatted(LocalDate date) {
        return date.toString(DateTimeFormat.forPattern(DATE_FORMAT_OUTPUT));
    }

    public static LocalDate convert(String dateStr) {
        return LocalDate.parse(dateStr, DateTimeFormat.forPattern(DATE_FORMAT_INPUT));
    }
}