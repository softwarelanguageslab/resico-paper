package shell_structure;

import android.webkit.URLUtil;

public class ClassShell {

    public String getFileNameFromURL(String url) {
        String fileNameWithExtension = null;
        String fileNameWithoutExtension = null;
        if (URLUtil.isValidUrl(url)) {
            fileNameWithExtension = URLUtil.guessFileName(url, null, null);
            if (fileNameWithExtension != null && !fileNameWithExtension.isEmpty()) {
                String[] f = fileNameWithExtension.split(".");
                if (f != null & f.length > 1) {
                    fileNameWithoutExtension = f[0];
                }
            }
        }
        return fileNameWithoutExtension;
    }
}
