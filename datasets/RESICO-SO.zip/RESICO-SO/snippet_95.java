package shell_structure;

import org.apache.commons.lang3.StringUtils;

public class ClassShell {
    public static void main(String[] args) {
        String stringToPad = "10";
        int maxPadLength = 10;
        String paddingCharacter = " ";

        StringUtils.leftPad(stringToPad, maxPadLength, paddingCharacter);
    }
}
