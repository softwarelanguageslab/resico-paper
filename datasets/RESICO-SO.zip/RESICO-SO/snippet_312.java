package shell_structure;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import com.google.gson.Gson;

public class Test {

    public static void main(String[] args) throws IOException {
        Gson gson = new Gson();
        BufferedReader br = new BufferedReader(new FileReader("json.json"));
        StringBuffer res1 = new StringBuffer();

        String currLine = "";
        while((currLine = br.readLine())!=null) {
            res1.append(currLine); 
        }

        Deck res2 = gson.fromJson(res1.toString(), Deck.class);
        System.out.println(res2);
    }
}