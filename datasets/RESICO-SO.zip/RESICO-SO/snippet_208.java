package shell_structure;

import org.json.JSONObject;
import org.json.XML;
import com.google.gson.Gson;


public class ClassShell {

    public static void main(String[] args) {
        MyObject myObj = new MyObject();
        ArrayList<AnotherObject2> smsList = new ArrayList<AnotherObject2>();
        ArrayList<AnotherObject1> data = new ArrayList<AnotherObject1>();
        AnotherObject1 ao1 = new AnotherObject1();
        ao1.setGroup_id(39545922);
        ao1.setSmsList(smsList);
        
        AnotherObject2 sms = new AnotherObject2();
        sms.setCountry("XYZ");
        sms.setCustomid("39545922-1");
        sms.setCustomid1("");
        sms.setMobile((long) 913456789);
        sms.setStatus("XYZ");
        smsList.add(sms);
        ao1.setSmsList(smsList);
        data.add(ao1);
        myObj.setStatus("OK");
        myObj.setData(data);
        
        // Build a JSON string to display
        Gson gson = new Gson();
        String jsonString = gson.toJson(myObj);
        System.out.println(jsonString);
        
        // Get an object from a JSON string
        MyObject myObject2 = gson.fromJson(jsonString, MyObject.class);
        
        // Display the new object
        System.out.println(gson.toJson(myObject2));
    }
}
