package shell_structure;

import com.google.gwt.core.server.StackTraceDeobfuscator;
import com.google.gwt.user.client.rpc.RpcRequestBuilder;

public class ClassShell {
    public static void main(String[] args) {

        String path = getServletConfig().getServletContext().getRealPath("/WEB-INF/deploy/<your module name>/symbolMaps/");
        StackTraceDeobfuscator deobfuscator = StackTraceDeobfuscator.fromFileSystem(path);
        String strongName = getThreadLocalRequest().getHeader(RpcRequestBuilder.STRONG_NAME_HEADER);

        // Do the magic
        deobfuscator.deobfuscateStackTrace(exception, strongName);

        // Log it
        logger.severe("Uncaught GWT exception", exception);
    }
}
