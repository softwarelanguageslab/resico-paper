package shell_structure;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;

import java.util.Random;

public class StackOverflow45044823 {

  public static void populateField(final char[][] field) {
    Validate.noNullElements(field);
    final Random random = new Random();
    for (int rowNumber = 0; rowNumber < field.length; rowNumber++) {
      for (int columnNumber = 0; columnNumber < field[rowNumber].length; columnNumber++) {
        //random.nextGaussian() / 6.0 =  stdev=1/6 center=0
        //rowNumber / (float) field.length - 0.5 = grows uniformly from -0.5 to 0.5
        if (random.nextGaussian() / 6.0 < rowNumber / (float) field.length - 0.5) {
          field[rowNumber][columnNumber] = 'T';
        } else {
          field[rowNumber][columnNumber] = ' ';
        }
      }
    }
  }

  public static void main(String[] args) {
    final char[][] treeField = new char[50][50];
    populateField(treeField);
    printField(treeField);
  }

  private static void printField(char[][] field) {
    Validate.noNullElements(field);
    for (char[] aField : field) {
      System.out.println(StringUtils.join(aField, '|'));
    }
  }
}