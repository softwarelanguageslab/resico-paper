package shell_structure;

import org.hibernate.SessionFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;


public class ClassShell {
    public static void main(String[] args) {
        ResourcePatternResolver patternResolver = new PathMatchingResourcePatternResolver();   
        Resource [] mappingLocations = patternResolver.getResources("classpath*:mappings/**/*.hbm.xml");
        sessionFactory.setMappingLocations(mappingLocations);
    }
}
