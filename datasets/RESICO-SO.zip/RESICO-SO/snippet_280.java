package shell_structure;

import com.google.gson.Gson;

public class ClassShell {
    public static void main(String[] args) {
        List<Dto> beans = service.something();
        Gson gson = new Gson();
        // convert your list to json
        String jsonCartList = gson.toJson(beans);
    }
}
