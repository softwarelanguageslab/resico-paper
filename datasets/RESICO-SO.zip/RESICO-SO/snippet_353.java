package shell_structure;
import java.text.ParseException;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class JodaTimeTransition {
    public static void main(String[] args) throws ParseException {
        String dateString="20141114213000";
        dateString += " UTC";

        /*new*/
        String formatString = "yyyyMMddHHmmss z";
//      String formatString ="yyyyMMddHHmmss";

        /*new*/ 
        DateTimeFormatter dtf = DateTimeFormat.forPattern(formatString);
//      SimpleDateFormat sdf = new SimpleDateFormat(formatString + " z");

        /* new - Create localDate using JodaTime DateTime class */
        DateTime localDate = DateTime.parse(dateString, dtf);
//      Date localDate = sdf.parse(dateString);

        /* new - convert time to MST, since it is currently UTC*/
        localDate = localDate.toDateTime(DateTimeZone.forID("America/Denver"));

        /* new - print out <local date> using specified format.*/
        System.out.println("Local Date::" + localDate.toString("EEE MMM dd HH:mm:ss z yyyy"));
        /* Where did you get the local date mentioned at comments of line below? */
//      System.out.println("Local Date::"+localDate); // Local Date::Sat Nov 15 05:30:00 HKT 2014


        /* new - Get reference to current date/time as <localCal> 
         * (This step can be omitted, and the previous localDate variable can be used)
        */
        DateTime localCal = DateTime.now();
//      Calendar localCal = Calendar.getInstance();

        /* new - Set <localCal> to <localDate> */
        localCal = localDate;
//      localCal.setTime(localDate);

        /* new - Create new EST time zone*/
        DateTimeZone estTimeZone= DateTimeZone.forID("America/New_York");
//      TimeZone estTimeZone = TimeZone.getTimeZone("America/New_York");

        /* new - set <localCal> time zone from MST to EST */
        localCal = localCal.toDateTime(estTimeZone);
//      localCal.setTimeZone(estTimeZone);
//      sdf.setTimeZone(estTimeZone);

        /* new - print <localCal> as new EST time zone */
        System.out.println(localCal.toString("yyyyMMddHHmmss z"));
//      System.out.println(sdf.format(localCal.getTime()));//20141114163000 EST

        /* new - print in desired format: Fri Nov 14 16:30:00 EST 2014 */
        System.out.println(localCal.toString("EEE MMM dd HH:mm:ss z yyyy"));
//      System.out.println(localCal.getTime());//Sat Nov 15 05:30:00 HKT 2014
    }
}