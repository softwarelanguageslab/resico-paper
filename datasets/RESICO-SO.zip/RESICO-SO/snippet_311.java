package shell_structure;
import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import com.jetico.bestcrypt.FileManagerApplication;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class SecondaryCardChannel {//By analogy with the java.nio.channels.SeekableByteChannel
    private FileChannel fileChannel;
    private ParcelFileDescriptor pfd;
    private boolean isInputChannel;
    private long position;

    public SecondaryCardChannel(Uri treeUri, Context context) {
        try {
            pfd = context.getContentResolver().openFileDescriptor(treeUri, "rw");
            FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
            fileChannel = fis.getChannel();
            isInputChannel = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public int read(ByteBuffer buffer) {
        if (!isInputChannel) {
            try {
                fileChannel.close();
                FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
                fileChannel = fis.getChannel();
                isInputChannel = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            fileChannel.position(position);
            int bytesRead = fileChannel.read(buffer);
            position = fileChannel.position();
            return bytesRead;
        } catch (IOException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public int write(ByteBuffer buffer) {
        if (isInputChannel) {
            try {
                fileChannel.close();
                FileOutputStream fos = new FileOutputStream(pfd.getFileDescriptor());
                fileChannel = fos.getChannel();
                isInputChannel = false;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            fileChannel.position(position);
            int bytesWrite = fileChannel.write(buffer);
            position = fileChannel.position();
            return bytesWrite;
        } catch (IOException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public long position() throws IOException {
        return position;
    }

    public SecondaryCardChannel position(long newPosition) throws IOException {
        position = newPosition;
        return this;
    }

    public long size() throws IOException {
        return fileChannel.size();
    }

    public SecondaryCardChannel truncate(long size) throws IOException {
        fileChannel.truncate(size);
        return this;
    }
}