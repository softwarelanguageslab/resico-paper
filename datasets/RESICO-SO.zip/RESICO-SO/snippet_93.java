package shell_structure;

import org.apache.commons.collections4.ListUtils;

public class ClassShell {
    public static void main(String[] args) {
        int targetSize = 100;
        List<Integer> largeList;
        List<List<Integer>> output = ListUtils.partition(largeList, targetSize);
    }
}
