package shell_structure;
import java.io.IOException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class ApiJSONRead {
    public static void main(String[] args) throws IOException {
        HttpClient client = new DefaultHttpClient();
        HttpGet request = new HttpGet("http://ip.jsontest.com/");
        org.apache.http.HttpResponse httpResponse = client.execute(request);
        String response = EntityUtils.toString(httpResponse.getEntity());
        System.out.println(response);
        JsonObject jobj = new Gson().fromJson(response, JsonObject.class);
        String Jsonresponse = jobj.get("ip").getAsString();
        System.out.println(Jsonresponse);
    }
}