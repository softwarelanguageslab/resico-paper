package shell_structure;

import org.apache.commons.lang3.StringUtils;

public class ClassShell {
    public static void main(String[] args) {
        int[] a = {1, 2, 3};
        String key= StringUtils.join(a, '-');
        System.out.println(key);
    }
}
