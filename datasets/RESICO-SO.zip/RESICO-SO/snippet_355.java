package de.is2.sign.test.ldap;

import java.util.List;

import javax.naming.directory.SearchControls;

import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;

import de.is2.insign.aufruferdemo.ldapservices.Group;
import de.is2.insign.aufruferdemo.ldapservices.GroupAttributesMapper;

public class LDAPListGroups {

    public static void main(String[] args) throws Exception {

        LdapContextSource ldapContextSource = new LdapContextSource();
        //LDAP URL
        ldapContextSource.setUrl("ldap://localhost:10389/dc=example,dc=com");
        //Authenticate as User that has access to this node in LDAP
        ldapContextSource.setUserDn("uid=admin,ou=system");
        ldapContextSource.setPassword("secret");
        ldapContextSource.afterPropertiesSet();
        LdapTemplate ldapTemplate = new LdapTemplate(ldapContextSource);
        ldapTemplate.afterPropertiesSet();

        GroupAttributesMapper mapper = new GroupAttributesMapper();
        SearchControls controls = new SearchControls();
        AndFilter filter = new AndFilter();
        filter.and(new EqualsFilter("objectclass", "groupOfNames"));

        List<Group> groups = ldapTemplate.search("ou=groups", filter.encode(), controls, mapper);
        for (Group group:groups)
        {
            System.out.println(group.getLongID());
        }
    }
}