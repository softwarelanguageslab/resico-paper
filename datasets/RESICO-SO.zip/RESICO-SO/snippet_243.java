package stackoverflow.questions.q18116805;

import java.lang.reflect.Type;
import java.util.*;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

public class Main {
    public static void main(String[] args) {
        String json =                                                 
            "{  \"0001\":[111, \"BLABLA\", \"LALA\", \"KKK\",80,20],   "+
            "    \"002\":[222, \"BLABLA\", \"LALA\", \"KKK\",80,40],   "+
            "    \"003\":[333, \"BLABLA\", \"LALA\", \"KKK\",100,20],  "+
            "    \"000\":[444, \"BLABLA\", \"LALA\", \"KKK\",800,60],  "+
            "    \"555\":[555, \"BLABLA\", \"LALA\", \"KKK\",80,20],   "+
            "    \"100\":[48, \"BLABLA\", \"LALA\", \"KKK\",80,20]}";

        Type aType = new TypeToken<Map<String,ArrayList<Object>>>() {}.getType();
        Map<String,ArrayList<Object>> map = new Gson().fromJson(json, aType);

        System.out.println(map);
    }
}