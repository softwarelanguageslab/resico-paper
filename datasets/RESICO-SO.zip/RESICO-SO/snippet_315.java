package shell_structure;

import java.io.*;
import android.content.Context;
import android.content.res.AssetManager;

public class ClassShell {
    public static void main(String[] args) {
        String dbName = /* db name */
        Context context = /* read android context from somewhere */
        File dbFile = context.getDatabasePath( dbName );
        // Test if DB file has been previously deployed.
        if( !dbFile.exists() ) {
            // Deploy the DB file.
            AssetManager assets = context.getAssets();
            // Open an input stream on the source db file in assets.
            // (Production code will need try/catch/finally around this block)
            InputStream in = assets.open("dbname.sqlite");
            // Open an output stream on the target location.
            OutputStream out = new FileOutputStream( dbFile );
            // Copy the contents. (In actual code you would want to
            // use a buffer).
            int byte;
            while( (byte = in.read()) != -1 ) {
                out.write( byte );
            }
            in.close();
            out.close();
        }
    }
}
