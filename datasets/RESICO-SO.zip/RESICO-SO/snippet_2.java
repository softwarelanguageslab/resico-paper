package shell_structure;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class MyCustomBean implements ApplicationContextAware {

  private ApplicationContext springContext;

  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    springContext = applicationContext;
  }

  public ISerializer getSerializer(Object source,boolean useAggressiveSerialization) {
    String serializerBeanName = springContext.getBeanNamesForType(ISerializer.class);
  }
}
