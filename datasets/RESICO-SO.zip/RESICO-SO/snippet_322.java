package id.co.kendaricall;

import android.database.Cursor;
import android.os.Bundle;
import java.util.ArrayList;

public class KontakListActivity extends TemplateActivity {
    public static String ALAMAT_KONTAK;
    public static String ID_KONTAK;
    public static String KATEGORI_KONTAK;
    public static String NAMA_KONTAK;
    private String idKategori;

    static {
        ID_KONTAK = "id_kontak";
        NAMA_KONTAK = "nama_kontak";
        ALAMAT_KONTAK = "alamat_kontak";
        KATEGORI_KONTAK = "kategori_kontak";
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kontaklist);
        headerSetup();
        this.idKategori = getIntent().getExtras().getString("idKategori");
        showKontakList(this.idKategori);
    }

    protected void onResume() {
        super.onResume();
        setNavigation(KATEGORI, this.myData.getKategoriById(this.idKategori));
        setKotaLokasi();
    }

    public void showKontakList(String idKategori) {
        Cursor myCursor = this.myData.getKontakByKotaAndKategori(idKategori);
        ArrayList<Kontak> myList = new ArrayList<Kontak>();
        myCursor.moveToFirst();
        while (!myCursor.isAfterLast()) {
            Kontak kontak = new Kontak();
            kontak.setId(myCursor.getString(myCursor.getColumnIndex("_id")));
            kontak.setNama(myCursor.getString(myCursor.getColumnIndex("nama")));
            kontak.setAlamat(myCursor.getString(myCursor.getColumnIndex("alamat")));
            kontak.setKawasan(myCursor.getString(myCursor.getColumnIndex("kawasan")));
            kontak.setTelepon(myCursor.getString(myCursor.getColumnIndex("nomor")));
            myList.add(kontak);
            myCursor.moveToNext();
        }
        setListAdapter(new AdapterKontakList(this, myList, this.myData.getKategoriById(this.idKategori)));
    }
}