package shell_structure;

import com.google.common.base.CaseFormat;

public class ClassShell {
    public static void main(String[] args) {
        String camelStrings = "YOUR_UPPER, YOUR_TURN, ALT_TAB";

        List<String> camelList = Arrays.asList(camelStrings.split(","));
        camelList.stream().forEach(i -> System.out.println(CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, i) + ", "));
    }
}
