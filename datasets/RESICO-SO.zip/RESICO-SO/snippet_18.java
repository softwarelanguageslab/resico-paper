package shell_structure;

import java.util.Map;
import com.google.common.collect.ImmutableMap;


public class ClassShell {

    public enum EventType2 {
        EventA, EventB, EventC;
    }

    public Map<String, Map<String, String>> execute(String eventMapHolder) {
        final Map<String, String> holder = parseStringToMap(eventMapHolder);
        if (holder.isEmpty() || Strings.isNullOrEmpty(holder.get("m_itemId"))) {
            return ImmutableMap.of();
        }
        String itemId = holder.get("m_itemId");
        Map<String, String> clientInfoHolder = getClientInfo(itemId);
        holder.putAll(clientInfoHolder);
        return ImmutableMap.<String, Map<String, String>>builder()
                .put(this.name(), holder)
                .build();
    };

    public Map<String, String> parseStringToMap(String eventMapHolder) {
        // parse eventMapHolder String to Map
        return null; // FIXME
    }

    public Map<String, String> getClientInfo(final String clientId) {
        // code to populate the map and return it
        return null; // FIXME
    }
}
