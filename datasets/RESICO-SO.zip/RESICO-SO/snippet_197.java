package shell_structure;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;


public class ClassShell {
    public static void main(String[] args) {

        if (action.equals("sayHello")) {
            Context context = yourfunctionReturnsContexthere();
            if(context==null){
            Log.e(TAG,"context is null.. returning");
            }
            Intent intent = new Intent();
            intent.setAction("com.streethawk.intent.action.gcm.STREETHAWK_ACCEPTED");
            PendingIntent pIntent = PendingIntent.getBroadcast(context, 0, intent,     
                PendingIntent.FLAG_UPDATE_CURRENT);
            NotificationCompat.Builder builder = new NotificationCompat.Builder(context);
            builder.setTicker("Test Ticker Notification");
            builder.setContentTitle("Test Title Notification");
            builder.setContentText("Test Content Notification");
            builder.setContentIntent(pIntent).build();
            builder.setAutoCancel(true);
            try {
                PackageInfo packageInfo =  
                context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                builder.setSmallIcon(packageInfo.applicationInfo.icon);
            } catch (NameNotFoundException e) {
                // should never happen
                throw new RuntimeException("Could not get package name: " + e);
            }
            NotificationManager notificationManager = (NotificationManager) 
                context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0, builder.build()); 
        }
    }
}
