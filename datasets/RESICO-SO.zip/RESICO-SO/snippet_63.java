package shell_structure;

import android.text.format.DateFormat;

public class ClassShell {
    public static void main(String[] args) {
        String dateString = (String) DateFormat.format("dd-MM-yyyy",new java.util.Date());
    }
}
