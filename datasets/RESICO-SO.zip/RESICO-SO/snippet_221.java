package shell_structure;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public class XStreamApp {
    public static void main(String[] args) {
        XStream xStream = new XStream();
        xStream.registerConverter(new AConverter());
        xStream.registerConverter(new BConverter());
        xStream.alias("A", A.class);

        System.out.println(xStream.toXML(new A()));
    }
}