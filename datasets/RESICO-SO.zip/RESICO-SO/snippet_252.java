package shell_structure;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

public class ClassShell {
    public static void main(String[] args) {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("key", key);
        params.add("storeId", storeId);
        params.add("orderId", orderId);
        UriComponents uriComponents =     UriComponentsBuilder.fromHttpUrl("http://spsenthil.com/order").queryParams(params).build();
        ListenableFuture<ResponseEntity<String>> responseFuture =     restTemplate.getForEntity(uriComponents.toUriString(), String.class);
    }
}
