package shell_structure;

import com.google.gson.Gson;

public class ClassShell {
    public static void main(String[] args) {

        final String jsonDataString = receive();
        final MyData myData = new Gson().fromJson(jsonDataString, MyData.class);
    }
}
