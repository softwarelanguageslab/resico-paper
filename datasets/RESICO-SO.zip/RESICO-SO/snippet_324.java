package shell_structure;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;


public class ClassShell {

    public String readResource(final String fileName, Charset charset) throws Exception {
        try {
            return Resources.toString(Resources.getResource(fileName), charset);
        } catch (IOException e) {
            throw new IllegalArgumentException(e);
        }
    }
}
