package shell_structure;

import java.util.Random;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;

public class GrowCircle {
    float x, y;
    int radius;
    Paint myp = new Paint();
    int colr,colg,colb;
    int redvar=1;
    int bluevar=5;
    int greenvar=2;
    int tripper=10;
    int change=2;
    Random rand = new Random();

    public GrowCircle(float x, float y) {
        this.x=x;
        this.y=y;
        this.radius=2;
        this.colr=rand.nextInt(254)+1;
        this.colg=rand.nextInt(254)+1;
        this.colb=rand.nextInt(254)+1;

    }

    public void update() {
        radius+=4;
        tripper+=change;
        if(tripper<=1||tripper>=15){
            change=-change;
        }
        Random col = new Random();
        myp.setColor(Color.argb(255,colr,colg,colb));
        colr+=redvar;
        colg+=greenvar;
        colb+=bluevar;

        if(colr<=5||colr>=250){
            redvar=-redvar;
        }
        if(colg<=5||colg>=250){
            greenvar=-greenvar;
        }
        if(colb<=5||colb>=250){
            bluevar=-bluevar;
        }

    }

    public void drawThis(Canvas canvas) {
        myp.setStrokeWidth(tripper);
        myp.setStyle(Style.STROKE);
        canvas.drawCircle(x, y, radius, myp);
    }
}