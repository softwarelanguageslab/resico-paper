package spring.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class InitTest {
    public static void main(String[] args) {
      AbstractApplicationContext ctx = new ClassPathXmlApplicationContext("InitTestContext.xml");
      ctx.registerShutdownHook();

      InitTestBean bean = (InitTestBean)ctx.getBean("InitTestBean");
      bean.display();
    }
}