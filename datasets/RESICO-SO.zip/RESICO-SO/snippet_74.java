package com.beans;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DataRetrieve {
    public static void main(String[] args) {
        Configuration cfg= new Configuration(); 
        cfg.configure("hibernate.cfg.xml");
        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tx = session.beginTransaction();

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the ID you want to see the record:");
        int i = sc.nextInt();
        Query query = session.createQuery("from Employee where id =" + i);
        List list = query.list();

        if(list.size() > 0) {
            Employee emp = (Employee) list.get(0);//new Employee();
            int j = emp.getId();
            if (j == i) {
                System.out.println(emp.getId()+"");
            } else {
                System.out.println("no fields found");
            } 
        } else {
            System.out.println("no Record found");
        } 

        tx.commit();
        session.close();
    }
}