package shell_structure;

import com.google.common.collect.Lists;
import com.google.common.math.IntMath;
import java.math.RoundingMode;


public class ClassShell {
    public static void main(String[] args) {
        int partitionSize = IntMath.divide(list.size(), 2, RoundingMode.UP);
        List<List<T>> partitions = Lists.partition(list, partitionSize);
    }
}
