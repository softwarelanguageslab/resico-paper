package shell_structure;
import java.util.HashSet;
import java.util.LinkedList;

import com.google.common.base.Joiner;

public class CollectionsTest {

    public static void main(String[] args) {
        HashSet<Integer> c = new HashSet<>();
        c.add(0);
        c.add(1);
        c.add(2);

        HashSet<Integer> d = new HashSet<>();
        d.add(2);
        d.add(3);

        System.out.println("c = " + Joiner.on(", ").join(c));
        System.out.println("d = " + Joiner.on(", ").join(d));
        c.addAll(d);
        System.out.println("c.addAll(d) = " + Joiner.on(", ").join(c));
    }
}