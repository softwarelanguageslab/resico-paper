package shell_structure;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.util.List;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
        // write your code here
        String json = "{\"url\": \"https://i.ytimg.com/vi/XGM6sHIJuho/hqdefault1.jpg\"," +
                " \"og:image\": \"https://i.ytimg.com/vi/XGM6sHIJuho/hqdefault2.jpg\"," +
                " \"twitter:image\":\"https://i.ytimg.com/vi/XGM6sHIJuho/hqdefault3.jpg\"}";

        Gson gson = new Gson();
        JsonObject obj = gson.fromJson(json, JsonObject.class);
        List<String> links = obj.entrySet().stream()
                .map(entry -> entry.getValue().getAsString())
                .collect(Collectors.toList());
        links.forEach(System.out::println);
    }
}