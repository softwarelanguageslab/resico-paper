package shell_structure;

import android.widget.Button;

public class ClassShell {
    public static void main(String[] args) {
        Button b = new Button(this);
        b.setText("Button added dynamically!");
        b.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
        b.setId(MY_BUTTON);
        b.setOnClickListener(this);

        ArrayList<Button> buttons = new ArrayList<Button>();
        buttons.add(b);
    }
}
