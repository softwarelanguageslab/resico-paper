package shell_structure;

import com.google.common.collect.Lists;

public class ClassShell {
    public static void main(String[] args) {
        List<String> whatever = Lists.newArrayList("Blah1", "Blah2");
        whatever.add(0, "BlahAll");
    }
}
