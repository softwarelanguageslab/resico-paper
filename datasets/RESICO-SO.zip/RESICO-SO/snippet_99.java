package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PropertyReader {

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
        List<String> locales = new ArrayList<String>(Arrays.asList("en", "ru", "de"));
        for (String loc : locales) {
            Locale locale = new Locale(loc);
            String value = context.getMessage("example", null, locale);
            System.out.println(value);
        }
        ((AbstractApplicationContext) context).close();
    }
}