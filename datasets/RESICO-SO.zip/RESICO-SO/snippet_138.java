package shell_structure;

import com.google.common.base.Defaults;

public class ClassShell {
    public static void main(String[] args) {
        Defaults.defaultValue(Integer.TYPE); //will return 0
    }
}
