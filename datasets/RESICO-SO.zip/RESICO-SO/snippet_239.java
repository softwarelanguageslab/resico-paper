package shell_structure;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import java.util.Map;
import java.util.Set;

public class Search {

    public static void drawChart(Multimap<String, Integer> persons){
        //we use Multimap because we may have more than one person with the same name
        Set<String> names = persons.keySet();
        int maxLength = 0;
        for (String name : names) {
            if (name.length() > maxLength) {
                maxLength = name.length(); //define the longest name
            }
        }

        for (Map.Entry<String, Integer> entry : persons.entries()) {
            String name = entry.getKey();
            System.out.print(name);
            if (name.length() < maxLength) {
                //adjusting the number of spaces required to be on the same level
                //with the longest name
                int diff = maxLength - name.length();
                for (int i = 0; i < diff; i++) {
                    System.out.print(" ");
                }
            }
            Integer age = entry.getValue();
            for (int i = 0; i < age; i++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Multimap<String, Integer> map = ArrayListMultimap.create();
        map.put("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" +
            "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 2);
        map.put("ffffffffffffffffffffffffffffffffffffffffffffffffff" +
            "fffffffffffffffffffffffff", 3);
        map.put("zz", 3);
        map.put("zz", 6);
        map.put("ffff", 9);
        drawChart(map);
    }
}