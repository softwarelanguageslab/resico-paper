package shell_structure;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.io.FileReader;
import java.nio.file.StandardOpenOption;

public class JsonUpdater {
  // Method to update nested json elements
  public void updateJson(String inputFile, String outputFile) {
      try {
          // Get the json content from input file
          String content = new String(Files.readAllBytes(Paths.get(inputFile)));

          // Get to the nested json object
          JsonObject jsonObj = new Gson().fromJson(content, JsonObject.class);
          JsonObject nestedJsonObj = jsonObj
                  .getAsJsonObject("level-1")
                  .getAsJsonObject("level-2")
                  .getAsJsonObject("level-3")
                  .getAsJsonArray("level-4b").get(0).getAsJsonObject();

          // Update values
          nestedJsonObj.addProperty("level-4b-1", "new-value-4b-1");
          nestedJsonObj.getAsJsonObject("level-4b-3").addProperty("StartDate", "newdate");

          // Write updated json to output file
          Files.write(Paths.get(outputFile), jsonObj.toString().getBytes(), StandardOpenOption.CREATE);
      } catch (IOException exception) {
          System.out.println(exception.getMessage());
      }
  }

  // Main
  public static void main(String[] args) {
    JsonUpdater jsonUpdater = new JsonUpdater();
    jsonUpdater.updateJson("test.json", "new.json");
  }
}