package shell_structure;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UserDao {
    Session session;
    Transaction tran;

    public void get() {
        Configuration c=new Configuration();
        c.configure("hibernate.cfg.xml");
        SessionFactory se=c.buildSessionFactory();
        session=se.openSession();
        tran=session.beginTransaction();

    }
    
    public void addUser(String username, String password, String email, String phone, String city) {
        User user=new User();


        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        user.setPhone(phone);
        user.setCity(city);

        session.save(user);
        tran.commit();

        System.out.println("saved succesfully");
    }
}