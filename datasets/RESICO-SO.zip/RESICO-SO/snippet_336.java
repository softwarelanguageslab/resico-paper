package shell_structure;

import org.apache.commons.lang3.SerializationUtils;

public class ClassShell {
    public static void main(String[] args) {
        clonedArrayList = SerializationUtils.deserialize(SerializationUtils.serialize(originalArrayList));
    }
}
