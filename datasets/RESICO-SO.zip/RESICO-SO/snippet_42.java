package com.webom.crypt;

import org.apache.commons.lang3.StringEscapeUtils;
import com.ibm.icu.text.Transliterator;

public class Test {

        public static String ARABIC_TO_LATIN = "Arabic-Latin";
        public static String ARABIC_TO_LATIN_NO_ACCENTS = "Arabic-Latin; nfd; [:nonspacing mark:] remove; nfc";

        public static void main(String[] args) {
            String ARABICString = "صدام حسين التكريتي";

            String unicodeCodes = StringEscapeUtils.escapeJava(ARABICString);
            System.out.println("Unicode codes:" + unicodeCodes);

            Transliterator ARABICToLatinTrans = Transliterator.getInstance(ARABIC_TO_LATIN);
            String result1 = ARABICToLatinTrans.transliterate(ARABICString);
            System.out.println("ARABIC to Latin:" + result1);
     
            Transliterator ARABICToLatinNoAccentsTrans = Transliterator.getInstance(ARABIC_TO_LATIN_NO_ACCENTS);
            String result2 = ARABICToLatinNoAccentsTrans.transliterate(ARABICString);
            System.out.println("ARABIC to Latin (no accents):" + result2);
        }
    }