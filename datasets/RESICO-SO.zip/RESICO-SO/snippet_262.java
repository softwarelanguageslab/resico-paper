package shell_structure;

import com.google.gwt.i18n.client.NumberFormat;

public class ClassShell {
    public static void main(String[] args) {
        Double value = Double.parseDouble("0.00000012");
        String formatted = NumberFormat.getFormat("0.#####E0").format(value);
        System.out.println(formatted);
    }
}
