package shell_structure;
import org.joda.time.DateTime;    
import org.joda.time.DateTimeZone;    
import org.joda.time.format.DateTimeFormat;    
import org.joda.time.format.DateTimeFormatter;

public class TestTimezone {
    public static void main(String[] args) {

        DateTime jodatime = new DateTime(DateTimeZone.UTC);
        DateTimeFormatter dtfOut = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSSZZ");
        System.out.println(dtfOut.print(jodatime));

    }
}