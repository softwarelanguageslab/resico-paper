package shell_structure;

import com.google.common.collect.Sets;

public class ClassShell {
    public static void main(String[] args) {
        Sets.newHashSet("a", "b");
    }
}
