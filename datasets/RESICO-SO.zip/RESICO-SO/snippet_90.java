package shell_structure;
import java.util.*;
import com.google.common.base.Predicate;     
import com.google.common.collect.Lists;
import com.google.common.collect.Iterables;

public class YourClassName {
public List<PersonSearchResult> searchPersonListAsPerson( Person bean, short minScore, int maxResults, String cvwName, Person.PersonSource[] sources,  Person.PersonAttribute[] attributes) throws MasterDataServiceException {
            logServiceBegin(log, "searchPersonListAsPerson");
            PersonMapper mapper = new PersonMapper();
            List<PersonSearchResult> searchResults = searchForRecordList( mapper, bean, PersonEntityId.getStaticEntType(), minScore, maxResults, cvwName, sources, attributes);        
            if(searchResults != null && searchResults.size() > 1) {
            List<PersonSearchResult> results = Lists.new ArrayList()
                PersonPredicate pPredicate = new PersonPredicate();
                pPredicate.setSrcCodeToTest("CRDSCNCTP");
                Iterable<PersonSearchResult> result = Iterables.filter(searchResults, pPredicate);
                List result = Lists.newArrayList(result);
                if(result.size() > 0){
                    Collections.sort(result, new Comparator<PersonSearchResult>(){
                        public int compare(PersonSearchResult a, PersonSearchResult b) {
                            if(isNullOrEmpty(a.getPerson().getPerAttributesList()) && isNullOrEmpty(b.getPerson().getPerAttributesList())){
                                return 0;
                            }else if(isNullOrEmpty(b.getPerson().getPerAttributesList())){
                                return -1;
                            }else if(isNullOrEmpty(a.getPerson().getPerAttributesList())){
                                return 1;
                            }else{
                                int comparison = a.getPerson().getPerAttributesList().get(0).getStatus().compareToIgnoreCase(b.getPerson().getPerAttributesList().get(0).getStatus());
                                return comparison == 0 ? b.getPerson().getPerAttributesList().get(0).getUpdateDate().compareTo(a.getPerson().getPerAttributesList().get(0).getUpdateDate()) : comparison;
                            }
                        }
                    });
                }
            }
            logServiceEnd(log, "searchPersonListAsPerson");
            cleanUserCredentials();
            return searchResults;
        }

        private boolean isNullOrEmpty(List<Memperson> list){
            return list == null || list.isEmpty();
        }

}
class PersonPredicate implements Predicate<PersonSearchResult>{
        String srcCodeToTest;
        public boolean apply(PersonSearchResult person) {                
            return srcCodeToTest.equalsIgnoreCase(person.getPerson().getPersonId().getSrcCode());
        }
        public void setSrcCodeToTest(String srcCodeToTest){
            this.srcCodeToTest = srcCodeToTest;
        }
}