package com.vimal.common;

import java.text.SimpleDateFormat;
import java.util.Locale;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

 public class App {
    public static void main(String[] args) {

    ApplicationContext context = new ClassPathXmlApplicationContext("com/vimal/common/beans.xml");
    String name = context.getMessage("user.name", new Object[] { 45,"http://www.vkrishna.com" }, Locale.US);

    System.out.println("User name (English) : " + name);

    String nameHindi = context.getMessage("user.name", new Object[] {45, "http://www.vkrishna.com" }, new Locale("hi", "IN"));

    System.out.println("User name (Hindi) : " + nameHindi);
  }
}