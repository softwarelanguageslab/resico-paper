package shell_structure;
import java.lang.reflect.Type;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

class JsonData {
    private String type;
    private String id;
    private double radius;
    private List<Double> geometry;

    //Getters & Setters
}

public class JsonParser {

    public static void main(String[] args) {
        String json = "[{\"type\":\"CIRCLE\",\"id\":null,\"radius\":1730.4622192451884,\"geometry\":[32.3610810916614,50.91339111328125]},{\"type\":\"CIRCLE\",\"id\":null,\"radius\":1831.5495077322266,\"geometry\":[32.35528086804335,50.997161865234375]},{\"type\":\"CIRCLE\",\"id\":null,\"radius\":1612.2461023303567,\"geometry\":[32.34454947365649,51.011924743652344]}]";

        Type listType = new TypeToken<List<JsonData>>() {}.getType();
        List<JsonData> disputeSummaryArraylistobjectList = new Gson().fromJson(json, listType);
        System.out.println(disputeSummaryArraylistobjectList);
    }

}