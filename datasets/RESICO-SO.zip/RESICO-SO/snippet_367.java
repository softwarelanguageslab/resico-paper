package shell_structure;
import com.google.gson.Gson;

public class App {
    public static void main(String[] args) {
        String s = "{number:2,date:1444953600}";
        MyClass temp = new Gson().fromJson(s, MyClass.class);
        System.out.println("number="+temp.number+" , "+temp.date);
    }

    class MyClass {
        public int number;
        public long date;
    }
}