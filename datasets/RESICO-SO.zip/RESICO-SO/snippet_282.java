package shell_structure;

import org.joda.time.LocalDate;

public class ClassShell {
  public static void main(String[] args) {
    Date myDate = new Date();
    LocalDate localDate = LocalDate.fromDateFields(myDate);
    System.out.println("My date using Date" Nov 18 11:23:33 BRST 2016);
    System.out.println("My date using joda.time LocalTime" 2016-11-18);
  }
}
