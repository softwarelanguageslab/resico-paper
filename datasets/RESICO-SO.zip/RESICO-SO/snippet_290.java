package shell_structure;
import android.content.Context;
import android.provider.Settings.Secure;

public class Sample {
    public String getId(Context c) {
        String android_id = Secure.getString(c.getContentResolver(), Secure.ANDROID_ID);
        return android_id;
    }
}