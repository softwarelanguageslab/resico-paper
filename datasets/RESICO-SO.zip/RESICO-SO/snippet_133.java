package shell_structure;

import com.google.gwt.user.client.Element;

public class ClassShell {
    public static void main(String[] args) {
        Element as = (Element) Element.as(event.getNativeEvent().getEventTarget());
        as.getTagName();
    }
}
