package ssh.control;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import android.util.Log;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;


public class SSHConnections {
    static String user="";
    static String pass="";
    static String ip="";


    static Session session;

    public static ChannelExec getChannelExec() throws Exception{
        //System.out.println("connected");
        //This class serves as a central configuration point, and as a factory for Session objects configured with these settings.
        JSch jsch = new JSch();
        //A Session represents a connection to a SSH server.
        session = jsch.getSession(user, ip, 22);
        //getSession()   :-  the session to which this channel belongs. 
        session.setPassword(pass);

        // Avoid asking for key confirmation
        //http://docs.oracle.com/javase/1.4.2/docs/api/java/util/Properties.html
        Properties prop = new Properties();
        prop.put("StrictHostKeyChecking", "no");


        //Sets multiple default configuration options at once. 
        session.setConfig(prop);

        session.connect();
        if(session.isConnected()) {
            System.out.println("connected");
        }

        // SSH Channel 
        //Opens a new channel of some type over this connection. 
        ChannelExec channelssh = (ChannelExec) session.openChannel("exec");

        return channelssh;
    }

    public static  String[] executeRemoteCommand(String command) throws Exception {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ChannelExec channelssh = SSHConnections.getChannelExec();
        channelssh.setOutputStream(baos);

        // Execute command
        channelssh.setCommand(command);//gedit tt
        InputStreamReader isr = new InputStreamReader(channelssh.getInputStream());

        BufferedReader bufred = new BufferedReader(isr);

        channelssh.connect();
        String s = bufred.readLine();

        List<String> lines = new ArrayList<String>();

        int count = 0;
        while( s!=null ) {
            //System.out.println(s);
            lines.add(count,s);
            //      filesandfolders[count]=s;
            //      System.out.println(filesandfolders[count]);
            s = bufred.readLine();  
            count++;
        }

        String filesandfolders[] = new String[count];

        for(int i = 0; i<count;i++) {
            filesandfolders[i] = lines.get(i);
            Log.d("filesandfolders[i]", filesandfolders[i]);
        }
        //for(int j=0;j<filesandfolders.length;j++) {
        //System.out.println(filesandfolders[j]);
        //}
        //System.out.println("lines is "+lines.get(0));
        //int a;
        //while((a = isr.read()) != -1)
        //System.out.print((char)a);
        //channelssh.disconnect();
        //return baos.toString();
        return filesandfolders;
    }

    public static  List<String> executeRemoteCommand1(String command) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ChannelExec channelssh=SSHConnections.getChannelExec();
        channelssh.setOutputStream(baos);

        // Execute command
        channelssh.setCommand(command);//gedit tt
        InputStreamReader isr = new InputStreamReader(channelssh.getInputStream());

        BufferedReader bufred = new BufferedReader(isr);

        channelssh.connect();
        String s = bufred.readLine();

        List<String> lines = new ArrayList<String>();

        int count=0;
        while(s != null) {
            //System.out.println(s);
            lines.add(count, s);
            //      filesandfolders[count] = s;
            //      System.out.println(filesandfolders[count]);
            s = bufred.readLine();  
            count++;
        }

        String filesandfolders[] = new String[count];

        for(int i=0; i<count;i++) {
            filesandfolders[i]=lines.get(i);
        }
        //for(int j=0;j<filesandfolders.length;j++) {
        //System.out.println(filesandfolders[j]);
        //}
        //System.out.println("lines is "+lines.get(0));
        //int a;
        //while((a = isr.read()) != -1)
        //System.out.print((char)a);
        //channelssh.disconnect();
        //return baos.toString();
        return lines;
    }
}