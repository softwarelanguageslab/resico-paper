package shell_structure;

import org.springframework.util.FileCopyUtils;

public class ClassShell {
    public static void main(String[] args) {

        InputStream is = connection.getInputStream();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        FileCopyUtils.copy(is, bos);
        String data = new String(bos.toByteArray());
    }
}
