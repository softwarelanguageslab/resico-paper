package shell_structure;

import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.xml.transform.StringSource;


public class ClassShell {

public void doWithMessage(WebServiceMessage message) {
    if (message instanceof SaajSoapMessage) {
        try {
            SaajSoapMessage soapMessage = (SaajSoapMessage) message;
            SoapHeader soapHeader = soapMessage.getSoapHeader();
            StringSource headerSource = new StringSource("<MYHeader>\n<Auth>\n<MyID>1312</MyID>\n<Pwd>test213</Pwd>\n</Auth>\n</MYHeader>");
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(headerSource, soapHeader.getResult());
        } catch (TransformerFactoryConfigurationError | TransformerException e) {
            logger.error(e.getMessage(), e);
        }
    }
}
}
