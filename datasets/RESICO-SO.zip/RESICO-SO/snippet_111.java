package shell_structure;

import com.google.gson.Gson;

public class ClassShell {
    public static void main(String[] args) {
        Gson gson = new Gson();
        String jsonInString = gson.toJson(obj);
    }
}
