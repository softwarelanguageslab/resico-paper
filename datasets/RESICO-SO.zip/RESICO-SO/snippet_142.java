package shell_structure;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class StringTest {
    public static void main(String[] args) {
        int numIterations = 100000;
        int numRuns = 10;
        ArrayList<String> strings = new ArrayList<String>();
        for(int i = 0; i < 1000; i++) strings.add("Remove the word remove from String "+i);

        long before = 0;
        long after = 0;
        for(int j=0; j < numRuns; j++) {
            before = System.currentTimeMillis();
            for(int i = 0; i < numIterations; i++){
                for(String s : strings){
                    String newvalue = s.split(" ", 2)[1];
                }
            }
            after = System.currentTimeMillis() - before;
            System.out.println("Split Took "+after + " ms");
        }


        // Substring method
        for(int j=0; j < numRuns; j++) {
            before = System.currentTimeMillis();
            for(int i = 0; i < numIterations; i++){
                for(String s : strings){
                    String newvalue = s.substring(s.indexOf(" ") + 1);
                }
            }
            after = System.currentTimeMillis() - before;
            System.out.println("Substring Took "+after + " ms");
        }



        // Apache Commons Lang method
        before = System.currentTimeMillis();
        for(int j=0; j < numRuns; j++) {
            before = System.currentTimeMillis();
            for(int i = 0; i < numIterations; i++){
                for (String s : strings) {
                    String parentStringValue = StringUtils.substringAfter(s, " ");
                }
            }
            after = System.currentTimeMillis() - before;
            System.out.println("CommonsLang Took "+after + " ms");
        }


        for(int j=0; j < numRuns; j++) {
            long deleteTime = 0l;     
            before = System.currentTimeMillis();
            for(int i = 0; i < numIterations; i++){

                List<StringBuilder> stringBuilders = new ArrayList<StringBuilder>();
                for (String s : strings) {
                    stringBuilders.add(new StringBuilder(s));
                }
                long beforeDelete = System.currentTimeMillis();
                for (StringBuilder s : stringBuilders) {
                    s.delete(0, s.indexOf(" ") + 1);
                }
                deleteTime+=(System.currentTimeMillis() - beforeDelete);
            }
            after = System.currentTimeMillis() - before;
            System.out.println("StringBuilder Delete " + deleteTime + " ms out of " + after + " total ms");
        }

        // Faster Regex method
        Pattern pattern = Pattern.compile("\\w+\\s");
        for(int j=0; j < numRuns; j++) {
            before = System.currentTimeMillis();
            for(int i = 0; i < numIterations; i++){
                for (String s : strings) {
                    String newvalue = pattern.matcher(s).replaceFirst("");
                }
            }
            after = System.currentTimeMillis() - before;
            System.out.println("Faster Regex Took "+after + " ms");
        }

        // Slow Regex method
        for(int j=0; j < numRuns; j++) {
            before = System.currentTimeMillis();
            for(int i = 0; i < numIterations; i++){
                for (String s : strings) {
                    String newvalue = s.replaceFirst("\\w+\\s", "");
                }
            }
            after = System.currentTimeMillis() - before;
            System.out.println("Slow Regex Took " + after + " ms");
        }
    }
}