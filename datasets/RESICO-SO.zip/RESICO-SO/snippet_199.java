package shell_structure;

import android.provider.ContactsContract.PhoneLookup;


public class ClassShell {

    public String fetchContactIdFromPhoneNumber(String phoneNumber) {
        Uri uri = Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(phoneNumber));
        Cursor cursor = this.getContentResolver().query(uri,
            new String[] { PhoneLookup.DISPLAY_NAME, PhoneLookup._ID },
            null, null, null);

        String contactId = "";

        if (cursor.moveToFirst()) {
            do {
            contactId = cursor.getString(cursor
                .getColumnIndex(PhoneLookup._ID));
            } while (cursor.moveToNext());
        }

        return contactId;
    }
}
