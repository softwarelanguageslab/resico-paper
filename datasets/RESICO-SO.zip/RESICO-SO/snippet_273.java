package com.stackoverflow.so19019560;

import com.google.common.base.CharMatcher;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;

import java.util.List;

public class Foo {

    private static final Splitter SPLITTER = Splitter.on(CharMatcher.WHITESPACE).omitEmptyStrings();

    public static void main(final String[] args) {
        final String string = "1-50  of \t\n500+";
        final List<String> elements = Lists.newArrayList(SPLITTER.split(string));

        // output
        for (int i = 0; i < elements.size(); i++) {
            System.out.println(String.format("Element %d: %s", i + 1, elements.get(i)));
        }
    }
}