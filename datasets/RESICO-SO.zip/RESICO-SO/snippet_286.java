package shell_structure;
import com.google.gson.Gson;

class Foo {
    private String hello;

    public String toString() {
        return "hello='" + hello + "'";
    }
}

public class hello {
    public static void main(String[] args) {
        String text = "{\"hello\": \"world\"}";

        Gson gson = new Gson();
        Foo foo = gson.fromJson(text, Foo.class);

        System.out.println(foo.toString());
        System.out.println(gson.toJson(foo));
    }
}