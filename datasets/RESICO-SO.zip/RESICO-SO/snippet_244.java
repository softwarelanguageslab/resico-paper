package co.mr_tpktrustcircle.testgson;

import android.util.Log;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;

public class MainExample {

    public main() {
        Gson mGson = new Gson();
        List<Example2> example2List = new ArrayList<>();
        example2List.add(new Example2("example2.1", 2));
        example2List.add(new Example2("example2.2", 3));

        Example example1 = new Example("hello", example2List);

        String resultToJSON = mGson.toJson(example1); //This works fine. The example2List is stored as a JSON Array.
        Log.i("__json string : ", resultToJSON);
        Example resultFromJSON = mGson.fromJson(resultToJSON, Example.class); // This should give an error as you suggested: "Expected BEGIN_OBJECT but was NUMBER at line 1 column 2 path $"

        Log.i("__resultFromJSON.str : ", resultFromJSON.getExampleString());

        List<Example2> example2FromGson = resultFromJSON.getExample2List();
        for (Example2 example2Element : example2FromGson) {
            Log.d("__example2 element : ",example2Element.getString() + " & " + example2Element.getInt());
        }
    }
}