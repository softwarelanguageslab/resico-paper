package shell_structure;

import org.apache.commons.collections4.ListUtils;

public class ClassShell {
  public static void main(String[] args) {

    ArrayList<Integer> mainList;
    List<List<Integer>> multipleLists = ListUtils.partition(mainList,100);

    int i=1;
    for (List<Integer> indexedList : multipleLists) {
      System.out.println("Values in List "+i);

      for (Integer value : indexedList)
        System.out.println(value);
      i++;
    }
  }
}
