package shell_structure;
import com.google.gson.Gson;

public class MainClass {

    public static void main(String[] args) {
        try {
            Gson gson = new Gson();
            String responseBody = "{\"coord\":{\"lon\":-0.13,\"lat\":51.51},\"weather\":[{\"id\":803,\"main\":\"Clouds\",\"description\":\"broken clouds\",\"icon\":\"04n\"}],\"base\":\"stations\",\"main\":{\"temp\":280.83,\"feels_like\":278.79,\"temp_min\":279.15,\"temp_max\":282.15,\"pressure\":1006,\"humidity\":87},\"visibility\":10000,\"wind\":{\"speed\":1.5},\"clouds\":{\"all\":75},\"dt\":1580086051,\"sys\":{\"type\":1,\"id\":1414,\"country\":\"GB\",\"sunrise\":1580111217,\"sunset\":1580143144},\"timezone\":0,\"id\":2643743,\"name\":\"London\",\"cod\":200}";
            WeatherConditions newWeather = gson.fromJson(responseBody, WeatherConditions.class);
            System.out.println(
                    "Temp: " + newWeather.getMain().getTemp() + "\nPressure: " + newWeather.getMain().getPressure()
                            + "\nHumidity: " + newWeather.getMain().getHumidity() + "\nTemp_max: "
                            + newWeather.getMain().getTemp_max() + "\nTemp_min: " + newWeather.getMain().getTemp_min());
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
    }
}