package shell_structure;
import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;

public class OnlineCheck {
    public boolean isOnline(Context context) {

        ConnectivityManager conMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] networkInfo = conMgr.getAllNetworkInfo();
        boolean state=false;

        for(NetworkInfo nInfo:networkInfo){
            if(nInfo.getType()==ConnectivityManager.TYPE_WIFI || nInfo.getType()==ConnectivityManager.TYPE_ETHERNET || nInfo.getType()==ConnectivityManager.TYPE_MOBILE){
                if (nInfo.getState() == NetworkInfo.State.CONNECTED || nInfo.getState() == NetworkInfo.State.CONNECTING) {
                    state=true;
                    break;
                } 
            }
        }
        return state;
    }
}