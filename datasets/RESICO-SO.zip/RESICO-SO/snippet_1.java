package com.queomedia.vwcotool.infrastructure.security.spring;   
import org.springframework.security.access.expression.method.ExtensibleMethodSecurityExpressionRoot;
import org.springframework.security.core.Authentication;

public class VwCoToolMethodSecurityExpressionRoot extends ExtensibleMethodSecurityExpressionRoot {

    private Authentication a;

    public MyMethodSecurityExpressionRoot(final Authentication a) {
        super(a);
        this.a = a;
    }

    public isXXX(final DomainObject x){
        return x.getCreator().getName().equals(a.getPrincipal());
    }
}