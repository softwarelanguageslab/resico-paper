package shell_structure;
import com.google.gson.Gson;
import com.owlike.genson.Genson;
import com.owlike.genson.annotation.JsonProperty;

public class JsonParseDate {
    public String json = "{\"date\":\"2017-12-23T20:30:15.000Z\",\"user_fk\":\"1\"}";

    public static void main(String [] args){
        JsonParseDate app = new JsonParseDate();
        app.go();
    }

    private void go(){

        // Comment next two lines to run with Gson (and uncomment the Gson lines)
        // Genson genson = new Genson();
        // DatedObject datedObject = genson.deserialize(json, DatedObject.class);

        // Comment next two lines to run with Genson (and uncomment Genson lines)
        Gson gson = new Gson();
        DatedObject datedObject = gson.fromJson(json, DatedObject.class);
        System.out.println(datedObject.date);

    }

    public static class DatedObject{
        public Date date;
        public String user;

        public DatedObject(Date date, String user){
            this.date = date;
            this.user = user;
        }
    }
}