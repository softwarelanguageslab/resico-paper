package shell_structure;

import java.util.EnumSet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.schema.TargetType;
import org.junit.Test;

import Entity.Users;

public class TestMain {
    public static void main(String[] args) {
         try {
            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure().build();
            SessionFactory sessionFactory = new MetadataSources(serviceRegistry).buildMetadata().buildSessionFactory();
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            Users users = new Users();
            users.setId(2);
            session.save(users);
            transaction.commit();
            session.close();
            sessionFactory.close();
         } catch(Throwable th) {
                System.err.println("Init SessionFactory creation failed" );
                System.err.println(th);
                throw new ExceptionInInitializerError(th);
         } finally {

        }
    }
}