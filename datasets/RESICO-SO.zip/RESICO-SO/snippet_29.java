package shell_structure;

import com.google.common.collect.ImmutableMap;

public class ClassShell {
    public static void main(String[] args) {

        // For up to five entries, use .of()
        Map<String, Integer> littleMap = ImmutableMap.of(
            "One", Integer.valueOf(1),
            "Two", Integer.valueOf(2),
            "Three", Integer.valueOf(3)
        );

        // For more than five entries, use .builder()
        Map<String, Integer> bigMap = ImmutableMap.<String, Integer>builder()
            .put("One", Integer.valueOf(1))
            .put("Two", Integer.valueOf(2))
            .put("Three", Integer.valueOf(3))
            .put("Four", Integer.valueOf(4))
            .put("Five", Integer.valueOf(5))
            .put("Six", Integer.valueOf(6))
            .build();
    }
}
