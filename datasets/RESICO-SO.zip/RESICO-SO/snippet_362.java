package shell_structure;

import org.hibernate.cfg.Configuration;

public class ClassShell {
    public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLInnoDBDialect");
    }
}
