package shell_structure;

import com.google.gwt.dom.client.Style.Visibility;

public class ClassShell {
    public static void main(String[] args) {
        RootPanel timeinfo = RootPanel.get("timeinfo");
        if (timeinfo != null) {
            timeinfo.getElement().getStyle().setVisibility(Visibility.VISIBLE);
        }
    }
}
