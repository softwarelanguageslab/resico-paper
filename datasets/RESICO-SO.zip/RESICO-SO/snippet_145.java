package shell_structure;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.collections.FactoryUtils;

public class SubDevisonDto {
  public static void main(String[] args) {
    List subDevisions = LazyList.decorate(new ArrayList(), FactoryUtils.instantiateFactory(SubDivison.class));
  }
}