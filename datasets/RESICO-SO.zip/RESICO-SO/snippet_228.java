package shell_structure;

import android.telephony.TelephonyManager;
import android.content.Context;


public class ClassShell {
    public static void main(String[] args) {
        TelephonyManager telephonyManager;
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        String deviceId = telephonyManager.getDeviceId();
    }
}
