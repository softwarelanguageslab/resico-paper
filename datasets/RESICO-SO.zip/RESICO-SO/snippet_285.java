package shell_structure;

import android.hardware.Camera;

public class ClassShell {
    public static void main(String[] args) {
        int numberOfCameras = Camera.getNumberOfCameras();
    }
}
