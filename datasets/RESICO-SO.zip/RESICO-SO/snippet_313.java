package shell_structure;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


public class Test {

    public static void main(String[] args) throws IOException {
        // TODO Auto-generated method stub

        Team team = new Team();

        team.setLeader("RenegadeEagle");
        team.setSerilizedInventory("54;");
        team.setMods(new ArrayList());


        List members = new ArrayList();
        members.add("069dcc56-cc5b-3867-a4cd-8c00ca516344");
        team.setMembers(members);

        TeamsWrapper tw = new TeamsWrapper();
        List ls1 = new ArrayList();

        ls1.add(team);
        ls1.add(team);

        tw.setTeam(ls1);
        tw.setTeamName("teamname");

        Gson gson = new GsonBuilder().create();
        System.out.println(gson.toJson(tw));
    }
}