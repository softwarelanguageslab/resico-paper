package shell_structure;

import org.apache.commons.lang3.RegExUtils;

public class ClassShell {
    public static void main(String[] args) {
        String input = RegExUtils.removeAll(input, "-?[^\\d.]");
    }
}
