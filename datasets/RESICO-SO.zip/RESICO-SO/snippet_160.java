package shell_structure;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.core.client.JsonUtils;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;

public class _37_OverLayStackOverfflowQuestion implements EntryPoint {

    String jsonS = "{\"hello\":\"world\"}";

    public void onModuleLoad() {
        JavaScriptObject jso = JsonUtils.safeEval(jsonS);
        DataUtil overlayEr = jso.cast();
        OtherOverlay wellwell = jso.cast();

        overlayEr.test(wellwell);
        Window.alert("works");
    }
}