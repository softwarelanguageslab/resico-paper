package shell_structure;

import org.apache.commons.lang3.StringUtils;

public class ClassShell {
    public static void main(String[] args) {
        String model = "07:40,09:00,10:20,11:40,|09:00,10:20,11:40,|07:40,09:00,10:20,11:40,|10:20,11:40,|"
        model = StringUtils.removeEnd(model, ",|");
    }
}
