package shell_structure;

import org.springframework.integration.transformer.ObjectToMapTransformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;


public class ClassShell {
    public static void main(String[] args) {
            Message message = new GenericMessage(value);
            ObjectToMapTransformer transformer = new ObjectToMapTransformer();
                    transformer.setShouldFlattenKeys(true);
                    Map<String,Object> payload = (Map<String, Object>) transformer
                            .transform(message)
                            .getPayload();
    }
}
