package shell_structure;

import com.google.gson.JsonObject;


public class ClassShell {

    public static void main(String[] args) {

        Gson gson = new GsonBuilder().create();
        JsonObject jsonObject = gson.fromJson(content, JsonObject.class);
        String serializedName = jsonObject.get("name").getAsString();
    }
}
