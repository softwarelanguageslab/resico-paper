package shell_structure;

import org.apache.commons.lang3.StringUtils;

public class ClassShell {
    public static void main(String[] args) {
        String filename = StringUtils.upperCase(filename);
    }
}
