package shell_structure;

import com.google.common.base.Strings;

public class ClassShell {
    public static void main(String[] args) {
        if (!Strings.isNullOrEmpty(myString)) {
            return myString;
        }
    }
}
