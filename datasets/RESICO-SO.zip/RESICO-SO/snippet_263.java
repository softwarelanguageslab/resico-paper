package shell_structure;

import org.junit.Assert;
import static org.hamcrest.Matchers.isEmptyString;


public class ClassShell {
    public static void main(String[] args) {
        WebElement myInput = driver.findElement(By.cssSelector("input[type=\"text\"]"));
        Assert.assertThat(myInput.getAttribute("value"), isEmptyString());
    }
}
