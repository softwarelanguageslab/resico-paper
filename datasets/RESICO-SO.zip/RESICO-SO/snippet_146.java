package shell_structure;
import org.apache.commons.lang3.text.WordUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ExtractInfo  {

    public static void main (String [] args) { 
        String html = "<PERSON>James murray</PERSON> went to <LOCATION>Los angeles</LOCATION>";
        Document doc = Jsoup.parse(html);
        Elements es = doc.select("person,location");
        for(Element e : es){
           String eText = e.text();
           e.text(replace(eText));
        }
        System.out.println(doc.text());
   }
   public static String replace(String str){
       return WordUtils.capitalize(str);
   }
}