package shell_structure;

import com.google.common.base.Stopwatch;

public class ClassShell {
    public static void main(String[] args) {
        final Stopwatch stopwatch = Stopwatch.createStarted();
        //dostuff
        System.out.println("Time of execution in seconds:" + stopwatch.stop().elapsed(TimeUnit.SECONDS));
    }
}
