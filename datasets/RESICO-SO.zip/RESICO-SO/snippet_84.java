package shell_structure;
import java.io.IOException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;


public class JsoupParser6 {

    public static void main(String[] args) {
        try {
            // Integral
            String url = "http://www.integral-calculator.com/int.php";
            String q = "{\"expression\":\"sin(4x) * e^(-x)\",\"intVar\":\"x\",\"upperBound\":\"\",\"lowerBound\":\"\",\"simplifyExpressions\":false,\"latex\":\"\\\\displaystyle\\\\int\\\\limits^{}_{}{\\\\sin\\\\left(4x\\\\right){\\\\cdot}{\\\\mathrm{e}}^{-x}\\\\, \\\\mathrm{d}x}\"}";
            Document integralDoc = Jsoup.connect(url).data("q", q).data("v", "1380119311").post();
            System.out.println(integralDoc);
            System.out.println("\n*******************************\n");

            //Differential
            url = "http://www.derivative-calculator.net/diff.php";
            q = "{\"expression\":\"sin(x)\",\"diffVar\":\"x\",\"diffOrder\":1,\"simplifyExpressions\":false,\"showSteps\":false,\"latex\":\"\\\\dfrac{\\\\mathrm{d}}{\\\\mathrm{d}x}\\\\left(\\\\sin\\\\left(x\\\\right)\\\\right)\"}";
            Document differentialDoc = Jsoup.connect(url).data("q", q).data("v", "1380119305").post();
            System.out.println(differentialDoc);
            System.out.println("\n*******************************\n");

            //Calculus
            url = "http://calculus-calculator.com/calculation/integrate.php";
            Document calculusDoc = Jsoup.connect(url).data("expression", "sin(x)").data("intvar", "x").post();
            String outStr =     StringEscapeUtils.unescapeJava(calculusDoc.toString());
            Document formattedOutPut = Jsoup.parse(outStr);
            formattedOutPut.body().html(formattedOutPut.select("div.isteps").toString());
            System.out.println(formattedOutPut);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}