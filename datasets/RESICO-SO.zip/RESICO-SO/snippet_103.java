package main;

import com.google.common.base.CharMatcher;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;

public class TestMain {

    static Splitter split = Splitter.on(CharMatcher.anyOf(" #")).trimResults()
            .omitEmptyStrings();
    static Joiner join = Joiner.on(", ");

    public static void main(String[] args) {
        final String test = " A B # C#D# E # ";
        System.out.println(join.join(split.split(test)));
    }
}