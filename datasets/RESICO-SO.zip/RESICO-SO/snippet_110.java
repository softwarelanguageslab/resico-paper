package shell_structure;

import com.google.common.collect.Lists;

public class ClassShell {
    public static void main(String[] args) {
        ArrayList<String> getSymbolsPresent = Lists.newArrayList("item 1", "item 2");
    }
}
