package shell_structure;

import com.google.common.primitives.UnsignedBytes;

public class ClassShell {
    public static void main(String[] args) {
        UnsignedBytes.MAX_POWER_OF_TWO;
    }
}
