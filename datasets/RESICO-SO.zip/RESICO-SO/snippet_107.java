package shell_structure;
import org.apache.commons.lang3.SystemUtils;

class Something {
    public static void main(String[] args){     
        System.out.println(SystemUtils.JAVA_IO_TMPDIR);
    }
}