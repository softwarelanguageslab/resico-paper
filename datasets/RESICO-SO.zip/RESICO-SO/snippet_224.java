package shell_structure;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class Test {

    public static void main(String[] args) {

        Gson gson = new GsonBuilder().create();
        MessageBody messageBody = gson.fromJson(json, MessageBody.class);

        Map<String, DataField> addAttrs = (Map<String, DataField>) messageBody.getFields().get("additionalAttributes").getValue();
        System.out.println(addAttrs);
    }
}