package shell_structure;

import com.google.common.collect.Constraints;


public class ClassShell {
    public static void main(String[] args) {
        Constraints.constrainedList(new ArrayList(), Constraints.notNull());
    }
}
