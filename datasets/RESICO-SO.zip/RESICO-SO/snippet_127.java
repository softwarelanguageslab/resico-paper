package shell_structure;

import android.support.v4.app.FragmentTransaction;

public class ClassShell {
    public static void main(String[] args) {
        MyFragment myFragment = new MyFragment();
        FragmentTransaction ftx = getSupportFragmentManager().beginTransaction();

        ftx.replace(R.id.my_fragment_id, myFragment);

        ftx.commit();
    }
}
