package org.kodejava.example.hibernate.app;

import java.util.Date;
import org.hibernate.Session;

public class LabelManager {
    private Label getLabel(Long id) {
        Session session = SessionFactoryHelper.getSessionFactory().getCurrentSession();

        session.beginTransaction();

        /*
         * We get back Label object from database by calling the Session object
         * get() method and passing the object type and the object id to be
         * read.
         */
        Label label = (Label) session.get(Label.class, id);
        session.getTransaction().commit();

        return label;
    }

    private void saveLabel(Label label) {
        /*
         * To save an object we first get a session by calling getCurrentSession()
         * method from the SessionFactoryHelper class. Next we create a new
         * transcation, save the Label object and commit it to database,
         */
        Session session = SessionFactoryHelper.getSessionFactory().getCurrentSession();

        session.beginTransaction();        
        session.save(label);        
        session.getTransaction().commit();
    }

    public static void main(String[] args) {        
        LabelManager manager = new LabelManager();

        /*
         * Creates a Label object we are going to stored in the database. We
         * set the name, modified by and modified date information.
         */
        Label label = new Label();
        label.setName("Sony Music");
        label.setModifiedBy("admin");
        label.setModifiedDate(new Date());

        /*
         * Call the LabelManager saveLabel method.
         */
        manager.saveLabel(label);

        /*
         * Read the object back from database.
         */
        label = manager.getLabel(label.getId());
        System.out.println("Label = " + label);
    }    
}