package shell_structure;
import java.io.FileWriter;
import java.io.IOException;
import com.google.gson.Gson;

public class GsonExample {
    public static void main(String[] args) {

        Object obj = new Object();
        Gson gson = new Gson();
        String json = gson.toJson(obj); //convert 
        System.out.println(json);

    }
}