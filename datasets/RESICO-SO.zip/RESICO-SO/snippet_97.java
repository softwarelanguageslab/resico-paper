package shell_structure;
import com.google.common.base.Function;
import com.google.common.collect.Collections2;

public class Main {
    public static void main(String[] args) {
        List<Entity> entities;
        List<Long> ids = pluckIds(entities);
    }

    public static <E extends Entity> List<Long> pluckIds(List<E> list) {
        return new ArrayList<Long>(Collections2.transform(list, new Function<E, Long>() {
            public Long apply(E entity) {
                return entity.getId();
            }
        });
    }
}