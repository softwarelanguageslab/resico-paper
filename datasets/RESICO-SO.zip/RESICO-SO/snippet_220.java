package shell_structure;
import org.joda.time.DateTime;

public class CompareDateTimes {

  public static void main(String[] args) {

    // dt1 and dt2 have the same date and time
    DateTime dt1 = new DateTime();
    DateTime dt2 = new DateTime(dt1);

    // dt3 is one day later
    DateTime dt3 = new DateTime(dt2.plusDays(1));

    System.out.println("dt1.equals(dt2): " + dt1.equals(dt2));
    System.out.println("dt1.equals(dt3): " + dt1.equals(dt3));

    System.out.println("dt1.isAfter(dt3): " + dt1.isAfter(dt3));
    System.out.println("dt1.isBefore(dt3): " + dt1.isBefore(dt3));
  }
}