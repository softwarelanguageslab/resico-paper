package blog.jodatime;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.joda.time.DateTime;

public class DateTimeAdapter extends XmlAdapter<String, DateTime> {

    public DateTime unmarshal(String v) throws Exception {
        return DateTime.parse(v);
    }

    public String marshal(DateTime v) throws Exception {
        return v.toString();
    }

}