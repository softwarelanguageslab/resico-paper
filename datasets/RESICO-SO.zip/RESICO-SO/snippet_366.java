package com.mvc.javaclasses;

import com.google.gson.Gson;
import com.mvc.javaclassbeans.employee;
import com.mvc.javaclassbeans.employeeselect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.*;


public class Main {

    PreparedStatement ps;
    public String query;
    Statement stmt = null;

    public String selectfunction(employeeselect ob) throws ClassNotFoundException, SQLException {

        dbconnector dbc = new dbconnector();
        Connection connection = dbc.Open();

        List rows = new ArrayList();
        Map row = null;

        try {
            ResultSet resultSet = stmt.executeQuery(query);
            ResultSetMetaData metaData = resultSet.getMetaData();
            int numColumns = metaData.getColumnCount();

            while (resultSet.next()) {
                row = new HashMap();
                for (int i = 1; i < numColumns + 1; i++) {
                    row.put(metaData.getColumnName(i), resultSet.getObject(i));
                }
                rows.add(row);
            }

            resultSet.close();
        } catch (Exception e) {

        }
        String json = new Gson().toJson(rows);
        return json;
    }
}