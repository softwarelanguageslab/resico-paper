package shell_structure;

import com.google.common.html.HtmlEscapers;

public class ClassShell {
    public static void main(String[] args) {
        String source = "The less than sign (<) and ampersand (&) must be escaped before using them in HTML";
        String escaped = HtmlEscapers.htmlEscaper().escape(source);
    }
}
