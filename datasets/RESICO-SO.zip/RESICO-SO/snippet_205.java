package shell_structure;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class ItemsDetail extends Activity {

  int multiple=0;
  ImageView imageView;
  TextView tot_calories;

  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.items_details);
    Spinner mspin = (Spinner) findViewById(R.id.spinner1);
    Integer[] items = new Integer[]{1,2,3,4};

    ArrayAdapter<Integer> adapter = new ArrayAdapter<Integer>(this, android.R.layout.simple_spinner_item, items);
    mspin.setAdapter(adapter);

    TextView name_select = (TextView)findViewById(R.id.SelectedName);
    name_select.setText(constant.food_items[constant.SelectedIndex]);
    imageView = (ImageView) findViewById(R.id.imagedetail);
    UpdateImage(constant.food_items[constant.SelectedIndex]);
    TextView calories = (TextView)findViewById(R.id.calories111);
    calories.setText(constant.food_calories[constant.index]+"");

    tot_calories = (TextView)findViewById(R.id.caloriestotal);
    mspin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
      public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) { 
        // Your code here
        multiple=items[position]*constant.food_calories[constant.index];
      }
      public void onNothingSelected(AdapterView<?> adapterView) {
        return;
      } 
    });
    tot_calories.setText(""+multiple);
  }
}