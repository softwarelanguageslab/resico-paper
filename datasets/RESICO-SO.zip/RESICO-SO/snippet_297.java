package shell_structure;

import android.net.Uri;

public class ClassShell {
    public static void main(String[] args) {
        Uri uri=Uri.parse(url_string);
        uri.getQueryParameter("para1");
    }
}
