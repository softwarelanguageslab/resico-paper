package shell_structure;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class A {
  static Log log = LogFactory.getLog(A.class);

  void methodA(){
   try{
    log.info("I am inside A");
   } catch(Exception e) {
      log.error("error" , e);
     }
  }
}