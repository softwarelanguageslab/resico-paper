package shell_structure;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class ClassShell {
  public static void main(String[] args) {
    ResponseStatusException(HttpStatus.NOT_FOUND, "Collection not found");
  }
}
