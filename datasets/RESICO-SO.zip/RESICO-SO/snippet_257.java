package shell_structure;
import java.io.FileReader;
import java.util.ArrayList;

import com.google.gson.Gson;

public class Foo {
  public static void main(String[] args) throws Exception {
    Gson gson = new Gson();
    Person[] myTypes = gson.fromJson(new FileReader("input.json"), Person[].class);
    System.out.println(gson.toJson(myTypes));
  }
}

public class Person {    
    String name;
    int phone;
    String email;
}