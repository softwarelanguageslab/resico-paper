package shell_structure;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;


public class GsonExample {
    public static void main(String[] args) {
        String s= "[[\"110917\", 3.0099999999999998, -0.72999999999999998," +
                "2.8500000000000001, 2.96, 685.0, 38603.0], [\"110917\", 2.71," +
                "0.20999999999999999, 2.8199999999999998, 2.8999999999999999," +
                "2987.0, 33762.0]]";


        JsonParser  parser = new JsonParser();
        JsonElement elem   = parser.parse( s );

        JsonArray elemArr = elem.getAsJsonArray();
        System.out.println( elemArr );
    }
}