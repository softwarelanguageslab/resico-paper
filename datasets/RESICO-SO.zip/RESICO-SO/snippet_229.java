package shell_structure;
import org.apache.commons.lang3.RandomUtils;

public class RetryHelpTest {

    public static void main(String[] args) {
        for (int i = 0; i < 100; i++) {
            System.out.println("--------------");
            RetryHelp.build()
                    .tryWith(() -> {
                        System.out.println("hello world");
                        return RandomUtils.nextBoolean();
                    })
                    .tryInterval(1L)
                    .tryNum(3)
                    .elseThrow(() -> new RuntimeException("some thing wrong"))
                    .start();
        }
    }
}