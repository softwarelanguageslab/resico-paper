package shell_structure;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class ClassShell {
   public String toString() {
      return ReflectionToStringBuilder.toString(this);
   }
}
