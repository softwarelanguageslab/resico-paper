package shell_structure;
import java.util.Iterator;

import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.Widget;

public class WidgetValidator {

    private static void validateFlexTable(final FlexTable flextable) {
        for (int row = 0; row < flextable.getRowCount(); row++) {
            for (int column = 0; column < flextable.getCellCount(row); column++) {
                WidgetValidator.validateWidget(flextable.getWidget(row, column));
            }
        }
    }

    private static void validatePanel(final Panel panel) {
        final Iterator<Widget> iterator = panel.iterator();
        while (iterator.hasNext()) {
            WidgetValidator.validateWidget(iterator.next());
        }
    }

    public static void validateWidget(final Widget widget) {
        if (widget != null) {
            if (widget instanceof FlexTable) {
                WidgetValidator.validateFlexTable((FlexTable) widget);
            } else if (widget instanceof Panel) {
                WidgetValidator.validatePanel((Panel) widget);
            } else {
                System.out.println(widget.getElement().getId().replace("gwt-debug-", ""));
            }
        }
    }
}