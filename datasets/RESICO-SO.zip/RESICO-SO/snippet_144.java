package shell_structure;
import android.util.Log;

public class AppLogClass {

    public void e(String tag, String msg){
        if (BuildConfig.DEBUG) {
            Log.e(tag, msg);
        }
    }

    public void d(String tag, String msg){
        if (BuildConfig.DEBUG) {
            Log.d(tag, msg);
        }
    }
}