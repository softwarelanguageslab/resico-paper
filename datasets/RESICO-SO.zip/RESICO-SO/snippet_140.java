package org.spring.javabeans ;

import  org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawingApplication {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext appContext= new ClassPathXmlApplicationContext("Spring.xml");
        Triangle triangle = (Triangle) appContext.getBean("triangle");
        appContext.close();
        triangle.draw();
    }
}