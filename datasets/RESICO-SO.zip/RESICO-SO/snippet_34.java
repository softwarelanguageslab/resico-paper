package shell_structure;

import android.support.media.ExifInterface;

public class ClassShell {

  public static void main(String[] args) {
    try (InputStream inputStream = context.getContentResolver().openInputStream(uri)) {
          ExifInterface exif = new ExifInterface(inputStream);
          int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
