package shell_structure;

import com.google.common.collect.ImmutableList;

public class ClassShell {
    public static void main(String[] args) {
        List<List<Integer>> numbers = ImmutableList.<List<Integer>>of(
                ImmutableList.of(1, 2),
                ImmutableList.of(3, 4)
        );
    }
}
