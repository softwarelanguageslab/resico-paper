package shell_structure;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class MyGlobals {
    Context mContext;

    // Constructor
    public MyGlobals(Context context){
        this.mContext = context;
    }

    public boolean checkInternetConnection() {
        ConnectivityManager cm = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if ((cm != null) && (netInfo != null)) {
            if (netInfo.isConnected()) {
                return true;
            }
        }
        return false;
    }
}