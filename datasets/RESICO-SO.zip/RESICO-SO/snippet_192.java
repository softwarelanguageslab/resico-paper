package shell_structure;

import com.google.common.collect.Table;
import com.google.common.collect.TreeBasedTable;


public class ClassShell {
    public static void main(String[] args) {
        String in = "this + is - an * input";
        Table<Integer, String, String> table = TreeBasedTable.create();
        StringTokenizer stringTokenizer = new StringTokenizer(in, "+-*", true);

        int x = stringTokenizer.countTokens();

        for (int i = 0; i < x / 2; i++) {
            table.put(i, stringTokenizer.nextToken(),
                    stringTokenizer.nextToken());

        }
        if (stringTokenizer.hasMoreElements()) {
            table.put(x, stringTokenizer.nextToken(), "");
        }

        // iterate through tokens
        System.out.println(table.columnKeySet());
        // iterate thruogh delims
        System.out.println(table.values());
    }
}
