package shell_structure;

import org.apache.commons.lang3.JavaVersion;
import org.apache.commons.lang3.SystemUtils;


public class ClassShell {
    public static void main(String[] args) {
        if (SystemUtils.isJavaVersionAtLeast(JavaVersion.JAVA_1_8)
            System.out.println("Java version was 8 or greater!");
    }
}