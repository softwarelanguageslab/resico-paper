package shell_structure;

import android.util.Log;


public class Helper {
    public static void testAndroid() {
        Log.i(“Unity”, “test android”);
    }
}