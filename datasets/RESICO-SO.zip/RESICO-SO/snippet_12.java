package shell_structure;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.EclipseLinkJpaVendorAdapter;

public class Main {

    public static void main(String[] args) {
        LocalContainerEntityManagerFactoryBean bean =
                new LocalContainerEntityManagerFactoryBean();
        bean.setDataSource(new MyDataSource());
        bean.setPersistenceUnitName("TestPU");
        bean.setJpaVendorAdapter(new EclipseLinkJpaVendorAdapter());
        bean.afterPropertiesSet();

        EntityManagerFactory factory = bean.getNativeEntityManagerFactory();
        EntityManager em = factory.createEntityManager();
        em.getTransaction().begin();
        User user = new User();
        user.setFullname("Mister");
        em.persist(user);
        em.getTransaction().commit();
        em.close();
    }

}