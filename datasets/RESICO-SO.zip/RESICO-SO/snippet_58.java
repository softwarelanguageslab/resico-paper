package shell_structure;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class ClassShell {
    public static void main(String[] args) {

        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy/MM/dd HH:mm");
        DateTime d1 = formatter.parseDateTime(startDate);
        DateTime d2 = formatter.parseDateTime(endDate);

        Assert.assertTrue(d1.isBefore(d2));
        Assert.assertTrue(d2.isAfter(d1));
    }
}
