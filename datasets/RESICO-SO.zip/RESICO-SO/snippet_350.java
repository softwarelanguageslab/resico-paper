package shell_structure;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.util.StringUtils;

public class ClassShell {
  public static void main(String[] args) {

    if(CollectionUtils.isEmpty(tokens))
        return; // tests that the Collection parameter is neither null nor empty

    for(String token : tokens) {
      if(!StringUtils.hasText(token)) // tests that the String parameter is neither null nor empty
        return;
    }
  }
}
