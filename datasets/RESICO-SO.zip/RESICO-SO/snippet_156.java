package shell_structure;

import com.google.gson.GsonBuilder;

public class ClassShell {
    public static void main(String[] args) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        MeasurementsDTO measurementsDTO = gsonBuilder.create().fromJson(s1, MeasurementsDTO.class);
    }
}
