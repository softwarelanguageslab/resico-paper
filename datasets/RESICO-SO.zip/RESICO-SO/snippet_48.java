package shell_structure;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class YourClass{
    private static Log log = LogFactory.getLog(YourClass.class);

    public void yourMethod(){
        log.info("Your Message");
    }
}
