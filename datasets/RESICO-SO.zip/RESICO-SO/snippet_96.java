package shell_structure;

import org.apache.commons.lang3.exception.ExceptionUtils;

public class ClassShell {
    public static void main(String[] args) {
        String[] ss = ExceptionUtils.getRootCauseStackTrace(e);
        logger.error(StringUtils.join(ss, System.lineSeparator()));
    }
}
