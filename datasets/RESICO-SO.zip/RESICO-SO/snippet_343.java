package shell_structure;
import android.content.Context;
import android.net.Uri;
import android.util.Log;

import com.csehelper.variables.Constants;
import com.csehelper.variables.Keys;
import com.csehelper.variables.Url;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;

public class NetworkOps {
    public final String EXCEPTION = "~Exception~";
    /****************************
     * Method to Grab Source
     ****************************/
    public static String GrabSource(String URL) {
        return PostData(URL, null);
    }



    /**
     * *****************************************
     * Method to Grab Source code from URL
     * Posting Data
     * *****************************************
     */
    private static String PostData(String url, Uri.Builder uribuilder) {
        String Source;
        HttpURLConnection.setFollowRedirects(false);
        HttpURLConnection urlConnection = null;
        try {
            urlConnection = (HttpURLConnection) new URL(url).openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setConnectTimeout(10000);

            if(uribuilder != null) {
                String query = uribuilder.build().getEncodedQuery();

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
            }

            urlConnection.connect();

            if (urlConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {

                String line;
                StringBuilder builder = new StringBuilder();
                InputStreamReader isr = new InputStreamReader(
                        urlConnection.getInputStream());
                BufferedReader reader = new BufferedReader(isr);
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
                Source = builder.toString();
            } else {
                Source = EXCEPTION + "Server unreachable. Check network connection.";
            }
        } catch (SocketTimeoutException e) {
            Source = EXCEPTION + "Connection timed out.";
        } catch (java.net.UnknownHostException e) {
            Source = EXCEPTION + Constants.EXCEPTION_NO_NET;
        } catch (ArrayIndexOutOfBoundsException e) {
            Source = EXCEPTION + "Server error";
        } catch (ProtocolException e) {
            Source = EXCEPTION + "Protocol error";
        } catch (IOException e) {
            Source = EXCEPTION + "Server unreachable. Check network connection.";
        } catch (Exception e) {
            Source = EXCEPTION + "Error:" + e.toString() + " - "
                    + e.getMessage();
            e.printStackTrace();

        } finally {
            if (urlConnection != null) urlConnection.disconnect();
        }
        return Source;
    }
}