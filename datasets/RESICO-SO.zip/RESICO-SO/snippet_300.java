package shell_structure;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MultiHashMap;
import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.HashedMap;

public class TryingMultiMap {
    public Map<String, String> testMap(MultiMap m) {
        Map<String, String> m_copy = new HashMap();
        m_copy.putAll(m);
        System.out.println(m_copy);
        return m_copy;
    }

    public static void main(String[] args) {
        System.out.println("test");
        MultiMap m = new MultiHashMap();
        m.put("Bhaskar","Java");
        m.put("Bhaskar","Java");
        m.put("Ravi",".Net");
        m.put("Ravi", ".Net");
        m.put("Suyash","C++");
        System.out.println(m);

        Map exhibitMap= new HashMap();
        h.put("Bhaskar", "Java");
        h.put("Bhaskar", "Java");
        System.out.println("exhibitMap"+ExhibitMap);

        TryingMultiMap obj = new TryingMultiMap();
        obj.testMap(m);
    }
}