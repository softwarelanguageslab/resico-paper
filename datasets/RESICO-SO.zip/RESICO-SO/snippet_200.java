package com.rajesh.getselecteditem;
import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

  ArrayList<Position> listitems = new ArrayList<Position>();
  ListAdapter listAdapter;
  ListView lvMain;

  /** Called when the activity is first created. */
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
    lvMain = (ListView) findViewById(R.id.listview);

    arraylistvalueadding();
    listAdapter = new ListAdapter(this, listitems);

    lvMain.setAdapter(listAdapter);
  }

  void arraylistvalueadding() {
    for (int i = 1; i <= 20; i++) {
        listitems.add(new Position(i,false));
    }
  }
}