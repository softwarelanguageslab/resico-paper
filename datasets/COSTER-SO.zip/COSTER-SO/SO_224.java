package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_224 {
public void soCodeSnippet(){
if (nextLine == null) {
  return null;
}

List tokensOnThisLine=new ArrayList();

StringBuffer sb=new StringBuffer();

boolean inQuotes=false;

do {
  if (inQuotes) {
    sb.append("\n");
    nextLine=getNextLine();
    if (nextLine == null)     break;
  }
  for (int i=0; i < nextLine.length(); i++) {
    char c=nextLine.charAt(i);
    if (c == quotechar) {
      if (inQuotes && nextLine.length() > (i + 1) && nextLine.charAt(i + 1) == quotechar) {
        sb.append(nextLine.charAt(i + 1));
        i++;
      }
 else {
        inQuotes=!inQuotes;
        if (i > 2 && nextLine.charAt(i - 1) != this.separator && nextLine.length() > (i + 1) && nextLine.charAt(i + 1) != this.separator) {
          sb.append(c);
        }
      }
    }
 else     if (c == separator && !inQuotes) {
      tokensOnThisLine.add(sb.toString());
      sb=new StringBuffer();
    }
 else {
      sb.append(c);
    }
  }
}
 while (inQuotes);

tokensOnThisLine.add(sb.toString());

return (String[])tokensOnThisLine.toArray(new String[0]);

}
}
