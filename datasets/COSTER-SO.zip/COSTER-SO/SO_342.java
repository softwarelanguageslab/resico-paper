package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_342 {
public void soCodeSnippet(){
if (this == obj) {
  return true;
}

if (obj == null) {
  return false;
}

if (getClass() != obj.getClass()) {
  return false;
}

GenericTreeNode<?> other=(GenericTreeNode<?>)obj;

if (data == null) {
  if (other.data != null) {
    return false;
  }
}
 else if (!data.equals(other.data)) {
  return false;
}

return true;

}
}
