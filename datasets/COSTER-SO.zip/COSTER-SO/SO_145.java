package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_145 {
public void soCodeSnippet(){
if (!hasNext()) {
  return;
}

Map<String,String> parameters=new HashMap<String,String>();

parameters.put("csrf_token",ctx.getCsrfToken());

parameters.put("offset",Integer.toString(offset));

parameters.put("sorting",sorting);

if (period != null) {
  parameters.put("period",period.toString());
}

if (unread != null) {
  parameters.put("unread",unread.toString());
}

offset=httpClient.loadContent(uri,parameters,parser);

}
}
