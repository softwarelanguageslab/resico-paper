package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_407 {
public void soCodeSnippet(){
FormLayout centreLayout=new FormLayout();

PanelBuilder tempbuilder=new PanelBuilder(centreLayout);

tempbuilder.appendRow("$row");

tempbuilder.appendGlueColumn();

CellConstraints cc=new CellConstraints();

int x=2;

int y=1;

for (JComponent comp : components) {
  tempbuilder.appendColumn("$lbl");
  tempbuilder.appendColumn("$columngap");
  tempbuilder.add(comp,cc.xy(x,y));
  x+=2;
}

tempbuilder.appendGlueColumn();

int tempstartcol=startCol == -1 ? col : startCol;

JPanel temppanel=tempbuilder.getPanel();

temppanel.setBackground(bgColor);

builder.add(temppanel,cc.xyw(tempstartcol,row,colSpan));

return this;

}
}
