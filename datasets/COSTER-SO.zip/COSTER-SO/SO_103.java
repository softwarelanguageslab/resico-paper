package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_103 {
public void soCodeSnippet(){
super.paint(g);

Graphics2D g2D=(Graphics2D)g;

g2D.setColor(Color.black);

if (board != null) {
  boardBox=new Rectangle2D.Double(0,0,Board.toScreenSpace(board.getWidth()),Board.toScreenSpace(board.getHeight()));
  g2D.fillRect((int)boardBox.getX(),(int)boardBox.getY(),(int)boardBox.getWidth(),(int)boardBox.getHeight());
}

g2D.setColor(Color.red);

if (engine != null && board.getPlanes() != null) {
  ArrayList<Plane> planes=board.getPlanes();
  for (int i=0; i < planes.size(); i++) {
    if (planes.get(i).getBearing() != -2) {
      g2D.setColor(colors[i % colors.length]);
      if (planes.get(i).isOn(engine.getCurrentRound())) {
        g2D.drawOval((int)Board.toScreenSpace(planes.get(i).getX() - GameConfig.SAFETY_RADIUS),(int)Board.toScreenSpace(planes.get(i).getY() - GameConfig.SAFETY_RADIUS),(int)Board.toScreenSpace(GameConfig.SAFETY_RADIUS * 2),(int)Board.toScreenSpace(GameConfig.SAFETY_RADIUS * 2));
        for (int j=0; j < planes.get(i).getHistory().size() - 1; j++) {
          Point2D.Double start=planes.get(i).getHistory().get(j);
          Point2D.Double end=planes.get(i).getHistory().get(j + 1);
          int drawXstart=(int)Board.toScreenSpace(start.x);
          int drawYstart=(int)Board.toScreenSpace(start.y);
          int drawXend=(int)Board.toScreenSpace(end.x);
          int drawYend=(int)Board.toScreenSpace(end.y);
          g2D.drawLine(drawXstart,drawYstart,drawXend,drawYend);
        }
      }
    }
  }
}

if (engine != null && board.getPlanes() != null) {
  ArrayList<Plane> planes=board.getPlanes();
  for (int i=0; i < planes.size(); i++) {
    if (planes.get(i).getBearing() != -2) {
      g2D.setColor(colors[i % colors.length]);
      if (planes.get(i).isOn(engine.getCurrentRound())) {
        g2D.fillOval((int)Board.toScreenSpace(planes.get(i).getX() - .5),(int)Board.toScreenSpace(planes.get(i).getY() - .5),(int)Board.toScreenSpace(1),(int)Board.toScreenSpace(1));
      }
 else       g2D.drawOval((int)Board.toScreenSpace(planes.get(i).getX() - .5),(int)Board.toScreenSpace(planes.get(i).getY() - .5),(int)Board.toScreenSpace(1),(int)Board.toScreenSpace(1));
    }
  }
}

if (engine != null && board.getAirports() != null) {
  for (  Airport c : board.getAirports()) {
    g2D.setColor(Color.WHITE);
    g2D.fillOval((int)Board.toScreenSpace(c.getX() - Airport.DIAMETER / 2),(int)Board.toScreenSpace(c.getY() - Airport.DIAMETER / 2),(int)Board.toScreenSpace(Airport.DIAMETER),(int)Board.toScreenSpace(Airport.DIAMETER));
  }
}

g2D.setStroke(new BasicStroke(1));

if (debugLine != null) {
  g2D.setColor(Color.orange);
  g2D.drawLine((int)Board.toScreenSpace(debugLine.getX1()),(int)Board.toScreenSpace(debugLine.getY1()),(int)Board.toScreenSpace(debugLine.getX2()),(int)Board.toScreenSpace(debugLine.getY2()));
}

if (curCursor != null) setCursor(curCursor);

}
}
