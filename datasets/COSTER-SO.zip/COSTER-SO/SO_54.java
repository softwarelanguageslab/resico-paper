package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_54 {
public void soCodeSnippet(){
TerrainService t=new TerrainContract(new TerrainImpl());

t.init(1000,10,5);

System.err.println("res " + t.getBloc(0,0,0));

BlocService b=new BlocContract(new BlocImpl());

ObjetService tresor=new ObjetContract(new ObjetImpl());

tresor.init(Tresor.UNDOLLAR);

b.init(Type.FOSSE,tresor);

t.setBloc(0,0,0,b);

System.err.println("res " + t.getBloc(0,0,0));

}
}
