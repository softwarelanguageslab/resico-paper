package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_130 {
public void soCodeSnippet(){
in.beginObject();

Map<String,String> values=new HashMap<>();

String site=null;

Integer id=null;

while (in.hasNext()) {
  String key=in.nextName();
  if (key.equals(siteToken)) {
    site=in.nextString();
  }
 else   if (key.equals(dataToken)) {
    id=in.nextInt();
  }
 else {
    values.put(key,in.nextString());
  }
}

in.endObject();

return new PersonalData(site,id,values);

}
}
