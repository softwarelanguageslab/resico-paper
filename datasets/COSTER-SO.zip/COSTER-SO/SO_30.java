package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_30 {
public void soCodeSnippet(){
String tooltip=jcomponent.getToolTipText();

if (StringUtils.isEmpty(tooltip)) {
  tooltip="<html>" + errortooltip + "</html>";
}
 else {
  if (tooltip.contains("<html>")) {
    tooltip=tooltip.replace(Pattern.quote("<html>"),Matcher.quoteReplacement("<html>" + errortooltip + "<br/>"));
  }
 else {
    tooltip="<html>" + errortooltip + "<br/>"+ tooltip+ "</html>";
  }
}

jcomponent.setToolTipText(tooltip);

jcomponent.setBorder(BorderFactory.createLineBorder(Color.red));

if (jcomponent instanceof JCheckBox) {
  ((JCheckBox)jcomponent).setBorderPainted(true);
}

}
}
