package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_70 {
public void soCodeSnippet(){
setupEventListeners();

thread=new Thread(new Runnable(){
  @Override public void run(){
    while (true) {
      try {
        Logger.getInstance().info("RPC thread (re)started");
        EventBusFactory.getDefault().fire(new RpcThreadStartedEvent());
        EventBusFactory.getDefault().fire(new ConnectionEstablishedEvent());
        while (true) {
          Logger.getInstance().info("executeNext");
          executeNext();
        }
      }
 catch (      InterruptedException e) {
      }
    }
  }
}
,"RPC worker");

clientConfig=new XmlRpcClientConfigImpl();

client=new XmlRpcClient();

client.setTypeFactory(new ESTypeFactoryImpl(client));

loadConfig();

thread.start();

}
}
