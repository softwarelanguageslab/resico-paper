package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_108 {
public void soCodeSnippet(){
URL url=new URL(urlStr);

BufferedReader reader=null;

StringBuffer xmlStr=new StringBuffer();

try {
  reader=new BufferedReader(new InputStreamReader(url.openStream()));
  String temp=null;
  while ((temp=reader.readLine()) != null) {
    xmlStr.append(temp);
  }
}
 catch (Exception e) {
  e.printStackTrace();
}
 finally {
  reader.close();
}

return xmlStr.toString();

}
}
