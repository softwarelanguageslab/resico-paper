package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_190 {
public void soCodeSnippet(){
log.debug("Requested Url :" + request.getURL());

XMLConfiguration xmlResponse=null;

HttpURLConnection conn=(HttpURLConnection)new URL(request.getURL()).openConnection();

conn.setRequestMethod("POST");

long opStartTime=System.currentTimeMillis();

Properties headerProps=request.getHeaderProperties();

for (String propName : headerProps.stringPropertyNames()) {
  conn.setRequestProperty(propName,headerProps.getProperty(propName));
}

conn.setDoInput(true);

conn.setDoOutput(true);

DataOutputStream dos=null;

FileInputStream fis=null;

File file=new File(fileName);

try {
  dos=new DataOutputStream(conn.getOutputStream());
  String lineEnd="\r\n";
  String twoHyphens="--";
  dos.writeBytes(twoHyphens + QcRequest.BOUNDARY + lineEnd);
  dos.writeBytes("Content-Disposition: form-data; name=\"file\";filename=\"" + file.getName() + "\""+ lineEnd);
  dos.writeBytes(lineEnd);
  int maxBufferSize=1 * 1024 * 1024;
  fis=new FileInputStream(new File(fileName));
  int bytesAvailable=fis.available();
  int bufferSize=Math.min(bytesAvailable,maxBufferSize);
  byte[] buffer=new byte[bufferSize];
  while (fis.read(buffer,0,bufferSize) > 0) {
    dos.write(buffer,0,bufferSize);
    bytesAvailable=fis.available();
    bufferSize=Math.min(bytesAvailable,maxBufferSize);
  }
  dos.writeBytes(lineEnd);
  dos.writeBytes(twoHyphens + QcRequest.BOUNDARY + twoHyphens+ lineEnd);
}
 catch (Exception ex) {
  log.error("Got exception while uploading file",ex);
}
 finally {
  try {
    if (fis != null) {
      fis.close();
    }
  }
 catch (  IOException ioe) {
    log.error("Got exception while closing file input stream :" + ioe);
  }
  try {
    if (dos != null) {
      dos.flush();
      dos.close();
    }
  }
 catch (  IOException ioe) {
    log.error("Got exception while closing output stream :" + ioe);
  }
}

if (conn.getResponseCode() == HttpURLConnection.HTTP_CREATED) {
  xmlResponse=new XMLConfiguration();
  xmlResponse.load(conn.getInputStream());
}
 else {
  QcException qcException=new QcException("Response code :" + conn.getResponseCode() + ", Error message :"+ QcUtil.readData(conn.getErrorStream()));
  throw qcException;
}

long opEndTime=System.currentTimeMillis();

log.debug("Time taken to process QC request: {} secs",(opEndTime - opStartTime) / 1000);

if (log.isTraceEnabled()) {
  log.trace("UPLOAD Response XML data :\n" + ConfigurationUtils.toString(xmlResponse));
}

log.info("Log file result data =" + QcXmlConfigUtil.getLogFileInfo(xmlResponse));

return xmlResponse;

}
}
