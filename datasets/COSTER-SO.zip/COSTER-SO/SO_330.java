package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_330 {
public void soCodeSnippet(){
int largeur=10;

int hauteur=50;

int profondeur=20;

int largeurBloc=5;

int hauteurBloc=25;

int profondeurBloc=-10;

Type myType=Type.VIDE;

Tresor myTresor=Tresor.CHAINEDEVELO;

System.out.println(SpecTestStrings.SPEC_TEST_NAME + new Object(){
}
.getClass().getEnclosingMethod().getName());

System.out.println(SpecTestStrings.SPEC_TEST_COND_INIT);

System.out.println("terrain.init(" + largeur + ", "+ hauteur+ ", "+ profondeur+ ");");

terrain.init(largeur,hauteur,profondeur);

System.out.println("bloc.init(" + myType + ", tresor);");

bloc.init(myType,objet);

System.out.println("objet.init(" + myTresor + ");");

objet.init(myTresor);

System.out.println(SpecTestStrings.SPEC_TEST_OPERATIONS);

System.out.println(SpecTestStrings.SPEC_TEST_ORACLE);

System.out.println("fail");

try {
  terrain.setBloc(largeurBloc,hauteurBloc,profondeurBloc,bloc);
  assertTrue(false);
}
 catch (ContractError e) {
  assertTrue(true);
}

}
}
