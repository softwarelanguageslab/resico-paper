package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_418 {
public void soCodeSnippet(){
FieldError err=null;

Session session=HibernateUtil.getSessionFactory().getCurrentSession();

session.getTransaction().begin();

Query query=session.createQuery("from FieldError where id = :id ");

query.setParameter("id",code);

List list=query.list();

if (!list.isEmpty()) {
  err=(FieldError)list.get(0);
}

return err;

}
}
