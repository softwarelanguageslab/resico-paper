package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_137 {
public void soCodeSnippet(){
TestRunInfo testRunInfo=null;

String qcTestName=map2QcTestName(testMethodResult);

String qcTestInstanceName=map2QcTestInstanceName(testMethodResult);

List<String> logFiles=getUploadLogFiles(testMethodResult);

QcTestStatus qcStatus=null;

if (testngQcStatusValues.containsKey(finalStatus)) {
  qcStatus=testngQcStatusValues.get(finalStatus);
}
 else {
  log.warn("Unable to match testng result to QC :{}, assigning default QC status FAILED",finalStatus);
  qcStatus=QcTestStatus.FAILED;
}

TestInstanceInfo testInstanceInfo=QcUtil.findTestInstance(this.testInstances,qcTestName,qcTestInstanceName,null);

if (testInstanceInfo != null) {
  log.info("Test instance id for test {}: {}",qcTestName,testInstanceInfo.getId());
  testRunInfo=new TestRunInfo();
  testRunInfo.setTestInstanceId(testInstanceInfo.getId());
  testRunInfo.setStatus(qcStatus);
  testRunInfo.setClientLogFilePaths(logFiles);
  testRunInfo.setUserId(QcConstants.QC_USERID);
  testRunInfo.setBuildNumbers(QcConstants.QC_BUILD_NUMBERS);
}
 else {
  log.error("No test instance found for test :" + qcTestName);
}

return testRunInfo;

}
}
