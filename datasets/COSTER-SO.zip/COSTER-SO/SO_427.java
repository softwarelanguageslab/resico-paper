package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_427 {
public void soCodeSnippet(){
if (rows == null) {
  return;
}

Arrays.sort(rowsToBeDel);

List<T> newrows=new ArrayList<T>();

for (int i=0; i < rows.size(); i++) {
  if (Arrays.binarySearch(rowsToBeDel,i) < 0) {
    newrows.add(rows.get(i));
  }
}

rows=newrows;

if (rows.isEmpty()) {
  fireTableDataChanged();
}
 else {
  fireTableRowsDeleted(rowsToBeDel[0],rowsToBeDel[rowsToBeDel.length - 1]);
}

}
}
