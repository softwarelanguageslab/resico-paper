package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_102 {
public void soCodeSnippet(){
System.out.println("@Test: testAmountDeposit");

List<COIN> coins=COIN.getCoinsForAmount(50.97f);

System.out.println("coins = " + coins);

for (COIN coin : coins) piggyBank.deposit(coin);

System.out.println("Current Balance = " + piggyBank.getCurrentBalance());

}
}
