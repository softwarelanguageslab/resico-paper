package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_320 {
public void soCodeSnippet(){
ResourceType resourceType=null;

Session session=HibernateUtil.getSessionFactory().getCurrentSession();

session.getTransaction().begin();

Query query=session.createQuery("from ResourceType where id = :id ");

query.setParameter("id",code);

List list=query.list();

if (!list.isEmpty()) {
  resourceType=(ResourceType)list.get(0);
}

return resourceType;

}
}
