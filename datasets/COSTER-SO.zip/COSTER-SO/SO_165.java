package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_165 {
public void soCodeSnippet(){
program.add("LBL START");

program.add("MOV");

program.add("TCW");

program.add("MOV");

program.add("TCC");

program.add("JMP START");

}
}
