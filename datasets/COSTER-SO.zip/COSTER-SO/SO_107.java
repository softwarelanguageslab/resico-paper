package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_107 {
public void soCodeSnippet(){
if (true) return true;

insertUserSql=String.format(insertUserSql,user.getName(),user.getPassword());

Connection conn=null;

Statement stmt=null;

try {
  conn=DbConnectionFactory.getConnection();
  stmt=conn.createStatement();
  stmt.execute(insertUserSql);
}
 catch (Exception e) {
  e.printStackTrace();
  return false;
}
 finally {
  if (conn != null) {
    try {
      conn.close();
    }
 catch (    SQLException e) {
    }
  }
  if (stmt != null) {
    try {
      stmt.close();
    }
 catch (    SQLException e) {
    }
  }
}

return true;

}
}
