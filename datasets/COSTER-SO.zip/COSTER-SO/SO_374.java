package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_374 {
public void soCodeSnippet(){
switch (buttonSet) {
case OK:
  buttonOK.setVisible(true);
buttonCancel.setVisible(false);
break;
case CANCEL:
buttonOK.setVisible(false);
buttonCancel.setVisible(true);
break;
case OK_CANCEL:
buttonOK.setVisible(true);
buttonCancel.setVisible(true);
break;
}

setTitle(title);

setMessage(message);

pack();

setLocationRelativeTo(null);

setVisible(true);

}
}
