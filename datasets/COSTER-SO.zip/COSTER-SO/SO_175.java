package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_175 {
public void soCodeSnippet(){
if (nodeName == null) {
  return WebUtil.error("node name is null!");
}

String[] strs=nodeName.split("\\.");

TItem item=findItem(strs);

if (item != null) {
  return WebUtil.failedJSON("add node:" + nodeName + " failed,node is exists!");
}

String newNodeName=strs[strs.length - 1];

String[] newStrs=new String[strs.length - 1];

for (int i=0; i < strs.length - 1; i++) {
  newStrs[i]=strs[i];
}

item=findItem(newStrs);

if (item == null) {
  return WebUtil.failedJSON("add node:" + nodeName + " failed,parent node is not exists!");
}

TItem newItem=new TItem();

newItem.setName(newNodeName);

item.addSubItem(newItem);

return WebUtil.oKJSON();

}
}
