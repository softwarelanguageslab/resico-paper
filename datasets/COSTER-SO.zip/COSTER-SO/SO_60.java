package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_60 {
public void soCodeSnippet(){
PersonStatistics ret=new PersonStatistics(first,last);

Set<String> attributeSkip=new HashSet<>();

cleanLocation: {
  OrderTable locationAttributeOrder=new OrderTable();
  List<String> locAttr=new ArrayList<>();
  Set<String> allLocAttr=new HashSet<>();
  for (  PersonalData clean : cleaned) {
    for (    String attr : clean.keySet()) {
      if (attr.startsWith("L"))       locAttr.add(attr);
    }
    allLocAttr.addAll(locAttr);
    locationAttributeOrder.addInOrder(locAttr);
    locAttr.clear();
  }
  Set<String> tmp=new TreeSet<>(locationAttributeOrder);
  tmp.addAll(allLocAttr);
  attributeSkip.addAll(allLocAttr);
  allLocAttr=tmp;
  for (  String attribute : allLocAttr) {
    ret.put("O" + attribute,generateAttributeStat(attribute,cleaned));
  }
}

Set<String> attributes=new LinkedHashSet<>();

for (PersonalData data : cleaned) {
  attributes.addAll(data.keySet());
}

attributes.removeAll(attributeSkip);

for (String attribute : attributes) {
  ret.put(attribute,generateAttributeStat(attribute,cleaned));
}

return ret;

}
}
