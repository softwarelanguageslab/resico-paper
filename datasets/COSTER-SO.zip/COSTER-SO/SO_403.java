package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_403 {
public void soCodeSnippet(){
int result=-1;

String strURL="http://" + host + ":"+ port+ "/api/"+ resourceType+ "?_format=xml&resource_type="+ resourceType;

HttpPost post=new HttpPost(strURL);

try {
  data=data.replace("fhir:","");
  StringEntity entity=new StringEntity(data);
  post.setEntity(entity);
  post.addHeader("Content-type","text/xml");
  UsernamePasswordCredentials creds=new UsernamePasswordCredentials(username,password);
  post.addHeader(BasicScheme.authenticate(creds,"US-ASCII",false));
  DefaultHttpClient httpclient=new DefaultHttpClient();
  CloseableHttpResponse httpResponse=httpclient.execute(post);
  result=httpResponse.getStatusLine().getStatusCode();
  HttpEntity entity2=httpResponse.getEntity();
  StringWriter writer=new StringWriter();
  IOUtils.copy(entity2.getContent(),writer);
  this.response=writer.toString();
  EntityUtils.consume(entity2);
  Header[] headers=post.getHeaders("Location");
  if (headers.length > 0) {
    this.location=headers[0];
  }
}
 catch (ConnectException e) {
  throw e;
}
catch (IOException e) {
  e.printStackTrace();
}
 finally {
  post.releaseConnection();
}

return result;

}
}
