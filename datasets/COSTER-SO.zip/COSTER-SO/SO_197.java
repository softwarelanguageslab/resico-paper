package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_197 {
public void soCodeSnippet(){
System.out.println("Does 'java.library.path' include 'lib' path? ");

System.out.println(System.getProperty("java.library.path"));

System.out.println("R_HOME=" + System.getenv("R_HOME"));

System.out.println("LD_LIBRARY_PATH=" + System.getenv("LD_LIBRARY_PATH"));

System.out.println("R_INCLUDE_DIR=" + System.getenv("R_INCLUDE_DIR"));

System.out.println("R_SHARE_DIR=" + System.getenv("R_SHARE_DIR"));

System.out.println("R_DOC_DIR=" + System.getenv("R_DOC_DIR"));

System.out.println("R_LIBS_USER=" + System.getenv("R_LIBS_USER"));

this.r=REngineFacade.getInstance();

}
}
