package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_169 {
public void soCodeSnippet(){
System.out.println("Select project");

System.out.println("=======================");

System.out.println("\tq: Quit");

System.out.println("\t0: None");

for (int i=0; i < projects.size(); i++) {
  Project project=projects.get(i);
  System.out.println("\t" + (i + 1) + ": "+ project.getName());
}

Scanner scan=new Scanner(System.in);

String option="";

while (true) {
  System.out.print("\nChoose project number:");
  option=scan.next();
  if (option.equalsIgnoreCase("q")) {
    System.out.println("Good bye!");
    System.exit(0);
  }
  if (!Pattern.matches("[0-9]+",option)) {
    System.out.println("You must enter a number");
    continue;
  }
  int index=Integer.parseInt(option);
  if (index < 0 || index > projects.size()) {
    System.out.println("Option out of range");
    continue;
  }
  if (index == 0)   return null;
  return projects.get(index - 1);
}

}
}
