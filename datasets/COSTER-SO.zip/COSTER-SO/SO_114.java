package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_114 {
public void soCodeSnippet(){
long deltaTime=1000;

timeUnit=TimeUnit.MILLISECONDS;

startTime=new Date(System.currentTimeMillis() - deltaTime * 10);

unboundTS=new TimeSeries<Double>(startTime,deltaTime,timeUnit);

bounds=3;

boundedTS=new TimeSeries<Integer>(startTime,deltaTime,timeUnit,this.bounds);

}
}
