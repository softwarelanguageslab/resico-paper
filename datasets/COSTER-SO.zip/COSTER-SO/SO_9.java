package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_9 {
public void soCodeSnippet(){
calendar.set(Calendar.DAY_OF_MONTH,day);

setSelectedDate(calendar.getTime());

this.setChanged();

this.notifyObservers(selectedDate);

if (closeOnSelect) {
  screen.dispose();
  screen.setVisible(false);
}

}
}
