package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_353 {
public void soCodeSnippet(){
new SwingObjectException("Error while deleting",e,ErrorSeverity.SEVERE,FileHelper.class);

String message=e.getMessage();

if (message.indexOf("\\") != -1) {
  message=message.replaceAll(Pattern.quote("\\"),Matcher.quoteReplacement("/"));
}

int option=JOptionPane.showConfirmDialog(null,String.format("Unable to delete folder %s.\nPlease close to proceed.",folder.getAbsolutePath()),"Warning",JOptionPane.DEFAULT_OPTION);

if (option == JOptionPane.YES_OPTION) {
  deleteFolderWaitIfOpen(folder);
}

}
}
