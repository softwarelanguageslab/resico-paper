package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_331 {
public void soCodeSnippet(){
ArrayList<String> list=new ArrayList<String>();

Object[] oArray=statesList.getSelectedValues();

for (Object o : oArray) {
  list.add((String)o);
}

StateFilter newStateFilter=null;

if (list.contains("All")) {
  newStateFilter=StateFilter.getStateFilterAll();
}
 else {
  if (list.contains("Running")) {
    newStateFilter=StateFilter.getStateFilterRunning();
  }
  if (list.contains("Stopped")) {
    newStateFilter=StateFilter.getStateFilterStopped();
  }
  if (list.contains("Done")) {
    newStateFilter=StateFilter.getStateFilterDone();
  }
}

eventBus.fire(new StateFilterChangedEvent(newStateFilter));

}
}
