package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_162 {
public void soCodeSnippet(){
StringBuffer newType=new StringBuffer("L");

Matcher wordDelimiterMatcher=WORD_DELIMITER_PATTERN.matcher(typeName);

while (wordDelimiterMatcher.find()) {
  String firstLetter=wordDelimiterMatcher.group(1);
  wordDelimiterMatcher.appendReplacement(newType,firstLetter.toUpperCase());
}

wordDelimiterMatcher.appendTail(newType);

return newType.toString();

}
}
