package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_234 {
public void soCodeSnippet(){
continueSimulation=true;

ArrayList<Plane> simPlanes=new ArrayList<Plane>();

for (Plane p : planes) {
  simPlanes.add(new Plane(p));
}

double simBearings[]=new double[simPlanes.size()];

for (int i=0; i < simBearings.length; i++) {
  simBearings[i]=simPlanes.get(i).getBearing();
}

int landed=0;

for (double b : simBearings) {
  if (b == -2)   landed++;
}

while (landed != simBearings.length && continueSimulation) {
  round++;
  simBearings=simulateUpdate(simPlanes,round,simBearings);
  if (simBearings == null)   return -1 * round;
  for (int i=0; i < simPlanes.size(); i++) {
    if (simPlanes.get(i).getDepartureTime() > round && simBearings[i] > -1) {
      return -1 * round;
    }
  }
  for (int i=0; i < simPlanes.size(); i++) {
    Plane p=simPlanes.get(i);
    if (simBearings[i] >= 0) {
      if (p.move(simBearings[i])) {
        if (p.getLocation().distance(p.getDestination()) < 0.5) {
          p.setBearing(-2);
          simBearings[i]=-2;
          landed++;
        }
      }
    }
  }
  for (  Plane l1 : simPlanes) {
    for (    Plane l2 : simPlanes) {
      if (!l1.equals(l2) && l1.getBearing() != -2 && l1.getBearing() != -1 && l2.getBearing() != -2 && l2.getBearing() != -1) {
        if (l1.getLocation().distance(l2.getLocation()) < GameConfig.SAFETY_RADIUS)         return -1 * round;
      }
    }
  }
}

return round;

}
}
