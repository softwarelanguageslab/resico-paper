package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_413 {
public void soCodeSnippet(){
Iterator<String> keys=jo.keys();

String string;

StringBuilder sb=new StringBuilder();

if (jo.has("Status-Code") && jo.has("Reason-Phrase")) {
  sb.append(jo.getString("HTTP-Version"));
  sb.append(' ');
  sb.append(jo.getString("Status-Code"));
  sb.append(' ');
  sb.append(jo.getString("Reason-Phrase"));
}
 else if (jo.has("Method") && jo.has("Request-URI")) {
  sb.append(jo.getString("Method"));
  sb.append(' ');
  sb.append('"');
  sb.append(jo.getString("Request-URI"));
  sb.append('"');
  sb.append(' ');
  sb.append(jo.getString("HTTP-Version"));
}
 else {
  throw new JSONException("Not enough material for an HTTP header.");
}

sb.append(CRLF);

while (keys.hasNext()) {
  string=keys.next();
  if (!"HTTP-Version".equals(string) && !"Status-Code".equals(string) && !"Reason-Phrase".equals(string)&& !"Method".equals(string)&& !"Request-URI".equals(string)&& !jo.isNull(string)) {
    sb.append(string);
    sb.append(": ");
    sb.append(jo.getString(string));
    sb.append(CRLF);
  }
}

sb.append(CRLF);

return sb.toString();

}
}
