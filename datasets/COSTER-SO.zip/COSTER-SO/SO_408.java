package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_408 {
public void soCodeSnippet(){
prop=field.get(container);

if (prop == null) {
  return false;
}

isJComponent=false;

if (Components.class.isAssignableFrom(prop.getClass())) {
  return true;
}
 else if (JComponent.class.isAssignableFrom(field.getType())) {
  isJComponent=true;
  return true;
}

return false;

}
}
