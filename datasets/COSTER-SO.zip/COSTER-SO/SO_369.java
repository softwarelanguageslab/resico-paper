package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_369 {
public void soCodeSnippet(){
System.out.println("Begin HoltWinter ...");

this.r.loadLibrary("graphics");

System.out.println(this.r.rEvalSync("hw=HoltWinters(co2)").getContent());

System.out.println(this.r.rEvalSync("hw$a").asDouble());

System.out.println(this.r.rEvalSync("5").asDouble());

System.out.println("End HoltWinter ...");

}
}
