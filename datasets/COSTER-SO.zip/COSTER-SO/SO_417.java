package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_417 {
public void soCodeSnippet(){
List<TestResultData> testNgResultData=parseTestNgResultFromFilesOrUrls(urlsOrFiles);

List<String> testNgTests=(List<String>)CollectionUtils.collect(testNgResultData,new BeanToPropertyValueTransformer("testName"));

Collections.sort(testNgTests);

File csvFile=new File("testNgDdTests.csv");

BufferedWriter bw=null;

try {
  bw=new BufferedWriter(new FileWriter(csvFile));
  for (  String testNgTestName : testNgTests) {
    if (testNgTestName.contains("-")) {
      bw.write("com.vmware.qe.vcloud.tests.server." + testNgTestName);
      bw.write("\n");
    }
  }
}
 catch (Exception e) {
  throw e;
}
 finally {
  try {
    bw.close();
  }
 catch (  Exception e) {
    e.printStackTrace();
  }
}

}
}
