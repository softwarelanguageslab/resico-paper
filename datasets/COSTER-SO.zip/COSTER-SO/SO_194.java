package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_194 {
public void soCodeSnippet(){
String now=(new Date()).toString();

logger.info("Returning hello view with " + now);

Map<String,Object> myModel=new HashMap<String,Object>();

myModel.put("now",now);

myModel.put("products",this.productManager.getProducts());

return new ModelAndView("hello","model",myModel);

}
}
