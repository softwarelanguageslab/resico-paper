package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_366 {
public void soCodeSnippet(){
if (!QcUtil.isEmpty(configData.getString("qc.testset.id"))) {
  this.qcTestSetId=configData.getLong("qc.testset.id");
}

if (!QcUtil.isEmpty(configData.getString("qc.testset.name"))) {
  this.qcTestSetName=configData.getString("qc.testset.name");
}

this.enableTestLogUpload=configData.getBoolean("qc.testlog.upload.enable");

this.uploadAllTestLogs=configData.getBoolean("qc.upload.testlog.all");

testngQcStatusValues.put(ITestResult.FAILURE,QcTestStatus.FAILED);

testngQcStatusValues.put(ITestResult.SKIP,QcTestStatus.NOT_COMPLETED);

testngQcStatusValues.put(ITestResult.SUCCESS,QcTestStatus.PASSED);

}
}
