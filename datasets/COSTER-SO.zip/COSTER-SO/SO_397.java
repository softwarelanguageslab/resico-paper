package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_397 {
public void soCodeSnippet(){
List<NameValuePair> nvps=new ArrayList<NameValuePair>();

HttpPost httpPost=new HttpPost(LOGON_SITE);

BasicCookieStore cookieStore=new BasicCookieStore();

CloseableHttpClient httpclient=HttpClients.custom().setDefaultCookieStore(cookieStore).build();

NameValuePair nameValuePair1=new BasicNameValuePair("username","lqy3411");

NameValuePair nameValuePair2=new BasicNameValuePair("password","liangqingyu1229");

nvps.add(nameValuePair1);

nvps.add(nameValuePair2);

httpPost.setHeaders(headers);

try {
  httpPost.setEntity(new UrlEncodedFormEntity(nvps,"utf-8"));
  HttpResponse response=httpclient.execute(httpPost);
  HttpEntity entity=response.getEntity();
  System.out.println("Login form get: " + response.getStatusLine());
  EntityUtils.consume(entity);
  System.out.println("Initial set of cookies:");
  List<Cookie> cookies=cookieStore.getCookies();
  if (cookies.isEmpty()) {
    System.out.println("None");
  }
 else {
    for (int i=0; i < cookies.size(); i++) {
      System.out.println("- " + cookies.get(i).toString());
    }
  }
}
 catch (ClientProtocolException e) {
  e.printStackTrace();
}
catch (IOException e) {
  e.printStackTrace();
}

}
}
