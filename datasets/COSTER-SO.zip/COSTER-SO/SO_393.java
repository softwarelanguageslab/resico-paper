package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_393 {
public void soCodeSnippet(){
int deltaTime=1000;

TimeUnit timeUnit=TimeUnit.MILLISECONDS;

Date startTime=new Date(System.currentTimeMillis() - deltaTime * 10);

TimeSeries<Double> ts=new TimeSeries<Double>(startTime,deltaTime,timeUnit);

ts.append(1.0);

ts.append(2.0);

ts.append(3.0);

SESRForecaster forecaster=new SESRForecaster(ts);

IForecastResult<Double> forecast=forecaster.forecast(1);

ITimeSeries<Double> forecastSeries=forecast.getForecast();

ITimeSeriesPoint<Double> stepFC=forecastSeries.getPoints().get(0);

assertTrue(stepFC.getValue() > 2.88 && stepFC.getValue() < 3.1);

}
}
