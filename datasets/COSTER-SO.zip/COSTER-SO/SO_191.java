package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_191 {
public void soCodeSnippet(){
id=new Vector();

val=new Vector();

int j;

if (i != null && i.length > 0) for (j=0; j < i.length; j++) id.addElement(new Integer(i[j]));

if (v != null && v.length > 0) for (j=0; j < v.length; j++) val.addElement(v[j]);

}
}
