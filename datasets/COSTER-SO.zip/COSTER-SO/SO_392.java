package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_392 {
public void soCodeSnippet(){
System.out.println("Task selection");

System.out.println("=======================");

System.out.println("\tq: Quit");

System.out.println("\t0: None");

for (int i=0; i < tasks.size(); i++) {
  Task task=tasks.get(i);
  System.out.println("\t" + (i + 1) + ": "+ task.getName());
}

Scanner scan=new Scanner(System.in);

String option="";

while (true) {
  System.out.print("\nChoose task number:");
  option=scan.next();
  if (option.equalsIgnoreCase("q")) {
    System.out.println("Good bye!");
    System.exit(0);
  }
  if (!Pattern.matches("[0-9]+",option)) {
    System.out.println("You must enter a number");
    continue;
  }
  int index=Integer.parseInt(option);
  if (index < 0 || index > tasks.size()) {
    System.out.println("Opcion fuera de rango");
    continue;
  }
  if (index == 0)   return null;
  return tasks.get(index - 1);
}

}
}
