package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_47 {
public void soCodeSnippet(){
if (!content.startsWith("{")) {
  return null;
}

JSONObject obj=new JSONObject(content);

int karma=obj.getInt("karma");

int rating=obj.getInt("rating");

int voteWeight=obj.getInt("voteweight");

int myUnreadPosts=obj.getInt("myunreadposts");

int myUnreadComms=obj.getInt("myunreadcomms");

int inboxUnreadPosts=obj.getInt("inboxunreadposts");

int inboxUnreadComms=obj.getInt("inboxunreadcomms");

return new LepraStatus(karma,rating,voteWeight,myUnreadPosts,myUnreadComms,inboxUnreadPosts,inboxUnreadComms);

}
}
