package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_117 {
public void soCodeSnippet(){
int largeur=10;

int hauteur=-1;

int profondeur=20;

System.out.println(SpecTestStrings.SPEC_TEST_NAME + new Object(){
}
.getClass().getEnclosingMethod().getName());

System.out.println(SpecTestStrings.SPEC_TEST_OPERATIONS);

System.out.println("terrain.init(" + largeur + ", "+ hauteur+ ", "+ profondeur+ ");");

System.out.println(SpecTestStrings.SPEC_TEST_ORACLE);

System.out.println("fail");

try {
  terrain.init(largeur,hauteur,profondeur);
  assertTrue(false);
}
 catch (ContractError e) {
  assertTrue(true);
}

}
}
