package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_6 {
public void soCodeSnippet(){
List<TestResultData> testNgResultData=parseTestNgResultFromFilesOrUrls(urlsOrFiles);

List<String> testNgTests=(List<String>)CollectionUtils.collect(testNgResultData,new BeanToPropertyValueTransformer("testName"));

Collections.sort(testNgTests);

List<QcTestCase> qcTestCases=getAllTestCasesFromTestSets(testSetIdArr);

List<String> qcTestNames=(List<String>)CollectionUtils.collect(qcTestCases,new BeanToPropertyValueTransformer("name"));

Collections.sort(qcTestNames);

File csvFile=new File("testNgQcDiv.csv");

BufferedWriter bw=null;

try {
  bw=new BufferedWriter(new FileWriter(csvFile));
  for (  String testNgTestName : testNgTests) {
    bw.write(testNgTestName + ",");
    if (qcTestNames.contains(testNgTestName)) {
      bw.write(testNgTestName);
    }
    bw.write("\n");
  }
}
 catch (Exception e) {
  throw e;
}
 finally {
  try {
    bw.close();
  }
 catch (  Exception e) {
    e.printStackTrace();
  }
}

}
}
