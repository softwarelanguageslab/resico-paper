package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_419 {
public void soCodeSnippet(){
int largeur=10;

int hauteur=50;

int profondeur=20;

System.out.println(SpecTestStrings.SPEC_TEST_NAME + new Object(){
}
.getClass().getEnclosingMethod().getName());

System.out.println(SpecTestStrings.SPEC_TEST_OPERATIONS);

System.out.println("terrain.init(" + largeur + ", "+ hauteur+ ", "+ profondeur+ ");");

terrain.init(largeur,hauteur,profondeur);

System.out.println(SpecTestStrings.SPEC_TEST_ORACLE);

System.out.println("terrain.nbBlocLargeur() = " + largeur);

System.out.println("terrain.nbBlocHauteur() = " + hauteur);

System.out.println("terrain.nbBlocProfondeur() = " + profondeur);

testInvariants();

assertEquals(terrain.nbBlocLargeur(),largeur);

assertEquals(terrain.nbBlocHauteur(),hauteur);

assertEquals(terrain.nbBlocProfondeur(),profondeur);

for (int x=0; x < largeur; x++) {
  for (int y=0; y < hauteur; y++) {
    for (int z=0; z < profondeur; z++) {
      BlocService b=terrain.getBloc(x,y,z);
      assertNotNull(b);
      assertEquals(b.getType(),Type.VIDE);
      assertEquals(b.getObjet(),null);
    }
  }
}

}
}
