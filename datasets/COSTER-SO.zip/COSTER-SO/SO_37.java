package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_37 {
public void soCodeSnippet(){
StringBuilder builder=new StringBuilder();

builder.append("\n");

builder.append("Error Code:" + errorCode);

builder.append("\n");

builder.append("Error Description:" + SwingObjProps.getApplicationProperty(errorCode,(Object[])placeHolderValues));

builder.append("\n");

builder.append("Error Severity:" + errorSeverity.toString());

builder.append("\n");

builder.append("Message:" + StringUtils.defaultString(message));

builder.append("\n");

return builder.toString();

}
}
