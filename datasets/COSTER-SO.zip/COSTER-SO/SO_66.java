package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_66 {
public void soCodeSnippet(){
String response;

log.trace("URL = " + urlStr);

URL url=new URL(urlStr);

HttpURLConnection conn=null;

try {
  conn=openConnection(url);
  validateConnectionStatus(conn);
  response=readResponse(conn);
}
  finally {
  if (conn != null) {
    conn.disconnect();
  }
}

return response;

}
}
