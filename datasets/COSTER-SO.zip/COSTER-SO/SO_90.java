package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_90 {
public void soCodeSnippet(){
if (!isDontAddRowsAuto) {
  builder.appendRow(buttonRowGap);
  builder.appendRow(buttonRow);
  incrementRowCounter(2);
  resetColumnCount();
}

JPanel buttonBar=null;

switch (buttonBarPos) {
case Center:
  buttonBar=ButtonBarFactory.buildCenteredBar(buttons);
break;
case Left:
buttonBar=ButtonBarFactory.buildLeftAlignedBar(buttons);
break;
case Right:
buttonBar=ButtonBarFactory.buildRightAlignedBar(buttons);
break;
}

if (bgColor != null) {
  buttonBar.setBackground(bgColor);
}

builder.add(buttonBar,cc.xyw(col,row,colSpan));

incrementColumnCounter(colSpan + 1);

return this;

}
}
