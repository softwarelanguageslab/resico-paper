package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_306 {
public void soCodeSnippet(){
Request request=getRedirectRequest(titles);

Set<String> disambiguation=new HashSet<>();

JsonObject result=getWikiResult(request);

JsonObject query=result.get(QUERY_KEY).getAsJsonObject();

for (String key : REDIRECT_KEYS) addChangesToMap(changeMap,query.get(key));

for (JsonObject page : getPages(query)) {
  String title=page.get(TITLE_KEY).getAsString();
  if (isDisambiguationPage(page)) {
    disambiguation.add(title);
  }
 else   if (isMissingPage(page)) {
    String from=getActualValue(changeMap,title);
    String to=GenericCleaner.cleanValue(from);
    addChangeToMap(changeMap,from,to);
  }
}

return disambiguation;

}
}
