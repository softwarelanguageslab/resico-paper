package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_160 {
public void soCodeSnippet(){
init();

List<PersonalData> ret=new ArrayList<>();

boolean stop=false;

for (JsonElement userElement : users) {
  PersonalData data=getData(userElement);
  if (data == null) {
    stop=true;
    continue;
  }
  ret.add(data);
}

stopPaging.set(stop || ret.isEmpty());

return ret;

}
}
