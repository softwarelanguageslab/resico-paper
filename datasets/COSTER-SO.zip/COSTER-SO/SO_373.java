package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_373 {
public void soCodeSnippet(){
SampleGameMapFactory sgmf=new SampleGameMapFactory();

Collection<IGameMap> maps=new ArrayList<>();

IntStream.range(0,20).forEach(i -> maps.add(sgmf.getGameMap(i)));

IXMLGameMapProvider provider=new XMLGameMapProvider();

for (IGameMap iGameMap : maps) {
  try {
    provider.save(TPBJGConfig.LEVEL_FILE_DIRECTORY,iGameMap);
  }
 catch (  FileNotFoundException e) {
    TPBJGConfig.LEVEL_FILE_DIRECTORY.mkdirs();
    try {
      provider.save(TPBJGConfig.LEVEL_FILE_DIRECTORY,iGameMap);
    }
 catch (    FileNotFoundException e1) {
      e1.printStackTrace();
    }
  }
}

}
}
