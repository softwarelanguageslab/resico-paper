package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_81 {
public void soCodeSnippet(){
int largeur=50;

int hauteur=-50;

int profondeur=20;

System.out.println(SpecTestStrings.SPEC_TEST_NAME + new Object(){
}
.getClass().getEnclosingMethod().getName());

System.out.println(SpecTestStrings.SPEC_TEST_OPERATIONS);

System.out.println("gestionCombat.init(" + largeur + ", "+ hauteur+ ", "+ profondeur+ ");");

System.out.println(SpecTestStrings.SPEC_TEST_ORACLE);

System.out.println("gestionCombat = null");

testInvariants();

try {
  gestionCombat.init(largeur,hauteur,profondeur);
  assertTrue(false);
}
 catch (ContractError e) {
  assertTrue(true);
}

}
}
