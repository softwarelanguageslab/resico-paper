package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_79 {
public void soCodeSnippet(){
String userId=AuthUtil.getUserId(req);

Credential credential=AuthUtil.newAuthorizationCodeFlow().loadCredential(userId);

String message="";

if (req.getParameter("operation").equals("insertSubscription")) {
  try {
    MirrorClient.insertSubscription(credential,WebUtil.buildUrl(req,"/notify"),userId,req.getParameter("collection"));
    message="Application is now subscribed to updates.";
  }
 catch (  GoogleJsonResponseException e) {
    LOG.warning("Could not subscribe " + WebUtil.buildUrl(req,"/notify") + " because "+ e.getDetails().toPrettyString());
    message="Failed to subscribe. Check your log for details";
  }
}
 else if (req.getParameter("operation").equals("deleteSubscription")) {
  MirrorClient.deleteSubscription(credential,req.getParameter("subscriptionId"));
  message="Application has been unsubscribed.";
}
 else if (req.getParameter("operation").equals("insertItem")) {
  LOG.fine("Inserting Timeline Item");
  TimelineItem timelineItem=new TimelineItem();
  if (req.getParameter("message") != null) {
    timelineItem.setText(req.getParameter("message"));
  }
  timelineItem.setNotification(new NotificationConfig().setLevel("DEFAULT"));
  if (req.getParameter("imageUrl") != null) {
    URL url=new URL(req.getParameter("imageUrl"));
    String contentType=req.getParameter("contentType");
    MirrorClient.insertTimelineItem(credential,timelineItem,contentType,url.openStream());
  }
 else {
    MirrorClient.insertTimelineItem(credential,timelineItem);
  }
  message="A timeline item has been inserted.";
}
 else if (req.getParameter("operation").equals("insertPaginatedItem")) {
  LOG.fine("Inserting Timeline Item");
  TimelineItem timelineItem=new TimelineItem();
  timelineItem.setHtml(PAGINATED_HTML);
  List<MenuItem> menuItemList=new ArrayList<MenuItem>();
  menuItemList.add(new MenuItem().setAction("OPEN_URI").setPayload("https://www.google.com/search?q=cat+maintenance+tips"));
  timelineItem.setMenuItems(menuItemList);
  timelineItem.setNotification(new NotificationConfig().setLevel("DEFAULT"));
  MirrorClient.insertTimelineItem(credential,timelineItem);
  message="A timeline item has been inserted.";
}
 else if (req.getParameter("operation").equals("insertItemWithAction")) {
  LOG.fine("Inserting Timeline Item");
  TimelineItem timelineItem=new TimelineItem();
  timelineItem.setText("Tell me what you had for lunch :)");
  List<MenuItem> menuItemList=new ArrayList<MenuItem>();
  menuItemList.add(new MenuItem().setAction("REPLY"));
  menuItemList.add(new MenuItem().setAction("READ_ALOUD"));
  List<MenuValue> menuValues=new ArrayList<MenuValue>();
  menuValues.add(new MenuValue().setIconUrl(WebUtil.buildUrl(req,"/static/images/drill.png")).setDisplayName("Drill In"));
  menuItemList.add(new MenuItem().setValues(menuValues).setId("drill").setAction("CUSTOM"));
  timelineItem.setMenuItems(menuItemList);
  timelineItem.setNotification(new NotificationConfig().setLevel("DEFAULT"));
  MirrorClient.insertTimelineItem(credential,timelineItem);
  message="A timeline item with actions has been inserted.";
}
 else if (req.getParameter("operation").equals("insertContact")) {
  if (req.getParameter("iconUrl") == null || req.getParameter("name") == null) {
    message="Must specify iconUrl and name to insert contact";
  }
 else {
    LOG.fine("Inserting contact Item");
    Contact contact=new Contact();
    contact.setId(req.getParameter("id"));
    contact.setDisplayName(req.getParameter("name"));
    contact.setImageUrls(Lists.newArrayList(req.getParameter("iconUrl")));
    contact.setAcceptCommands(Lists.newArrayList(new Command().setType("TAKE_A_NOTE")));
    MirrorClient.insertContact(credential,contact);
    message="Inserted contact: " + req.getParameter("name");
  }
}
 else if (req.getParameter("operation").equals("deleteContact")) {
  LOG.fine("Deleting contact Item");
  MirrorClient.deleteContact(credential,req.getParameter("id"));
  message="Contact has been deleted.";
}
 else if (req.getParameter("operation").equals("insertItemAllUsers")) {
  if (req.getServerName().contains("glass-java-starter-demo.appspot.com")) {
    message="This function is disabled on the demo instance.";
  }
  List<String> users=AuthUtil.getAllUserIds();
  LOG.info("found " + users.size() + " users");
  if (users.size() > 10) {
    message="Total user count is " + users.size() + ". Aborting broadcast "+ "to save your quota.";
  }
 else {
    TimelineItem allUsersItem=new TimelineItem();
    allUsersItem.setText("Hello Everyone!");
    BatchRequest batch=MirrorClient.getMirror(null).batch();
    BatchCallback callback=new BatchCallback();
    for (    String user : users) {
      Credential userCredential=AuthUtil.getCredential(user);
      MirrorClient.getMirror(userCredential).timeline().insert(allUsersItem).queue(batch,callback);
    }
    batch.execute();
    message="Successfully sent cards to " + callback.success + " users ("+ callback.failure+ " failed).";
  }
}
 else if (req.getParameter("operation").equals("deleteTimelineItem")) {
  LOG.fine("Deleting Timeline Item");
  MirrorClient.deleteTimelineItem(credential,req.getParameter("itemId"));
  message="Timeline Item has been deleted.";
}
 else {
  String operation=req.getParameter("operation");
  LOG.warning("Unknown operation specified " + operation);
  message="I don't know how to do that";
}

WebUtil.setFlash(req,message);

res.sendRedirect(WebUtil.buildUrl(req,"/"));

}
}
