package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_69 {
public void soCodeSnippet(){
for (OpponentPanel panel : panels.values()) {
  panel.restore();
}

advanceGame.setText("Advance Game");

for (JLabel cardLabel : communityLabels) {
  cardLabel.setBorder(BorderFactory.createEmptyBorder());
  cardLabel.setVisible(false);
}

lblUserCards.setText("Your cards: ");

communityCards.clear();

ArrayList<Card> playerCards=userPlayer.getCards();

Card firstCard=playerCards.get(0);

userCardOne.setIcon(Util.getScaledImage(firstCard));

userCardOne.setBorder(BorderFactory.createEmptyBorder());

Card secondCard=playerCards.get(1);

userCardTwo.setIcon(Util.getScaledImage(secondCard));

userCardTwo.setBorder(BorderFactory.createEmptyBorder());

}
}
