package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_204 {
public void soCodeSnippet(){
if (object == null) {
  return null;
}

Class klass=object.getClass();

Field[] fields=klass.getFields();

int length=fields.length;

if (length == 0) {
  return null;
}

String[] names=new String[length];

for (int i=0; i < length; i+=1) {
  names[i]=fields[i].getName();
}

return names;

}
}
