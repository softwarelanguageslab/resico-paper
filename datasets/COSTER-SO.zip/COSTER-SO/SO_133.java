package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_133 {
public void soCodeSnippet(){
session=HibernateUtil.getSessionFactory().getCurrentSession();

session.getTransaction().begin();

CommsLog log=new CommsLog();

log.setResourceType(DbUtils.getResourceType(resourceType));

log.setReturnCode(code);

log.setFieldReport(fieldReport);

log.setResult(response);

log.setReportTime(Calendar.getInstance().getTime());

session.save(log);

session.getTransaction().commit();

}
}
