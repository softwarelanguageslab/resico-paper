package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_370 {
public void soCodeSnippet(){
if (camelCaseString == null) {
  return null;
}

if (camelCaseString.isEmpty()) {
  return new String[0];
}

final char[] c=camelCaseString.toCharArray();

final List<String> list=new ArrayList<String>();

int tokenStart=0;

int currentType=Character.getType(c[tokenStart]);

for (int pos=tokenStart + 1; pos < c.length; pos++) {
  final int type=Character.getType(c[pos]);
  if (type == currentType) {
    continue;
  }
  if (type == Character.LOWERCASE_LETTER && currentType == Character.UPPERCASE_LETTER) {
    final int newTokenStart=pos - 1;
    if (newTokenStart != tokenStart) {
      list.add(new String(c,tokenStart,newTokenStart - tokenStart));
      tokenStart=newTokenStart;
    }
  }
  currentType=type;
}

list.add(new String(c,tokenStart,c.length - tokenStart));

return list.toArray(new String[list.size()]);

}
}
