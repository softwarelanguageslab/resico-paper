package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_61 {
public void soCodeSnippet(){
char c;

String s=string.trim();

int length=s.length();

StringBuilder sb=new StringBuilder(length);

for (int i=0; i < length; i+=1) {
  c=s.charAt(i);
  if (c < ' ' || c == '+' || c == '%' || c == '=' || c == ';') {
    sb.append('%');
    sb.append(Character.forDigit((char)((c >>> 4) & 0x0f),16));
    sb.append(Character.forDigit((char)(c & 0x0f),16));
  }
 else {
    sb.append(c);
  }
}

return sb.toString();

}
}
