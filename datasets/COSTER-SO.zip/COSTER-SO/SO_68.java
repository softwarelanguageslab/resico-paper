package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_68 {
public void soCodeSnippet(){
if (!canImport(support)) return false;

JTabbedPaneTransferable d=null;

try {
  d=(JTabbedPaneTransferable)support.getTransferable().getTransferData(draggableTabbedPaneFlavor);
}
 catch (UnsupportedFlavorException ex) {
  throw new RuntimeException(ex);
}
catch (IOException ex) {
  throw new RuntimeException(ex);
}

final JTabbedPaneTransferable data=d;

if (data != null) {
  SwingObjFatTabbedPane pane=SwingObjFatTabbedPane.this;
  int mouseX=pane.getMousePosition().x;
  int mouseY=pane.getMousePosition().y;
  int index=pane.indexAtLocation(mouseX,mouseY);
  if (index == -1) {
    index=pane.getTabCount();
  }
 else {
    int tabX1;
    int tabX2;
    for (tabX1=mouseX; pane.indexAtLocation(tabX1,mouseY) == index; tabX1--)     ;
    for (tabX2=mouseX; pane.indexAtLocation(tabX2,mouseY) == index; tabX2++)     ;
    int tabCenter=tabX1 + (tabX2 - tabX1) / 2;
    if (mouseX > tabCenter)     index++;
  }
  pane.insertTab(data.title,data.icon,data.component,data.tip,index);
  pane.setSelectedComponent(data.component);
  data.didImport=true;
  return true;
}

return false;

}
}
