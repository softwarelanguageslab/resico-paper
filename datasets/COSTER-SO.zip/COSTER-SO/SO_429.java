package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_429 {
public void soCodeSnippet(){
for (String email : data.getAllValues("email")) {
  if (emails.contains(email))   return true;
}

for (String twitter : data.getAllValues("twitter")) {
  if (twitters.contains(twitter))   return true;
}

for (String phone : data.getAllValues("phone")) {
  if (phones.contains(phone))   return true;
}

if (data.containsKey("profilePicturePrint")) {
  for (  final String print : data.getAllValues("profilePicturePrint")) {
    if (matchPrint(print))     return true;
  }
}

return false;

}
}
