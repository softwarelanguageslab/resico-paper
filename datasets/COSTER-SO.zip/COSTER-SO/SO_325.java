package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_325 {
public void soCodeSnippet(){
PersonnageService p=new PersonnageContract(new PersonnageImpl());

p.init("totoro",501,445,255,20,9950,10,20,65);

System.err.println("au début argent = " + p.sommeArgent());

p.depotArgent(100);

System.err.println("apres depotArgent(100) = " + p.sommeArgent());

p.retraitArgent(50);

System.err.println("apres retraitArgent(50) = " + p.sommeArgent());

}
}
