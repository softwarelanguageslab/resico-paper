package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_218 {
public void soCodeSnippet(){
if (!addresses.hasMoreElements()) throw new IllegalArgumentException();

InetAddressNode first=null;

InetAddressNode prev=null;

InetAddressNode node=null;

int count=0;

while (addresses.hasMoreElements()) {
  InetAddress add=addresses.nextElement();
  if (add.getHostName().contains("borrowed-icon.local"))   continue;
  count++;
  node=new InetAddressNode(add);
  if (first == null)   first=node;
  if (prev != null)   prev.next=node;
}

System.out.printf("Loaded %d ip addresses%n",count);

node.next=first;

return first;

}
}
