package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_443 {
public void soCodeSnippet(){
setOpaque(false);

setBorder(new EmptyBorder(3,0,0,0));

FlowLayout flowLayout=(FlowLayout)getLayout();

flowLayout.setVgap(0);

flowLayout.setHgap(0);

}
}
