package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_400 {
public void soCodeSnippet(){
XMLConfiguration xmlData=null;

log.debug("Requested Url :" + request.getURL());

HttpURLConnection conn=(HttpURLConnection)new URL(request.getURL()).openConnection();

conn.setRequestMethod("GET");

long opStartTime=System.currentTimeMillis();

Properties headerProps=request.getDefaultHeaderProperties();

for (String propName : headerProps.stringPropertyNames()) {
  conn.setRequestProperty(propName,headerProps.getProperty(propName));
}

if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
  xmlData=new XMLConfiguration();
  xmlData.load(conn.getInputStream());
}
 else {
  QcException qcException=new QcException("Response code :" + conn.getResponseCode() + ", Error message :"+ QcUtil.readData(conn.getErrorStream()));
  if (conn.getResponseCode() == HttpURLConnection.HTTP_NOT_FOUND) {
    log.warn(qcException.getMessage());
    throw new NotFound();
  }
 else {
    throw qcException;
  }
}

long opEndTime=System.currentTimeMillis();

log.debug("Time taken to process QC request: {} secs",(opEndTime - opStartTime) / 1000);

if (log.isTraceEnabled()) {
  log.trace("GET Response XML data :\n" + ConfigurationUtils.toString(xmlData));
}

return xmlData;

}
}
