package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_28 {
public void soCodeSnippet(){
final String title=getTitleAt(index);

final Component content=getComponentAt(index);

int width=content.getWidth();

int height=content.getHeight();

SwingObjFatTabbedPane.this.removeTabAt(index);

final JFrame frame=new JFrame(title);

frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

frame.setLocationByPlatform(true);

frame.setBounds(100,100,width,height);

final JPanel layoutPanel=new JPanel();

layoutPanel.setLayout(new BoxLayout(layoutPanel,BoxLayout.X_AXIS));

frame.setContentPane(layoutPanel);

layoutPanel.add(content);

frame.addWindowListener(new WindowAdapter(){
  @Override public void windowClosing(  WindowEvent event){
    layoutPanel.remove(content);
    SwingObjFatTabbedPane.this.addTab(title,content);
  }
}
);

frame.setVisible(true);

}
}
