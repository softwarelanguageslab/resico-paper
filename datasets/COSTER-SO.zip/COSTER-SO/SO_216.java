package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_216 {
public void soCodeSnippet(){
if (number == null) {
  throw new JSONException("Null pointer");
}

testValidity(number);

String string=number.toString();

if (string.indexOf('.') > 0 && string.indexOf('e') < 0 && string.indexOf('E') < 0) {
  while (string.endsWith("0")) {
    string=string.substring(0,string.length() - 1);
  }
  if (string.endsWith(".")) {
    string=string.substring(0,string.length() - 1);
  }
}

return string;

}
}
