package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_385 {
public void soCodeSnippet(){
File imageConverted=new File(file.getParentFile(),FilenameUtils.getBaseName(file.getName()) + ".gif");

File imageCropped=new File(file.getParentFile(),FilenameUtils.getBaseName(file.getName()) + "-cropped.gif");

this.transformImages(file,imageConverted,imageCropped);

BASE64Encoder encoder=new BASE64Encoder();

FileInputStream fis=new FileInputStream(imageConverted);

String encodedData=encoder.encode(IOUtils.toByteArray(fis,fis.available()));

encoder=new BASE64Encoder();

fis=new FileInputStream(imageCropped);

String encodedDataThumb=encoder.encode(IOUtils.toByteArray(fis,fis.available()));

String reportText=null;

reportText=this.getHumphreyMeasurement(xmlFile,String.format("%07d",new Integer(patientRef)),fieldReport,encodedData,encodedDataThumb);

imageConverted.delete();

imageCropped.delete();

return reportText;

}
}
