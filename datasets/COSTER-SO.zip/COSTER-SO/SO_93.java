package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_93 {
public void soCodeSnippet(){
client=new DefaultHttpClient();

client.getParams().setParameter(ClientPNames.COOKIE_POLICY,CookiePolicy.BROWSER_COMPATIBILITY);

client.getParams().setParameter(ClientPNames.HANDLE_REDIRECTS,false);

HttpPost httpost=new HttpPost("https://reg.163.com/logins.jsp?url=http://entry.mail.163.com/coremail/fcg/ntesdoor2?lightweight=1&");

Vector<NameValuePair> nvps=new Vector<NameValuePair>();

nvps.add(new BasicNameValuePair("product","163"));

nvps.add(new BasicNameValuePair("type","1"));

nvps.add(new BasicNameValuePair("ursname",null));

nvps.add(new BasicNameValuePair("selected","1"));

nvps.add(new BasicNameValuePair("username",user));

nvps.add(new BasicNameValuePair("password",password));

nvps.add(new BasicNameValuePair("submit","登录"));

httpost.setEntity(new UrlEncodedFormEntity(nvps,"UTF-8"));

response=client.execute(httpost);

System.out.println(getRedirect(response,client));

return true;

}
}
