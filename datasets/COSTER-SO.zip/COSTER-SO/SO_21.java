package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_21 {
public void soCodeSnippet(){
message.setText("");

message.setVisible(false);

message.invalidate();

message.repaint();

for (int i=0; i < 2; ++i) {
  cards[i].setBorder(BorderFactory.createEmptyBorder());
  cards[i].setIcon(cardBack);
  cards[i].repaint();
}

}
}
