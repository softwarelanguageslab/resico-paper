package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_113 {
public void soCodeSnippet(){
out.println("Enter your library account number:");

String accountNum=reader.readLine();

if (!authenticator.accountNumIsValid(accountNum)) {
  out.println("Invalid account number.");
  return false;
}

out.println("Enter your password:");

String password=reader.readLine();

if (!authenticator.passwordIsValid(accountNum,password)) {
  out.println("Login failed.");
  return false;
}

user=authenticator.getUser(accountNum);

out.println("Login successful.");

return true;

}
}
