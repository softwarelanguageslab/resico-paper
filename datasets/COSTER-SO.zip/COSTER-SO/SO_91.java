package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_91 {
public void soCodeSnippet(){
Multiset<String> counts=HashMultiset.create();

int totalCount=values.length;

Collections.addAll(counts,values);

int max=-1, min=totalCount + 1;

List<String> maxCont=new ArrayList<>(), minCont=new ArrayList<>();

for (Multiset.Entry<String> ent : counts.entrySet()) {
  if (ent.getCount() > max) {
    max=ent.getCount();
    maxCont.clear();
    maxCont.add(ent.getElement());
  }
 else   if (max == ent.getCount()) {
    maxCont.add(ent.getElement());
  }
  if (ent.getCount() < min) {
    min=ent.getCount();
    minCont.clear();
    minCont.add(ent.getElement());
  }
 else   if (min == ent.getCount()) {
    minCont.add(ent.getElement());
  }
}

final double confidence=max * 1d / totalCount;

return new AttributeStatistics(maxCont.toArray(new String[maxCont.size()]),confidence,coverage,counts.elementSet().size(),minCont.toArray(new String[minCont.size()]));

}
}
