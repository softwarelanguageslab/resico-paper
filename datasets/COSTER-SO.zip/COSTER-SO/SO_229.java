package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_229 {
public void soCodeSnippet(){
in.beginObject();

String first, last;

if (!in.nextName().equals("firstName")) return null;

first=in.nextString();

if (!in.nextName().equals("lastName")) return null;

last=in.nextString();

if (!in.nextName().equals("attributes")) return null;

PersonStatistics ret=new PersonStatistics(first,last);

in.beginObject();

while (in.hasNext()) {
  ret.put(in.nextName(),(AttributeStatistics)DataGson.getGson().fromJson(in,AttributeStatistics.class));
}

in.endObject();

in.endObject();

return ret;

}
}
