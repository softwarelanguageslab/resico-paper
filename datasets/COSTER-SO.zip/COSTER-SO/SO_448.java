package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_448 {
public void soCodeSnippet(){
LinkedList<GenericTreeNode<$TreeData>> path=new LinkedList<GenericTreeNode<$TreeData>>();

GenericTreeNode<$TreeData> node=this;

while (node.getParent() != null) {
  path.addFirst(node);
  node=node.getParent();
}

if (node.getParent() == null) {
  path.addFirst(node);
}

return path.toArray(new GenericTreeNode[0]);

}
}
