package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_334 {
public void soCodeSnippet(){
this.reader=reader.markSupported() ? reader : new BufferedReader(reader);

this.eof=false;

this.usePrevious=false;

this.previous=0;

this.index=0;

this.character=1;

this.line=1;

}
}
