package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_214 {
public void soCodeSnippet(){
if (this.mode != mode) {
  throw new JSONException(mode == 'a' ? "Misplaced endArray." : "Misplaced endObject.");
}

this.pop(mode);

try {
  this.writer.write(c);
}
 catch (IOException e) {
  throw new JSONException(e);
}

this.comma=true;

return this;

}
}
