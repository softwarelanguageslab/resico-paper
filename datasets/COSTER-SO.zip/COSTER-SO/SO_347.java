package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_347 {
public void soCodeSnippet(){
if (!connected || rt == null) throw new RSrvException(this,"Not connected");

byte[] symn=sym.getBytes();

byte[] ctn=ct.getBytes();

int sl=symn.length + 1;

int cl=ctn.length + 1;

if ((sl & 3) > 0) sl=(sl & 0xfffffc) + 4;

if ((cl & 3) > 0) cl=(cl & 0xfffffc) + 4;

byte[] rq=new byte[sl + 4 + cl+ 4];

int ic;

for (ic=0; ic < symn.length; ic++) rq[ic + 4]=symn[ic];

while (ic < sl) {
  rq[ic + 4]=0;
  ic++;
}

for (ic=0; ic < ctn.length; ic++) rq[ic + sl + 8]=ctn[ic];

while (ic < cl) {
  rq[ic + sl + 8]=0;
  ic++;
}

Rtalk.setHdr(Rtalk.DT_STRING,sl,rq,0);

Rtalk.setHdr(Rtalk.DT_STRING,cl,rq,sl + 4);

Rpacket rp=rt.request(Rtalk.CMD_setSEXP,rq);

if (rp != null && rp.isOk()) return;

throw new RSrvException(this,"assign failed",rp);

}
}
