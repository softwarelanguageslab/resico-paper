package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_183 {
public void soCodeSnippet(){
for (Plane p : planes) {
  if (p.getBearing() != -1 && p.getBearing() != -2)   return bearings;
}

int minTime=10000;

int minIndex=10000;

for (int i=0; i < planes.size(); i++) {
  Plane p=planes.get(i);
  if (p.getDepartureTime() < minTime && p.getBearing() == -1) {
    minIndex=i;
    minTime=p.getDepartureTime();
  }
}

if (round >= minTime) {
  Plane p=planes.get(minIndex);
  bearings[minIndex]=calculateBearing(p.getLocation(),p.getDestination());
}

return bearings;

}
}
