package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_33 {
public void soCodeSnippet(){
int lowCard=hand.get(0).getValue();

int highCard=hand.get(4).getValue();

int checkCount=hand.size();

if (lowCard == 2 && highCard == 14) {
  checkCount=4;
}

for (int i=1, current=lowCard; i < checkCount; ++i) {
  if (hand.get(i).getValue() != current + 1)   return false;
  current+=1;
}

return true;

}
}
