package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_450 {
public void soCodeSnippet(){
String s;

s=props.getProperty("airplane.classes");

if (s != null) {
  String[] names=s.split(" ");
  for (int i=0; i < names.length; i++) {
    try {
      availablePlayers.add((Class<Player>)Class.forName(names[i]));
    }
 catch (    ClassNotFoundException e) {
      log.error("[Configuration] Class not found: " + names[i]);
    }
  }
}

File sourceFolder=new File("bin/airplane/");

for (File f : sourceFolder.listFiles()) {
  if (f.getName().length() == 2 && f.getName().substring(0,1).equals("g")) {
    for (    File c : f.listFiles()) {
      if (c.getName().endsWith(".class")) {
        String className=c.toString().replaceAll("/",".").replace("bin.","");
        className=className.substring(0,className.length() - 6);
        Class theClass=null;
        try {
          theClass=Class.forName(className,false,this.getClass().getClassLoader());
          if (theClass.getSuperclass() != null && theClass.getSuperclass().toString().equals("class airplane.sim.Player")) {
            if (!availablePlayers.contains((Class<Player>)theClass))             availablePlayers.add((Class<Player>)theClass);
          }
        }
 catch (        NoClassDefFoundError e) {
          continue;
        }
catch (        ClassNotFoundException e) {
          continue;
        }
      }
 else       if (c.isDirectory()) {
        for (        File ca : c.listFiles()) {
          if (ca.getName().endsWith(".class")) {
            String className=ca.toString().replace(c.toString(),"").replaceAll("/",".");
            className=className.substring(0,className.length() - 6);
            Class theClass=null;
            try {
              theClass=Class.forName(className,false,this.getClass().getClassLoader());
              if (theClass.getSuperclass() != null && theClass.getSuperclass().toString().equals("class airplane.sim.Player")) {
                if (!availablePlayers.contains((Class<Player>)theClass))                 availablePlayers.add((Class<Player>)theClass);
              }
            }
 catch (            NoClassDefFoundError e) {
              continue;
            }
catch (            ClassNotFoundException e) {
              continue;
            }
          }
 else           if (c.isDirectory()) {
          }
        }
      }
    }
  }
}

if (availablePlayers.size() == 0) log.fatal("No player classes loaded!!!");

if (props.getProperty("airplane.seed") != null) {
  long seed=Long.valueOf(props.getProperty("airplane.seed"));
  random=new Random(seed);
}
 else random=new Random();

readBoards();

}
}
