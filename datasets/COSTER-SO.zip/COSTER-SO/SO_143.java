package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_143 {
public void soCodeSnippet(){
String response;

URL url=new URL(urlStr);

HttpURLConnection conn=null;

try {
  conn=openConnection(url);
  conn.setRequestMethod("POST");
  conn.setRequestProperty("Content-Type","application/json");
  conn.setRequestProperty("Accept","application/json");
  conn.setDoOutput(true);
  try (OutputStream out=conn.getOutputStream();Writer writer=new OutputStreamWriter(out,"UTF-8")){
    writer.write(content);
  }
   validateConnectionStatus(conn);
  response=readResponse(conn);
}
  finally {
  if (conn != null) {
    conn.disconnect();
  }
}

return response;

}
}
