package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_390 {
public void soCodeSnippet(){
int myl=getBinaryLength();

boolean isLarge=(myl > 0xfffff0);

boolean hasAttr=false;

RList al=null;

if (attr != null) al=attr.asList();

if (al != null && al.size() > 0) hasAttr=true;

int rxt=Xt, ooff=off;

if (Xt == XT_VECTOR_STR) rxt=XT_ARRAY_STR;

if (Xt == XT_LIST || Xt == XT_LIST_TAG || Xt == XT_LIST_NOTAG) rxt=(asList() != null && asList().isNamed()) ? XT_LIST_TAG : XT_LIST_NOTAG;

Rtalk.setHdr(rxt | (hasAttr ? XT_HAS_ATTR : 0),myl - (isLarge ? 8 : 4),buf,off);

off+=(isLarge ? 8 : 4);

if (hasAttr) off=attr.getBinaryRepresentation(buf,off);

switch (rxt) {
case XT_S4:
case XT_NULL:
  break;
case XT_INT:
Rtalk.setInt(asInt(),buf,off);
break;
case XT_DOUBLE:
Rtalk.setLong(Double.doubleToLongBits(asDouble()),buf,off);
break;
case XT_ARRAY_INT:
if (cont != null) {
int ia[]=(int[])cont;
int i=0, io=off;
while (i < ia.length) {
Rtalk.setInt(ia[i++],buf,io);
io+=4;
}
}
break;
case XT_ARRAY_DOUBLE:
if (cont != null) {
double da[]=(double[])cont;
int i=0, io=off;
while (i < da.length) {
Rtalk.setLong(Double.doubleToLongBits(da[i++]),buf,io);
io+=8;
}
}
break;
case XT_ARRAY_STR:
if (cont != null) {
String sa[]=(String[])cont;
int i=0, io=off;
while (i < sa.length) {
if (sa[i] != null) {
try {
byte b[]=sa[i].getBytes(Rconnection.transferCharset);
System.arraycopy(b,0,buf,io,b.length);
io+=b.length;
b=null;
}
 catch (java.io.UnsupportedEncodingException uex) {
}
}
buf[io++]=0;
i++;
}
i=io - off;
while ((i & 3) != 0) {
buf[io++]=1;
i++;
}
}
break;
case XT_LIST_TAG:
case XT_LIST_NOTAG:
case XT_LIST:
case XT_VECTOR:
{
int io=off;
if (asList() != null) {
RList lst=asList();
int i=0;
while (i < lst.size()) {
REXP x=lst.at(i);
if (x == null) x=new REXP(XT_NULL,null);
io=x.getBinaryRepresentation(buf,io);
if (rxt == XT_LIST_TAG) io=(new REXP(XT_SYMNAME,lst.keyAt(i))).getBinaryRepresentation(buf,io);
i++;
}
}
}
break;
case XT_VECTOR_STR:
if (cont != null) {
String sa[]=(String[])cont;
int i=0, io=off;
while (i < sa.length) io=(new REXP(XT_STR,sa[i++])).getBinaryRepresentation(buf,io);
}
break;
case XT_SYMNAME:
case XT_STR:
getStringBinaryRepresentation(buf,off,(String)cont);
break;
}

return ooff + myl;

}
}
