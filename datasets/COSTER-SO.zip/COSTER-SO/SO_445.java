package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_445 {
public void soCodeSnippet(){
log.debug("Inside doGet method");

String cityNameorZip=request.getParameter("cityNameOrZip");

String numberOfDays=request.getParameter("days");

WeatherAPIResponse weather=null;

IWeather ws=new WorldWeatherOnlineImpl();

if (numberOfDays == null || "".equals(numberOfDays.trim())) {
  weather=ws.getWeatherInfo(cityNameorZip);
}
 else {
  int days=Integer.parseInt(numberOfDays);
  weather=ws.getWeatherInfo(cityNameorZip,days);
}

if (weather == null) {
  throw new RuntimeException("Error when retrieving weather information.");
}

StringBuffer sb=new StringBuffer();

if (weather.getData().getCurrent_condition() != null) {
  sb.append(prepareCurrentCondition(weather));
}
 else {
  MsgGson[] messg=weather.getData().getError();
  if (messg == null) {
    sb.append("<b>No information/message obtained from weather server.</b>");
  }
 else {
    sb.append("<b>" + messg[0].getMsg() + "</b>");
  }
}

response.setCharacterEncoding("UTF-8");

response.setContentType("text/plain");

response.getWriter().write(sb.toString());

response.flushBuffer();

log.debug("Exiting doGet method");

}
}
