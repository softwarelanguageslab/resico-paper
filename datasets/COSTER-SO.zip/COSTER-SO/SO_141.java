package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_141 {
public void soCodeSnippet(){
List<ItemSet<V>> candidates=getAllItemsetsOfSizeOne();

System.out.println("Level 1:");

System.out.println(candidates.size() + " total, unique itemsets: " + candidates.size());

System.out.println("\t" + candidates);

int levels=candidates.size();

pruneInfrequentCandidates(minSupport,candidates);

frequentItemSets.put(1,candidates);

for (int i=2; i < levels; i++) {
  System.out.println("Level " + i);
  candidates=aprioriGen(candidates);
  candidates=pruneInfrequentCandidates(minSupport,candidates);
  frequentItemSets.put(i,candidates);
  if (candidates.size() == 0) {
    System.out.println("We're done here, there's no more frequent itemsets");
    break;
  }
  System.out.println("\t" + candidates);
}

}
}
