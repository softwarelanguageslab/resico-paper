package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_359 {
public void soCodeSnippet(){
productManager.increasePrice(POSITIVE_PRICE_INCREASE);

double expectedChairPriceWithIncrease=22.55;

double expectedTablePriceWithIncrease=165.11;

List<Product> products=productManager.getProducts();

Product product=products.get(0);

assertEquals(expectedChairPriceWithIncrease,product.getPrice());

product=products.get(1);

assertEquals(expectedTablePriceWithIncrease,product.getPrice());

}
}
