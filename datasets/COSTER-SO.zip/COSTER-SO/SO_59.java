package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_59 {
public void soCodeSnippet(){
if ((nom.isEmpty() || !(0 < force) || !(force < pointsDeVie))) {
  throw new PreconditionError("Wrong init value");
}

if (largeur < 0 || hauteur < 0 || profondeur < 0) {
  throw new PreconditionError("Wrong init value");
}

super.init(nom,largeur,hauteur,profondeur,force,pointsDeVie,x,y,z);

checkInvariant();

if (!(nom().compareTo(nom) == 0)) {
  throw new PostconditionError("Error nom");
}

if (!(largeur() == largeur)) {
  throw new PostconditionError("Error largeur");
}

if (!(hauteur() == hauteur)) {
  throw new PostconditionError("Error hauteur");
}

if (!(profondeur() == profondeur)) {
  throw new PostconditionError("Error profondeur");
}

if (!(force() == force)) {
  throw new PostconditionError("Error force");
}

if (!(sommeArgent() == 0)) {
  throw new PostconditionError("Error sommeArgent");
}

if (!(pointsDeVie() == pointsDeVie)) {
  throw new PostconditionError("Error pointDeVie");
}

if (!(laChoseEquipee() == null)) {
  throw new PostconditionError("Error laChoseEquipee");
}

if (!(getX() == x)) {
  throw new PostconditionError("Error X");
}

if (!(getY() == y)) {
  throw new PostconditionError("Error Y");
}

if (!(getZ() == z)) {
  throw new PostconditionError("Error Z");
}

}
}
