package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_398 {
public void soCodeSnippet(){
Product prod=new Product();

prod.setId(rs.getInt("id"));

prod.setDescription(rs.getString("description"));

prod.setPrice(new Double(rs.getDouble("price")));

return prod;

}
}
