package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_432 {
public void soCodeSnippet(){
super(cellBackground,cellForeground);

this.table=table;

rows=new HashMap<Integer,String>();

setHighlightPredicate(new HighlightPredicate(){
  @Override public boolean isHighlighted(  Component component,  ComponentAdapter componentAdapter){
    return rows.containsKey(componentAdapter.row);
  }
}
);

table.addMouseMotionListener(new MouseAdapter(){
  @Override public void mouseMoved(  MouseEvent e){
    int row=RowHighlighter.this.table.rowAtPoint(e.getPoint());
    if (rows.containsKey(row)) {
      RowHighlighter.this.table.setToolTipText(rows.get(row));
    }
  }
}
);

table.addHighlighter(this);

}
}
