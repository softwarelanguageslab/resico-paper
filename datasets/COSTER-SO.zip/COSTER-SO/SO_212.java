package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_212 {
public void soCodeSnippet(){
if (width == 0) {
  return 0;
}

if (width < 0 || width > 32) {
  throw new IOException("Bad read width.");
}

int result=0;

while (width > 0) {
  if (this.available == 0) {
    this.unread=this.in.read();
    if (this.unread < 0) {
      throw new IOException("Attempt to read past end.");
    }
    this.available=8;
  }
  int take=width;
  if (take > this.available) {
    take=this.available;
  }
  result|=((this.unread >>> (this.available - take)) & ((1 << take) - 1)) << (width - take);
  this.nrBits+=take;
  this.available-=take;
  width-=take;
}

return result;

}
}
