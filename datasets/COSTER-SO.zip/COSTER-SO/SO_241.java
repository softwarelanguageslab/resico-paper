package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_241 {
public void soCodeSnippet(){
JTextArea area=new JTextArea();

area.setLineWrap(true);

area.setWrapStyleWord(true);

area.setOpaque(true);

return area;

}
}
