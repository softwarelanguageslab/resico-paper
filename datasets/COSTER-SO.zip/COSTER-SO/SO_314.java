package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_314 {
public void soCodeSnippet(){
WaitDialog.appendWaitDialogMessage("\nReplaced text with this");

try {
  Thread.sleep(2000);
}
 catch (InterruptedException e) {
  e.printStackTrace();
}

SwingObjData objData=(SwingObjData)scopeObj.getObjectFromMap("CompTest");

System.out.println(objData.getValue("tftest").asString());

List<TestData> testdata=(List<TestData>)objData.getValue("table").getValue();

testdata.get(0).setTftest1("Changed row data");

objData.set("table",testdata);

System.out.println(testdata.size());

objData.set("tftest","19/12/2019");

objData.set("tftest1","Changed tftest2");

}
}
