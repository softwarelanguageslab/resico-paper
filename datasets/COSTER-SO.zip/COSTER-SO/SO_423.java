package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_423 {
public void soCodeSnippet(){
ArrayList<Card> highPair=new ArrayList<Card>();

highPair.add(new Card(Card.Suit.SPADE,14));

highPair.add(new Card(Card.Suit.HEART,14));

highPair.add(new Card(Card.Suit.DIAMOND,13));

highPair.add(new Card(Card.Suit.SPADE,12));

highPair.add(new Card(Card.Suit.CLUB,11));

ArrayList<Card> lowTwoPair=new ArrayList<Card>();

lowTwoPair.add(new Card(Card.Suit.SPADE,2));

lowTwoPair.add(new Card(Card.Suit.HEART,2));

lowTwoPair.add(new Card(Card.Suit.DIAMOND,3));

lowTwoPair.add(new Card(Card.Suit.SPADE,3));

lowTwoPair.add(new Card(Card.Suit.CLUB,4));

assertTrue(HandRanking.rankHand(lowTwoPair) > HandRanking.rankHand(highPair));

}
}
