package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_35 {
public void soCodeSnippet(){
this.setTitle(SwingObjProps.getApplicationProperty("errorreport.gatherinfo.title"));

CommonUI.setIconImageForContainer(this);

txtArea=new JTextArea();

pnTxtArea=new JScrollPane(txtArea);

txtArea.setLineWrap(true);

txtArea.setWrapStyleWord(true);

btnSendEmail=new JButton("Send Email");

btnSendEmail.addActionListener(this);

}
}
