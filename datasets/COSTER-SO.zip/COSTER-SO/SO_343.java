package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_343 {
public void soCodeSnippet(){
Object storedKey=invertedMap.get(value);

if (storedKey != null) super.remove(storedKey);

super.put(key,value);

invertedMap.put(value,key);

return value;

}
}
