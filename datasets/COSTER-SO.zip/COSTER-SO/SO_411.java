package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_411 {
public void soCodeSnippet(){
final ITimeSeries<Double> history=this.getTsOriginal();

final ITimeSeries<Double> tsFC=super.prepareForecastTS();

List<Double> allHistory=new ArrayList<Double>(history.getValues());

Double[] histValuesNotNull=MeanForecasterJava.removeNullValues(allHistory);

final double[] values=ArrayUtils.toPrimitive(histValuesNotNull);

final RBridgeControl rBridge=RBridgeControl.getInstance(new File("r_scripts"));

rBridge.e("initTS()");

rBridge.assign("ts_history",values);

final double[] pred=rBridge.eDblArr("getForecast(ts_history)");

if (pred.length > 0) tsFC.append(pred[0]);

return new ForecastResult<Double>(tsFC,this.getTsOriginal());

}
}
