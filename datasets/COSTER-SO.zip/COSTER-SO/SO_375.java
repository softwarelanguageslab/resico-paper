package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_375 {
public void soCodeSnippet(){
availableBoards.clear();

String s=props.getProperty("airplane.board.dir");

if (s == null) {
  log.error("No board directory specified in conf file.");
}

File dir=new File(s);

if (!dir.isDirectory()) {
  log.error("Board directory is invalid " + s);
  return;
}

File[] files=dir.listFiles(new FileFilter(){
  public boolean accept(  File pathname){
    return pathname.getName().toLowerCase().endsWith(".txt");
  }
}
);

for (int i=0; i < files.length; i++) {
  availableBoards.add(files[i]);
}

if (availableBoards.size() > 0) boardFile=availableBoards.get(0);
 else boardFile=null;

}
}
