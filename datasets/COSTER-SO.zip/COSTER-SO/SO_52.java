package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_52 {
public void soCodeSnippet(){
Book book=mock(Book.class);

bookList.add(book);

when(reader.readLine()).thenReturn("");

when(book.isCheckedOut()).thenReturn(true);

when(book.getTitle()).thenReturn("");

library.returnItem(bookList);

verify(book).returnItem();

verify(printStream).println("Thank you for returning the item");

}
}
