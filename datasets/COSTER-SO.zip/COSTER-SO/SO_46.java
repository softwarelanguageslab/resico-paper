package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_46 {
public void soCodeSnippet(){
begin.addActionListener(a);

pause.addActionListener(a);

play.addActionListener(a);

step.addActionListener(a);

stop.addActionListener(a);

}
}
