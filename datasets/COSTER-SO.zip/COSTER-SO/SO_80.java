package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_80 {
public void soCodeSnippet(){
List<Extractor> ret=new ArrayList<>();

boolean stop=false;

for (Element resultContainer : getResultContainers()) {
  if (!checkName(resultContainer)) {
    stop=true;
    continue;
  }
  String url=getUrl(resultContainer);
  try {
    ret.add(new WhitepagesPersonLoader(url));
  }
 catch (  MalformedURLException ignored) {
  }
}

stopPaging.set(stop);

return ret;

}
}
