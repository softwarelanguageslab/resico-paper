package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_140 {
public void soCodeSnippet(){
if (req.getParameter("error") != null) {
  LOG.severe("Something went wrong during auth: " + req.getParameter("error"));
  res.setContentType("text/plain");
  res.getWriter().write("Something went wrong during auth. Please check your log for details");
  return;
}

if (req.getParameter("code") != null) {
  LOG.info("Got a code. Attempting to exchange for access token.");
  AuthorizationCodeFlow flow=AuthUtil.newAuthorizationCodeFlow();
  TokenResponse tokenResponse=flow.newTokenRequest(req.getParameter("code")).setRedirectUri(WebUtil.buildUrl(req,"/oauth2callback")).execute();
  String userId=((GoogleTokenResponse)tokenResponse).parseIdToken().getPayload().getUserId();
  LOG.info("Code exchange worked. User " + userId + " logged in.");
  AuthUtil.setUserId(req,userId);
  flow.createAndStoreCredential(tokenResponse,userId);
  NewUserBootstrapper.bootstrapNewUser(req,userId);
  res.sendRedirect(WebUtil.buildUrl(req,"/"));
  return;
}

LOG.info("No auth context found. Kicking off a new auth flow.");

AuthorizationCodeFlow flow=AuthUtil.newAuthorizationCodeFlow();

GenericUrl url=flow.newAuthorizationUrl().setRedirectUri(WebUtil.buildUrl(req,"/oauth2callback"));

url.set("approval_prompt","force");

res.sendRedirect(url.build());

}
}
