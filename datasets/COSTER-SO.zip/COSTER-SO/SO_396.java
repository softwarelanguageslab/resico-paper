package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_396 {
public void soCodeSnippet(){
QcConnector connector=new QcConnector();

List<String> testSetIds=Arrays.asList(testSetIdArr);

List<Long> testSetIdsLong=(List<Long>)CollectionUtils.collect(testSetIds,new Transformer(){
  @Override public Object transform(  Object arg0){
    return Long.valueOf((String)arg0);
  }
}
);

List<TestInstanceInfo> testInstanceInfos=connector.getTestInstances(testSetIdsLong);

List<Long> testIds=(List<Long>)CollectionUtils.collect(testInstanceInfos,new BeanToPropertyValueTransformer("testId"));

return connector.getTestCases(testIds);

}
}
