package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_236 {
public void soCodeSnippet(){
BufferedReader reader=new BufferedReader(new FileReader(new File(filename)));

ArrayList<String> attributeNames=new ArrayList<String>();

ArrayList<ItemSet<String>> itemSets=new ArrayList<ItemSet<String>>();

String line=reader.readLine();

line=reader.readLine();

while (line != null) {
  if (line.contains("#") || line.length() < 2) {
    line=reader.readLine();
    continue;
  }
  if (line.contains("attribute")) {
    int startIndex=line.indexOf("'");
    if (startIndex > 0) {
      int endIndex=line.indexOf("'",startIndex + 1);
      attributeNames.add(line.substring(startIndex + 1,endIndex));
    }
  }
 else {
    ItemSet<String> is=new ItemSet<String>();
    StringTokenizer tokenizer=new StringTokenizer(line,",");
    int attributeCounter=0;
    String itemSet="";
    while (tokenizer.hasMoreTokens()) {
      String token=tokenizer.nextToken().trim();
      if (token.equalsIgnoreCase("t")) {
        String attribute=attributeNames.get(attributeCounter);
        itemSet+=attribute + ",";
        is.addItem(attribute);
      }
      attributeCounter++;
    }
    itemSets.add(is);
  }
  line=reader.readLine();
}

reader.close();

return itemSets;

}
}
