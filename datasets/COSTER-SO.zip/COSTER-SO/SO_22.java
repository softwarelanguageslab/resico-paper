package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_22 {
public void soCodeSnippet(){
String key1="key_1";

String value1="value_1";

uniqueHashMap.put(key1,value1);

System.out.println(uniqueHashMap);

String key2="key_1";

String value2="value_2";

uniqueHashMap.put(key2,value2);

System.out.println(uniqueHashMap);

String key3="key_3";

String value3="value_2";

uniqueHashMap.put(key3,value3);

System.out.println(uniqueHashMap);

String key4="key_4";

String value4="value_4";

uniqueHashMap.put(key4,value4);

System.out.println(uniqueHashMap);

}
}
