package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_232 {
public void soCodeSnippet(){
HttpClient httpclient=new DefaultHttpClient();

HttpGet httpget=new HttpGet("http://www.163.com");

HttpResponse response=httpclient.execute(httpget);

HttpEntity entity=response.getEntity();

String html=new String(EntityUtils.toString(entity));

html=new String(html.getBytes("ISO-8859-1"),"GBK");

System.out.println(html);

httpclient.getConnectionManager().shutdown();

}
}
