package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_97 {
public void soCodeSnippet(){
if (password.length() < 8) return "Password should have at least 8 characters.";

Pattern pattern=Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$");

Matcher matcher=pattern.matcher(password);

if (!matcher.matches()) return "Password must contain at least 1 number, 1 uppercase and 1 lowercase character";

return null;

}
}
