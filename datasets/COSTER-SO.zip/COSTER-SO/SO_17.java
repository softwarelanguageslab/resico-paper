package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_17 {
public void soCodeSnippet(){
Document doc=Jsoup.parse(rawPost);

String postId=doc.select(".post").first().attr("id");

String postContent=doc.select(".dti").first().html();

String userLogin=doc.select(".c_user").first().text();

String postLink=null;

String commentsCnt=null, newCommentsCnt=null;

Element commentsCounts=doc.select(".b-post_comments_links").first();

if (commentsCounts != null) {
  Elements cnts=commentsCounts.getElementsByTag("a");
  if (!cnts.isEmpty()) {
    commentsCnt=cnts.first().text();
    postLink=cnts.first().attr("href");
    if (cnts.size() > 1) {
      newCommentsCnt=cnts.get(1).text();
    }
  }
}

String d=doc.select(".js-date").first().attr("data-epoch_date");

long date=Long.valueOf(d);

String title=doc.select(".ddi").first().html();

if (StringUtils.isNotBlank(title)) {
  title=title.trim().substring(8,title.indexOf("<a")).replaceAll("\\s"," ").trim();
}

int postIdInt=Integer.valueOf(postId.substring(1,postId.length()));

return new LepraPost(postIdInt,postLink,userLogin,title,new Date(date * 1000),commentsCnt,newCommentsCnt,postContent);

}
}
