package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_49 {
public void soCodeSnippet(){
List<Long> ids=new ArrayList<Long>();

List<String> qcNameCopies=new ArrayList<String>();

qcNameCopies.addAll(qcNames);

for (Map.Entry<Long,String> me : qcIdNames.entrySet()) {
  String qcName=me.getValue();
  if (qcNameCopies.contains(qcName)) {
    if (qcNameCopies.remove(qcName)) {
      ids.add(me.getKey());
    }
  }
  if (qcNameCopies.isEmpty()) {
    break;
  }
}

return (!ids.isEmpty() ? ids : null);

}
}
