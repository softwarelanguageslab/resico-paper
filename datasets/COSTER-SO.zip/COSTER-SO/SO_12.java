package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_12 {
public void soCodeSnippet(){
float normalspeed=effector.getSpeed();

final float speedDiff=normalspeed * (speedfactor - 1);

effector.setSpeed(effector.getSpeed() + speedDiff);

speedDiffs.add(speedDiff);

if (sound != null) sound.play();

}
}
