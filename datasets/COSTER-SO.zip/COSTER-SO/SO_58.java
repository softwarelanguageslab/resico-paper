package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_58 {
public void soCodeSnippet(){
char c=this.nextClean();

String string;

switch (c) {
case '"':
case '\'':
  return this.nextString(c);
case '{':
this.back();
return new JSONObject(this);
case '[':
this.back();
return new JSONArray(this);
}

StringBuilder sb=new StringBuilder();

while (c >= ' ' && ",:]}/\\\"[{;=#".indexOf(c) < 0) {
  sb.append(c);
  c=this.next();
}

this.back();

string=sb.toString().trim();

if ("".equals(string)) {
  throw this.syntaxError("Missing value");
}

return JSONObject.stringToValue(string);

}
}
