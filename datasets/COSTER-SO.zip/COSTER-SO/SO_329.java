package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_329 {
public void soCodeSnippet(){
printStream=mock(PrintStream.class);

reader=mock(BufferedReader.class);

authenticator=mock(Authenticator.class);

session=new Session(printStream,reader,authenticator);

when(reader.readLine()).thenReturn("test_account_num").thenReturn("test_password");

when(authenticator.accountNumIsValid(anyString())).thenReturn(true);

when(authenticator.passwordIsValid(anyString(),anyString())).thenReturn(true);

}
}
