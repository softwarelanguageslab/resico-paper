package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_442 {
public void soCodeSnippet(){
URL resource=AuthUtil.class.getResource("/oauth.properties");

File propertiesFile=new File("./src/main/resources/oauth.properties");

try {
  propertiesFile=new File(resource.toURI());
}
 catch (URISyntaxException e) {
  LOG.info(e.toString());
  LOG.info("Using default source path.");
}

FileInputStream authPropertiesStream=new FileInputStream(propertiesFile);

Properties authProperties=new Properties();

authProperties.load(authPropertiesStream);

String clientId=authProperties.getProperty("client_id");

String clientSecret=authProperties.getProperty("client_secret");

return new GoogleAuthorizationCodeFlow.Builder(new NetHttpTransport(),new JacksonFactory(),clientId,clientSecret,Collections.singleton(GLASS_SCOPE)).setAccessType("offline").setCredentialStore(store).build();

}
}
