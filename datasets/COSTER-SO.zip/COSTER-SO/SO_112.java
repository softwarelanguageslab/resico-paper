package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_112 {
public void soCodeSnippet(){
int index=-1;

double maxSSE=Double.NEGATIVE_INFINITY;

double currentSSE=0;

for (int i=0; i < indices.size(); i++) {
  currentSSE=distanceFunction.distance(data[indices.get(i)],centroid);
  if (currentSSE > maxSSE) {
    maxSSE=currentSSE;
    index=indices.get(i);
  }
}

return index;

}
}
