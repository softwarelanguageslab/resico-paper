package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_51 {
public void soCodeSnippet(){
super.paintComponent(g);

Graphics2D g2=(Graphics2D)g;

g2.setColor(Color.GREEN);

List<Food> foods=Grid.getFoods();

for (Food food : foods) {
  GridLocation loc=food.getLocation();
  g2.fillRect(loc.getX() * scale,loc.getY() * scale,scale,scale);
}

List<BugController> bugs=Grid.getBugs();

for (BugController bugController : bugs) {
  Breed breed=bugController.getBug().getBreed();
  g2.setColor(breed.getColor());
  GridLocation loc=bugController.getBug().getLoc();
  g2.fillRect(loc.getX() * scale,loc.getY() * scale,scale,scale);
}

String population="Population: " + new Integer(Grid.getBugPopulation()).toString();

g2.drawString(population,gridWidth - 90,30);

Map<Breed,Queue<Integer>> populationHistory=Simulator.getPopulationHistory();

int breedCount=0;

for (Breed b : populationHistory.keySet()) {
  g2.setColor(b.getColor());
  String breedPopulation="Population (" + b.getName() + "): "+ new Integer(Grid.getBugPopulation(b)).toString();
  g2.drawString(breedPopulation,gridWidth - 90,30 + (20 * (breedCount + 2)));
  int count=0;
  for (  Integer i : populationHistory.get(b)) {
    g2.fillRect(populationStartPointx + (count / 5),populationStartPointy - i,1,1);
    count++;
    if (count > 500) {
      break;
    }
  }
  breedCount++;
}

}
}
