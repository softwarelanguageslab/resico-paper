package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_136 {
public void soCodeSnippet(){
StringBuilder sb=new StringBuilder();

sb.append(" WeatherGson={ date=").append(date).append(", precipMM=").append(precipMM).append(", tempMaxC=").append(tempMaxC).append(", tempMaxF=").append(tempMaxF).append(", tempMinC=").append(tempMinC).append(", tempMinF=").append(tempMinF).append(", weatherCode=").append(weatherCode).append(", winddir16Point=").append(winddir16Point).append(", winddirDegree=").append(winddirDegree).append(", winddirection=").append(winddirection).append(", windspeedKmph=").append(windspeedKmph).append(", windspeedMiles=").append(windspeedMiles);

sb.append(", weatherDesc=[ ");

for (ValueGson vg : weatherDesc) {
  sb.append(vg).append(" ,");
}

sb.append(" ]");

sb.append(", weatherIconUrl=[ ");

for (ValueGson vg : weatherIconUrl) {
  sb.append(vg).append(" ,");
}

sb.append(" ]");

sb.append(" }");

return sb.toString();

}
}
