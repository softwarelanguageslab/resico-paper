package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_124 {
public void soCodeSnippet(){
if (names == null) return super.retainAll(c);

boolean rm[]=new boolean[size()];

boolean changed=false;

int i=0;

while (i < rm.length) {
  changed|=rm[i]=!c.contains(get(i));
  i++;
}

while (i > 0) {
  i--;
  if (rm[i])   remove(i);
}

return changed;

}
}
