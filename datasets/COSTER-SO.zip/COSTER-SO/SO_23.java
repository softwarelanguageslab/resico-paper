package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_23 {
public void soCodeSnippet(){
Collections.sort(frequentCandidatesKMinus1);

int allGeneratedCandidatesCounter=0;

Set<ItemSet<V>> frequentCandidateSet=new HashSet<ItemSet<V>>();

for (ItemSet<V> frequentCandidatePrevLevel : frequentCandidatesKMinus1) {
  for (  ItemSet<V> frequentItem : frequent1Itemsets) {
    if (frequentCandidatePrevLevel.intersection(frequentItem).size() == 0) {
      ItemSet<V> frequentCandidate=frequentCandidatePrevLevel.union(frequentItem);
      frequentCandidateSet.add(frequentCandidate);
      allGeneratedCandidatesCounter++;
      getAndCacheSupportForItemset(frequentCandidate);
    }
  }
}

return new LinkedList<ItemSet<V>>(frequentCandidateSet);

}
}
