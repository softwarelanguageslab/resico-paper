package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_147 {
public void soCodeSnippet(){
program.add("LBL MOVE_TO_FOOD");

program.add("MOV");

program.add("LOK MOVE_TO_FOOD");

program.add("BRD ENERGY 500");

program.add("LBL MOVE_DIAGONALLY");

program.add("MOV");

program.add("TCW");

program.add("MOV");

program.add("TCC");

program.add("STO SCAN_COUNT 0");

program.add("LBL SEARCH");

program.add("TCW");

program.add("LOK MOVE_TO_FOOD");

program.add("INC SCAN_COUNT");

program.add("BEQ SCAN_COUNT 4 MOVE_DIAGONALLY");

program.add("JMP SEARCH");

}
}
