package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_95 {
public void soCodeSnippet(){
BlocService b=new BlocContract(new BlocImpl());

ObjetContract o=new ObjetContract(new ObjetImpl());

o.init(Tresor.POUBELLEMETALLIQUE);

b.init(Type.VIDE,o);

System.out.println(b);

}
}
