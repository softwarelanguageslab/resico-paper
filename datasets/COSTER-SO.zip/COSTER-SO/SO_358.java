package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_358 {
public void soCodeSnippet(){
super(Integer.toString(day));

this.parent=parent;

setHorizontalAlignment(SwingConstants.CENTER);

setFont(plain);

this.addMouseListener(this);

}
}
