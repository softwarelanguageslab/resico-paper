package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_384 {
public void soCodeSnippet(){
List<Extractor> ret=new ArrayList<>();

boolean stop=false;

for (Element person : getPeople()) {
  if (!checkNames(person)) {
    stop=true;
    continue;
  }
  try {
    ret.add(new LinkedinPersonLoader(person.select(PROFILE_REQUEST_ELEMENT).first()));
  }
 catch (  MalformedURLException ignored) {
  }
}

stopPaging.set(stop);

return ret;

}
}
