package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_120 {
public void soCodeSnippet(){
List<ItemSet<String>> transactions=null;

boolean useSmallDataset=true;

try {
  if (useSmallDataset)   transactions=readFile("smallDataset.txt");
 else   transactions=readFile("supermarket.arff");
}
 catch (IOException e) {
  e.printStackTrace();
}

System.out.println(transactions);

Double minSupport=.4d;

System.out.println("We set the relative minsup to " + minSupport);

AbstractApriori<String> apriori;

long startTime=System.currentTimeMillis();

apriori=new BruteForceApriori<String>(transactions);

apriori.apriori(minSupport);

apriori.generateAllRules();

System.out.println("Generated " + apriori.getRules().size() + " rules.");

long endTime=System.currentTimeMillis();

long totalTime=endTime - startTime;

System.out.println("Completed in " + totalTime + " ms!");

}
}
