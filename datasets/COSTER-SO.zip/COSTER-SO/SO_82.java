package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_82 {
public void soCodeSnippet(){
List<Object> list=new ArrayList<Object>();

list.add(torrent);

list.add(uris);

list.add(options.serialize());

list.add(position);

AddTorrentTask task=new AddTorrentTask(list);

addTask(task);

}
}
