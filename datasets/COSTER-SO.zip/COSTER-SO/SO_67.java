package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_67 {
public void soCodeSnippet(){
if (!(obj instanceof Kim)) {
  return false;
}

Kim that=(Kim)obj;

if (this == that) {
  return true;
}

if (this.hashcode != that.hashcode) {
  return false;
}

return java.util.Arrays.equals(this.bytes,that.bytes);

}
}
