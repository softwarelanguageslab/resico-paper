package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_349 {
public void soCodeSnippet(){
GrainOrientedFarm desiredFarm=null;

sc=new Scanner(System.in);

int money=new Integer(sc.nextLine());

desiredFarm=new GrainOrientedFarm(money);

return desiredFarm;

}
}
