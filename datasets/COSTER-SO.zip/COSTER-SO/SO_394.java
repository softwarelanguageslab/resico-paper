package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_394 {
public void soCodeSnippet(){
JFrame frame=new JFrame("BugWorld");

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

frame.getContentPane().add(panel);

frame.pack();

frame.setVisible(true);

}
}
