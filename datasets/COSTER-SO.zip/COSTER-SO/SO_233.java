package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_233 {
public void soCodeSnippet(){
this.player=player;

setBackground(UIConstants.TABLE_COLOR);

JPanel cardPanel=new JPanel();

cardPanel.setBackground(UIConstants.TABLE_COLOR);

setPreferredSize(new Dimension(UIConstants.PLAYER_WIDTH,150));

cardBack=new ImageIcon(PokerTable.class.getResource("/cards/Red_Back.png"));

Image image=cardBack.getImage();

cardBack=new ImageIcon(image.getScaledInstance(70,-1,Image.SCALE_SMOOTH));

cards[0]=new JLabel(cardBack);

cards[1]=new JLabel(cardBack);

cardPanel.add(cards[0]);

cardPanel.add(cards[1]);

message=new JLabel();

message.setVisible(false);

message.setFont(new Font("Tahoma",Font.PLAIN,16));

add(message);

add(cardPanel);

}
}
