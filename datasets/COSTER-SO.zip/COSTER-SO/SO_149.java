package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_149 {
public void soCodeSnippet(){
GenericTreeNode<String> A=new GenericTreeNode<String>("1");

GenericTreeNode<String> T=A.addChild(new GenericTreeNode<String>("2")).addChild(new GenericTreeNode<String>("3"));

T.addChild(new GenericTreeNode<String>("4"));

T.addChild(new GenericTreeNode<String>("5"));

T.addChild(new GenericTreeNode<String>("6"));

A.addChild(new GenericTreeNode<String>("7")).addChild(new GenericTreeNode<String>("8"));

A.addChild(new GenericTreeNode<String>("9")).addChild(new GenericTreeNode<String>("10"));

assertEquals("[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]",new GenericTree<String>(A).build(GenericTreeTraversalOrderEnum.PRE_ORDER).toString());

}
}
