package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_92 {
public void soCodeSnippet(){
ArrayList<Card> highFullHouse=new ArrayList<Card>();

highFullHouse.add(new Card(Card.Suit.SPADE,14));

highFullHouse.add(new Card(Card.Suit.HEART,14));

highFullHouse.add(new Card(Card.Suit.DIAMOND,14));

highFullHouse.add(new Card(Card.Suit.SPADE,13));

highFullHouse.add(new Card(Card.Suit.CLUB,13));

ArrayList<Card> lowFour=new ArrayList<Card>();

lowFour.add(new Card(Card.Suit.SPADE,2));

lowFour.add(new Card(Card.Suit.HEART,2));

lowFour.add(new Card(Card.Suit.DIAMOND,2));

lowFour.add(new Card(Card.Suit.SPADE,3));

lowFour.add(new Card(Card.Suit.CLUB,2));

assertTrue(HandRanking.rankHand(lowFour) > HandRanking.rankHand(highFullHouse));

}
}
