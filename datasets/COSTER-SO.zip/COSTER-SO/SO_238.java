package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_238 {
public void soCodeSnippet(){
StringBuffer sb=new StringBuffer();

sb.append(" WeatherReponseDataGson={");

sb.append(" current_condition=[");

for (CurrentConditionGson ccg : current_condition) {
  sb.append(ccg.toString()).append(", ");
}

sb.append(" ]");

sb.append(", Request=[");

for (WeatherRequestGson req : request) {
  sb.append(req.toString()).append(", ");
}

sb.append(" ]");

sb.append(", WeatherGson=[");

for (WeatherGson wg : weather) {
  sb.append(wg.toString()).append(", ");
}

sb.append(" ]");

sb.append(" }");

return sb.toString();

}
}
