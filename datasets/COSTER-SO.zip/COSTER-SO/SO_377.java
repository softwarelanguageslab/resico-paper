package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_377 {
public void soCodeSnippet(){
StringBuilder secret=new StringBuilder();

secret.append(IOUtil.urlEncode(new String(consumer.getSecret())));

secret.append("&");

if (token != null) secret.append(IOUtil.urlEncode(new String(token.getSecret())));

return secret.toString();

}
}
