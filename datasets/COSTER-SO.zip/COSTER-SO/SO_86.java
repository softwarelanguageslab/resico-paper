package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_86 {
public void soCodeSnippet(){
addHTTPButton.setEnabled(false);

addFileButton.setEnabled(false);

pauseButton.setEnabled(false);

unpauseButton.setEnabled(false);

removeButton.setEnabled(false);

pauseAllButton.setEnabled(false);

unpauseAllButton.setEnabled(false);

optionsButton.setEnabled(false);

connectButton.setEnabled(true);

update();

}
}
