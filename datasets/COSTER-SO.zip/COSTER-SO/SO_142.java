package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_142 {
public void soCodeSnippet(){
final Double[] values={1.0,2.0,3.0,4.0};

final List<Double> expectedValues=new ArrayList<Double>(values.length);

for (final Double curVal : values) {
  expectedValues.add(curVal);
}

final TimeSeries<Double> ts=new TimeSeries<Double>(new Date(this.startTime),this.deltaTimeMillis,TimeUnit.MILLISECONDS);

ts.appendAll(values);

final ETSForecaster forecaster=new ETSForecaster(ts,this.confidenceLevel);

final IForecastResult<Double> forecast=forecaster.forecast(this.steps);

final ITimeSeries<Double> forecastSeries=forecast.getForecast();

final double expectedForecast=4.0;

this.assertEqualsWithTolerance("Unexpected forecast value",expectedForecast,0.1,forecastSeries.getPoints().get(0).getValue());

final ITimeSeries<Double> upperSeries=forecast.getUpper();

final double expectedUpper=5.424480;

this.assertEqualsWithTolerance("Unexpected upper value",expectedUpper,0.1,upperSeries.getPoints().get(0).getValue());

final ITimeSeries<Double> lowerSeries=forecast.getLower();

final double expectedLower=2.57531997;

this.assertEqualsWithTolerance("Unexpected lower value",expectedLower,0.1,lowerSeries.getPoints().get(0).getValue());

}
}
