package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_351 {
public void soCodeSnippet(){
if (this == obj) return true;

if (obj == null) return false;

if (getClass() != obj.getClass()) return false;

TestData other=(TestData)obj;

if (cbCombo == null) {
  if (other.cbCombo != null)   return false;
}
 else if (!cbCombo.equals(other.cbCombo)) return false;

if (chkBx != other.chkBx) return false;

if (tftest == null) {
  if (other.tftest != null)   return false;
}
 else if (!tftest.equals(other.tftest)) return false;

if (tftest1 == null) {
  if (other.tftest1 != null)   return false;
}
 else if (!tftest1.equals(other.tftest1)) return false;

return true;

}
}
