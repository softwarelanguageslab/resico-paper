package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_382 {
public void soCodeSnippet(){
boolean uploaded=true;

List<String> logFilePaths=testRunInfo.getClientLogFilePaths();

TestRunInfo newTestRun=null;

try {
  newTestRun=qcConnector.postResult2Qc(testRunInfo);
  if (newTestRun != null) {
    log.info("Successfully posted test run result into QC :" + newTestRun.getId());
  }
 else {
    log.error("Failed to post test result into QC");
  }
}
 catch (Exception ex) {
  log.error("Got an exception when posting test run result into QC",ex);
}

try {
  if (newTestRun != null && logFilePaths != null && !logFilePaths.isEmpty()) {
    for (    String logFilePath : logFilePaths) {
      if (qcConnector.uploadLogFile2Qc(newTestRun.getId(),logFilePath) != null) {
        log.info("Test logs are successfully uploaded into QC :" + logFilePaths);
      }
 else {
        log.error("Failed to upload test logs into QC :" + logFilePaths);
        uploaded=false;
      }
    }
  }
}
 catch (Exception ex) {
  log.error("Got an exception when uploading testlog files into QC",ex);
  uploaded=false;
}

return newTestRun != null && uploaded;

}
}
