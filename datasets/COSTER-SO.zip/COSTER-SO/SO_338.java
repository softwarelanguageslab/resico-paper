package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_338 {
public void soCodeSnippet(){
URL resource=FileHelper.class.getResource(relativepath);

if (resource == null) {
  return null;
}

String file=resource.getFile();

try {
  file=URLDecoder.decode(file,"UTF-8");
}
 catch (UnsupportedEncodingException e) {
  throw new SwingObjectRunException(e,ErrorSeverity.SEVERE,FileHelper.class);
}

return file;

}
}
