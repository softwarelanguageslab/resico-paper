package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_178 {
public void soCodeSnippet(){
response.setContentType("text/html");

Writer writer=response.getWriter();

writer.append("OK");

writer.close();

BufferedReader notificationReader=new BufferedReader(new InputStreamReader(request.getInputStream()));

String notificationString="";

int lines=0;

while (notificationReader.ready()) {
  notificationString+=notificationReader.readLine();
  lines++;
  if (lines > 1000) {
    throw new IOException("Attempted to parse notification payload that was unexpectedly long.");
  }
}

LOG.info("got raw notification " + notificationString);

JsonFactory jsonFactory=new JacksonFactory();

Notification notification=jsonFactory.fromString(notificationString,Notification.class);

LOG.info("Got a notification with ID: " + notification.getItemId());

String userId=notification.getUserToken();

Credential credential=AuthUtil.getCredential(userId);

Mirror mirrorClient=MirrorClient.getMirror(credential);

if (notification.getCollection().equals("locations")) {
  LOG.info("Notification of updated location");
  Mirror glass=MirrorClient.getMirror(credential);
  Location location=glass.locations().get(notification.getItemId()).execute();
  LOG.info("New location is " + location.getLatitude() + ", "+ location.getLongitude());
  MirrorClient.insertTimelineItem(credential,new TimelineItem().setText("Java Quick Start says you are now at " + location.getLatitude() + " by "+ location.getLongitude()).setNotification(new NotificationConfig().setLevel("DEFAULT")).setLocation(location).setMenuItems(Lists.newArrayList(new MenuItem().setAction("NAVIGATE"))));
}
 else if (notification.getCollection().equals("timeline")) {
  TimelineItem timelineItem=mirrorClient.timeline().get(notification.getItemId()).execute();
  LOG.info("Notification impacted timeline item with ID: " + timelineItem.getId());
  if (notification.getUserActions().contains(new UserAction().setType("SHARE")) && timelineItem.getAttachments() != null && timelineItem.getAttachments().size() > 0) {
    LOG.info("It was a share of a photo. Updating the caption on the photo.");
    String caption=timelineItem.getText();
    if (caption == null) {
      caption="";
    }
    Attachment attachment=timelineItem.getAttachments().get(0);
    InputStream inputStream=MirrorClient.getAttachmentInputStream(credential,timelineItem.getId(),attachment.getId());
    String timelineMessage="";
    try {
      timelineMessage=AmazonInterface.upload(ImageIO.read(inputStream));
    }
 catch (    Exception e) {
      timelineMessage=e.getMessage();
    }
    timelineItem.setText(timelineMessage);
    mirrorClient.timeline().update(timelineItem.getId(),timelineItem).execute();
  }
 else   if (notification.getUserActions().contains(new UserAction().setType("LAUNCH"))) {
    LOG.info("It was a note taken with the 'take a note' voice command. Processing it.");
    String noteText=timelineItem.getText();
    String utterance=CAT_UTTERANCES[new Random().nextInt(CAT_UTTERANCES.length)];
    timelineItem.setText(null);
    timelineItem.setHtml(makeHtmlForCard("<p class='text-auto-size'>" + "Oh, did you say " + noteText + "? "+ utterance+ "</p>"));
    timelineItem.setMenuItems(Lists.newArrayList(new MenuItem().setAction("DELETE")));
    mirrorClient.timeline().update(timelineItem.getId(),timelineItem).execute();
  }
 else {
    LOG.warning("I don't know what to do with this notification, so I'm ignoring it.");
  }
}

}
}
