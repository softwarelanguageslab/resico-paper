package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_106 {
public void soCodeSnippet(){
if (forecast.getForecast().getPoints().size() == 0) return null;

Double nextpredicted=forecast.getForecast().getPoints().get(0).getValue();

if (null == nextpredicted) return null;

double measuredValue=0.0;

if (current.getValue() instanceof Double) {
  measuredValue=(Double)current.getValue();
}

double difference=nextpredicted - measuredValue;

double sum=nextpredicted + measuredValue;

difference=Math.abs(difference / sum);

return new AnomalyScore(difference);

}
}
