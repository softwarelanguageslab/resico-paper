package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_192 {
public void soCodeSnippet(){
final ITimeSeries<T> history=this.getTsOriginal();

final long lastDistanceMillis=TimeUnit.MILLISECONDS.convert(history.getDeltaTime(),history.getDeltaTimeUnit());

final Date startTime=new Date(history.getEndTime().getTime());

final TimeSeries<T> tsFC=new TimeSeries<T>(startTime,history.getDeltaTime(),history.getDeltaTimeUnit());

return tsFC;

}
}
