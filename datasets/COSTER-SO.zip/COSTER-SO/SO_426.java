package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_426 {
public void soCodeSnippet(){
Logger.getInstance().info(ResourceBundle.getBundle("lang",locale).getString("File"));

Logger.getInstance().info(ResourceBundle.getBundle("lang",locale).getString("Edit"));

JMenu fileMenu=new JMenu(ResourceBundle.getBundle("lang",locale).getString("File"));

JMenu editMenu=new JMenu(ResourceBundle.getBundle("lang",locale).getString("Edit"));

menu.removeAll();

menu.add(fileMenu);

menu.add(editMenu);

}
}
