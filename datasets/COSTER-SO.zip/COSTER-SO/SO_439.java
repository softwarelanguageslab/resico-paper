package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_439 {
public void soCodeSnippet(){
StringBuilder ret=new StringBuilder();

int concat=0;

int count=0;

for (byte b : raw) {
  concat=(concat << 8) | (b & 0xff);
  count+=8;
  if (count == 24) {
    append(ret,concat,count);
    count=0;
    concat=0;
  }
}

if (count == 8) {
  concat<<=4;
  count+=4;
  append(ret,concat,count);
}
 else if (count == 16) {
  concat<<=2;
  count+=2;
  append(ret,concat,count);
}

while (ret.length() % 4 != 0) ret.append("=");

return ret.toString();

}
}
