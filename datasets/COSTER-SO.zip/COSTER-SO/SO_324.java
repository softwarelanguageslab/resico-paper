package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_324 {
public void soCodeSnippet(){
Projects projects=new Projects();

for (int i=0; i < 2; i++) {
  Project proj1=new Project();
  proj1.setId(1L);
  proj1.setName("shanghai" + i);
  proj1.setVendor("OSM" + i);
  proj1.setImageUrl("img/osm.png" + i);
  proj1.setCreateTime(new Date().getTime());
  proj1.setCreator("niles" + i);
  proj1.setInfo("Test map project for shanghai" + i);
  projects.addProject(proj1);
}

String jsonString=JSON.toJSONString(projects);

System.err.println(jsonString);

Projects projs=JSON.parseObject(jsonString,Projects.class);

System.err.println(projs.getProejct("shanghai1"));

}
}
