package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_55 {
public void soCodeSnippet(){
Command loginCommand=new LoginCommand(session,false);

commands.put("login",loginCommand);

when(session.hasLoggedInUser()).thenReturn(true);

commandMenu.listOptions();

verify(printStream,never()).println("login");

}
}
