package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_424 {
public void soCodeSnippet(){
String name=storyFileName.substring(0,storyFileName.length() - STORY_EXTENSION.length());

String[] words=name.split("_");

StringBuilder sb=new StringBuilder();

for (String word : words) {
  sb.append(StringUtils.capitalizeWord(word.toLowerCase()));
}

return sb.toString();

}
}
