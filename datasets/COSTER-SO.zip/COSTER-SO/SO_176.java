package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_176 {
public void soCodeSnippet(){
Collections.sort(frequentCandidatesKMinus1);

int allGeneratedCandidatesCounter=0;

Set<ItemSet<V>> frequentCandidateSet=new HashSet<ItemSet<V>>();

for (int i=0; i < frequentCandidatesKMinus1.size(); i++) {
  ItemSet<V> itemSet1=frequentCandidatesKMinus1.get(i);
  for (int j=i + 1; j < frequentCandidatesKMinus1.size(); j++) {
    ItemSet<V> itemSet2=frequentCandidatesKMinus1.get(j);
    ItemSet<V> difference=itemSet2.difference(itemSet1);
    Iterator<V> iterator=difference.getItems().iterator();
    while (iterator.hasNext()) {
      V next=iterator.next();
      ItemSet<V> possibleExtensionItemSet=new ItemSet<V>();
      possibleExtensionItemSet.addItem(next);
      ItemSet<V> union=itemSet1.union(possibleExtensionItemSet);
      if (union.size() != itemSet1.size() + 1) {
        continue;
      }
      allGeneratedCandidatesCounter++;
      getAndCacheSupportForItemset(union);
      frequentCandidateSet.add(union);
    }
  }
}

System.out.println(allGeneratedCandidatesCounter + " total, unique itemsets: " + frequentCandidateSet.size());

return new LinkedList<ItemSet<V>>(frequentCandidateSet);

}
}
