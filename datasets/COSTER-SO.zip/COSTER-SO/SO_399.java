package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_399 {
public void soCodeSnippet(){
final Double[] values={600.9,400.2,223.9};

final List<Double> expectedValues=new ArrayList<Double>(values.length);

for (final Double curVal : values) {
  expectedValues.add(curVal);
}

final TimeSeries<Double> ts=new TimeSeries<Double>(new Date(this.startTime),this.deltaTimeMillis,TimeUnit.MILLISECONDS);

ts.appendAll(values);

final List<Double> tsValues=ts.getValues();

Assert.assertEquals("Unexpected size of time series",values.length,ts.size());

Assert.assertEquals("Unexpected size of values list",values.length,tsValues.size());

Assert.assertEquals("values not equal",expectedValues,tsValues);

}
}
