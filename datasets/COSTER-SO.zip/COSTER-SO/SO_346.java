package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_346 {
public void soCodeSnippet(){
if ("true".equalsIgnoreCase(string)) {
  return Boolean.TRUE;
}

if ("false".equalsIgnoreCase(string)) {
  return Boolean.FALSE;
}

if ("null".equalsIgnoreCase(string)) {
  return JSONObject.NULL;
}

try {
  char initial=string.charAt(0);
  if (initial == '-' || (initial >= '0' && initial <= '9')) {
    Long value=new Long(string);
    if (value.toString().equals(string)) {
      return value;
    }
  }
}
 catch (Exception ignore) {
  try {
    Double value=new Double(string);
    if (value.toString().equals(string)) {
      return value;
    }
  }
 catch (  Exception ignoreAlso) {
  }
}

return string;

}
}
