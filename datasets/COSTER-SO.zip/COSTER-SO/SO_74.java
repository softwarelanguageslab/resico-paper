package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_74 {
public void soCodeSnippet(){
this.setPreferredSize(new Dimension(640,480));

this.bp=new BoardPanel();

JScrollPane boardScroller=new JScrollPane();

boardScroller.getViewport().add(bp);

this.getContentPane().setLayout(new BorderLayout());

this.getContentPane().add(boardScroller,BorderLayout.CENTER);

this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

this.setTitle("Explorers");

playerLabel=new JLabel("Player Name");

round=new JLabel("Round: 0");

JPanel panel=new JPanel(new GridLayout(1,2));

panel.add(playerLabel);

panel.add(round);

this.getContentPane().add(panel,BorderLayout.NORTH);

this.pack();

this.setVisible(false);

}
}
