package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_248 {
public void soCodeSnippet(){
int c;

if (this.usePrevious) {
  this.usePrevious=false;
  c=this.previous;
}
 else {
  try {
    c=this.reader.read();
  }
 catch (  IOException exception) {
    throw new JSONException(exception);
  }
  if (c <= 0) {
    this.eof=true;
    c=0;
  }
}

this.index+=1;

if (this.previous == '\r') {
  this.line+=1;
  this.character=c == '\n' ? 0 : 1;
}
 else if (c == '\n') {
  this.line+=1;
  this.character=0;
}
 else {
  this.character+=1;
}

this.previous=(char)c;

return this.previous;

}
}
