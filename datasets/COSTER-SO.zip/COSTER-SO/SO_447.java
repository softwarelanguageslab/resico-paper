package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_447 {
public void soCodeSnippet(){
double ssb=0;

double dist=0d;

dist=distanceFunction.distance(centroid,m);

ssb=c * Math.pow(dist,2);

return ssb;

}
}
