package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_206 {
public void soCodeSnippet(){
ArrayList<Card> highTrip=new ArrayList<Card>();

highTrip.add(new Card(Card.Suit.SPADE,14));

highTrip.add(new Card(Card.Suit.HEART,14));

highTrip.add(new Card(Card.Suit.DIAMOND,14));

highTrip.add(new Card(Card.Suit.SPADE,13));

highTrip.add(new Card(Card.Suit.CLUB,12));

ArrayList<Card> lowStraight=new ArrayList<Card>();

lowStraight.add(new Card(Card.Suit.SPADE,2));

lowStraight.add(new Card(Card.Suit.HEART,3));

lowStraight.add(new Card(Card.Suit.DIAMOND,4));

lowStraight.add(new Card(Card.Suit.SPADE,5));

lowStraight.add(new Card(Card.Suit.CLUB,14));

assertTrue(HandRanking.rankHand(lowStraight) > HandRanking.rankHand(highTrip));

}
}
