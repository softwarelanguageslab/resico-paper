package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_121 {
public void soCodeSnippet(){
List<Extractor> ret=new ArrayList<>();

ret.add(new FacebookApiLoader(first,last));

ret.add(new FourSquareApiLoader(first,last));

ret.add(new GooglePlusApiLoader(first,last));

ret.add(new LinkedinApiLoader(first,last));

ret.add(new PiplApiLoader(first,last));

ret.add(new TwitterApiLoader(first,last));

ret.add(new WhitepagesLoader(first,last));

return ret;

}
}
