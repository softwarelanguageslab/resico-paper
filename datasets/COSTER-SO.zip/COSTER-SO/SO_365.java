package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_365 {
public void soCodeSnippet(){
session=HibernateUtil.getSessionFactory().getCurrentSession();

session.getTransaction().begin();

Query query=session.createQuery("from FieldReport where file_name=:file_name");

query.setParameter("file_name",f.getName());

List list=query.list();

FieldReport report=null;

if (!list.isEmpty()) {
  report=(FieldReport)list.get(0);
}

if (report != null) {
  long time=((long)((Calendar.getInstance().getTimeInMillis() - f.lastModified()) / 1000));
  query=session.createQuery("from FieldErrorReport err where field_report_id= :report_id");
  query.setParameter("report_id",report.getId());
  int results=query.list().size();
  if (results > 0) {
    int timeDiff=0;
    if (results < FieldProcessor.BACKOFF_TIMES.length) {
      timeDiff=FieldProcessor.BACKOFF_TIMES[results - 1];
    }
 else {
      timeDiff=FieldProcessor.BACKOFF_TIMES[FieldProcessor.BACKOFF_TIMES.length - 1];
    }
    if (time > timeDiff) {
      File imageFile=new File(this.outgoingDir,report.getFileReference());
      File xmlFile=new File(this.outgoingDir,report.getFileName());
      HumphreyFieldMetaData metaData=new HumphreyFieldMetaData(this.regex);
      metaData.setDob(report.getDob());
      metaData.setFamilyName(report.getLastName());
      metaData.setGivenName(report.getFirstName());
      metaData.setFileReference(report.getFileReference());
      metaData.setPatientId(report.getPatientId());
      try {
        this.send(metaData,xmlFile,imageFile,report);
      }
 catch (      IOException ioex) {
        log.warning("IO Error processing " + f.getName() + ": "+ ioex.getMessage());
      }
    }
  }
}

}
}
