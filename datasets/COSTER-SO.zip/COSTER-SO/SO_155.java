package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_155 {
public void soCodeSnippet(){
Book book=mock(Book.class);

bookList.add(book);

when(reader.readLine()).thenReturn("");

when(book.getTitle()).thenReturn("");

library.checkOutItem(bookList);

verify(book).checkOut();

verify(printStream).println("Thank you! Enjoy the item");

}
}
