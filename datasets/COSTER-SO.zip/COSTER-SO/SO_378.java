package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_378 {
public void soCodeSnippet(){
container.setMaximumLogicUpdateInterval(gameSpeed);

container.setMinimumLogicUpdateInterval(gameSpeed);

container.setVSync(true);

menufont=new TrueTypeFont(new Font("Arial",Font.BOLD,28),false);

gameMap=GameMapFactory.getInstance().getGameMap(4);

app.setDisplayMode(gameMap.getWidth() * GameMapRenderer.FIELD_WIDTH,gameMap.getHeight() * GameMapRenderer.FIELD_HEIGHT,false);

gameMapRenderer=new GameMapRenderer(gameMap);

Player p1=new Player(container,this,FoodType.PEANUT,1,false);

Player p2=new Player(container,this,FoodType.JELLY,2,false);

p1.setX(gameMap.getPlayerSpawns().get(0)[0] * GameMapRenderer.FIELD_WIDTH);

p1.setY(gameMap.getPlayerSpawns().get(0)[1] * GameMapRenderer.FIELD_HEIGHT);

p2.setX(gameMap.getPlayerSpawns().get(1)[0] * GameMapRenderer.FIELD_WIDTH);

p2.setY(gameMap.getPlayerSpawns().get(1)[1] * GameMapRenderer.FIELD_HEIGHT);

players.add(p1);

players.add(p2);

Sound bgmusic=new Sound("assets/sounds/theme1.wav");

bgmusic.loop();

}
}
