package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_409 {
public void soCodeSnippet(){
Collections.sort(frequentCandidatesKMinus1);

int allGeneratedCandidatesCounter=0;

Set<ItemSet<V>> frequentCandidateSet=new HashSet<ItemSet<V>>();

for (int i=0; i < frequentCandidatesKMinus1.size(); i++) {
  ItemSet<V> prevLevelCandidate1=frequentCandidatesKMinus1.get(i);
  int currentK=prevLevelCandidate1.size() + 1;
  for (int j=i + 1; j < frequentCandidatesKMinus1.size(); j++) {
    ItemSet<V> prevLevelCandidate2=frequentCandidatesKMinus1.get(j);
    if (prevLevelCandidate1.firstKItemsIdentical(prevLevelCandidate2) == currentK - 2) {
      ItemSet<V> frequentCandidate=prevLevelCandidate1.union(prevLevelCandidate2);
      frequentCandidateSet.add(frequentCandidate);
      allGeneratedCandidatesCounter++;
      getAndCacheSupportForItemset(frequentCandidate);
    }
  }
}

return new LinkedList<ItemSet<V>>(frequentCandidateSet);

}
}
