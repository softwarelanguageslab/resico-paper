package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_32 {
public void soCodeSnippet(){
Patient p=null;

HttpTransfer sender=new HttpTransfer();

String requestParams="identifier=" + metaData.getPatientId();

sender.setHost(host);

sender.setPort(port);

int result=-1;

try {
  result=sender.read("Patient","pat",requestParams,username,password);
  if (result == 200) {
    FeedDocument doc=FeedDocument.Factory.parse(sender.getResponse());
    if (doc.getFeed().getEntryArray().length > 0) {
      EntryType entry=doc.getFeed().getEntryArray(0);
      ContentType content=entry.getContentArray(0);
      p=content.getPatient();
      p.setId(FilenameUtils.getBaseName(entry.getIdArray(0).getStringValue()));
    }
  }
}
 catch (ConnectException ex) {
  throw ex;
}
catch (XmlException ex) {
  ex.printStackTrace();
}

return p;

}
}
