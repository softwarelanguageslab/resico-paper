package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_404 {
public void soCodeSnippet(){
incrementRowCounter(2);

if (rowspecs[0].indexOf(',') != -1) {
  rowspecs=rowspecs[0].split(",");
}

for (String rowspec : rowspecs) {
  builder.appendRow(rowspec);
}

resetColumnCount();

return this;

}
}
