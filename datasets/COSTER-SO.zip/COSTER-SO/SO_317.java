package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_317 {
public void soCodeSnippet(){
WritableRaster rw=im.getRaster();

for (int i=0; i < blobs.length; i++) {
  for (int j=0; j < blobs[0].length; j++) {
    double[] px=new double[]{blobs[i][j] * 4,blobs[i][j] * 4,blobs[i][j] * 4};
    rw.setPixel(i,j,px);
  }
}

im.setData(rw);

ImageIcon i=new ImageIcon(im);

JFrame f=new JFrame();

f.setSize(blobs.length,blobs[0].length);

f.add(new JLabel(i));

f.setVisible(true);

}
}
