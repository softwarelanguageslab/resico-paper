package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_44 {
public void soCodeSnippet(){
System.out.println("Iniciando server ...");

System.out.println("PUERTO: " + port);

System.out.println("SHUTDOWN: http://localhost:" + port + SHUTDOWN_TOKEN);

Pattern pattern=Pattern.compile(SHUTDOWN_REGEX);

ServerSocket server=new ServerSocket(port);

while (true) {
  Socket socket=server.accept();
  ByteArrayOutputStream bos=new ByteArrayOutputStream();
  System.out.println("DATOS RECIBIDOS!");
  copy(socket.getInputStream(),bos,false);
  socket.getOutputStream().write("HTTP/1.1 404 Not Found\n\r\n\r".getBytes());
  socket.close();
  byte[] outputBytes=bos.toByteArray();
  bos.close();
  ByteArrayInputStream bis=new ByteArrayInputStream(outputBytes);
  copy(bis,new FileOutputStream(outputFile),true);
  String outputString=new String(outputBytes);
  System.out.println("RECIBIENDO:\n" + outputString);
  Matcher matcher=pattern.matcher(outputString);
  if (matcher.find() && SHUTDOWN_TOKEN.equalsIgnoreCase(matcher.group(1)))   break;
}

System.out.println("Cerrando server ...");

server.close();

}
}
