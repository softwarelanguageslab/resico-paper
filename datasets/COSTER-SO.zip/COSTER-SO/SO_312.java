package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_312 {
public void soCodeSnippet(){
ByteArrayOutputStream arrayBuffer=new ByteArrayOutputStream();

byte[] data=new byte[1024];

String reslut=null;

int len=0;

if (inputStream != null) {
  try {
    while ((len=inputStream.read(data)) != -1) {
      arrayBuffer.write(data,0,len);
    }
    reslut=new String(arrayBuffer.toByteArray(),encode);
  }
 catch (  IOException e) {
    e.printStackTrace();
  }
}

return reslut;

}
}
