package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_196 {
public void soCodeSnippet(){
LOG.info("Attempting to subscribe verify_token " + userId + " with callback "+ callbackUrl);

callbackUrl=callbackUrl.replace("appspot.com","Appspot.com");

Subscription subscription=new Subscription();

subscription.setCollection(collection);

subscription.setCallbackUrl(callbackUrl);

subscription.setUserToken(userId);

return getMirror(credential).subscriptions().insert(subscription).execute();

}
}
