package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_168 {
public void soCodeSnippet(){
StringBuilder signature=new StringBuilder();

signature.append(getRequestMethod());

signature.append("&");

signature.append(IOUtil.urlEncode(getBaseURL().toExternalForm()));

signature.append("&");

signature.append(getAllParameterString());

return signature.toString();

}
}
