package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_4 {
public void soCodeSnippet(){
if (speed == null) {
  return "";
}

String s="";

double num=0;

if (speed < 1024) {
  num=speed;
}
 else if (speed < (1024 * 1024)) {
  num=(double)speed / 1024;
  s="Kb/s";
}
 else if (speed < (1024 * 1024 * 1024)) {
  num=(double)speed / (1024 * 1024);
  s="Mb/s";
}
 else {
  num=(double)speed / (1024 * 1024 * 1024);
  s="Gb/s";
}

DecimalFormat oneDec=new DecimalFormat("0.0");

return oneDec.format(num) + " " + s;

}
}
