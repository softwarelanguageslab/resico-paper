package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_406 {
public void soCodeSnippet(){
this.startTime=(Date)startTime.clone();

this.deltaTime=deltaTime;

this.deltaTimeUnit=deltaTimeUnit;

this.capacity=capacity;

this.oneStepMillis=TimeUnit.MILLISECONDS.convert(this.deltaTime,this.deltaTimeUnit);

if (ITimeSeries.INFINITE_CAPACITY == capacity) {
  this.points=new CircularFifoBuffer();
}
 else {
  this.points=new CircularFifoBuffer(this.capacity);
}

this.nextTime=(Date)this.startTime.clone();

this.setNextTime();

}
}
