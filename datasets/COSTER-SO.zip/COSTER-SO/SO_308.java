package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_308 {
public void soCodeSnippet(){
int from=0;

int to=0;

while (from < this.capacity) {
  Object key=this.list[from];
  long usage=age(this.ticks[from]);
  if (usage > 0) {
    this.ticks[to]=usage;
    this.list[to]=key;
    this.map.put(key,to);
    to+=1;
  }
 else {
    this.map.remove(key);
  }
  from+=1;
}

if (to < this.capacity) {
  this.length=to;
}
 else {
  this.map.clear();
  this.length=0;
}

this.power=0;

}
}
