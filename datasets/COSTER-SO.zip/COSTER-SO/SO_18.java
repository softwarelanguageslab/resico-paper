package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_18 {
public void soCodeSnippet(){
if (this == obj) return true;

if (obj == null) return false;

if (getClass() != obj.getClass()) return false;

DataWrapper other=(DataWrapper)obj;

if (value == null) {
  if (other.value != null)   return false;
}
 else if (!value.equals(other.value)) return false;

return true;

}
}
