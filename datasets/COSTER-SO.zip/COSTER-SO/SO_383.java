package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_383 {
public void soCodeSnippet(){
String action=params.getValue("action");

if (action == null) {
  return WebUtil.error("unknown action!");
}

if ("list".equals(action)) {
  Projects projects=Global.getInstance().getProjects();
  return projects.listProjectJSON();
}

String projectName=params.getValue("project");

if (projectName == null) {
  return WebUtil.error("unknown project!");
}

Project project=Global.getInstance().getProject(projectName);

if (project == null) {
  return WebUtil.error("can not find project:" + projectName);
}

if ("module".equals(action)) {
  return project.fetchModuleInfo();
}
 else if ("moduleUpdate".equals(action)) {
  JsonObject jsonObject=params.getJsonObject("module");
  Gson gson=new Gson();
  Module module=gson.fromJson(jsonObject,Module.class);
  if (module != null) {
    project.setModule(module);
  }
}

return null;

}
}
