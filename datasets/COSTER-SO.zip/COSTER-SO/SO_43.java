package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_43 {
public void soCodeSnippet(){
Iterator<V> iterator=items.iterator();

Iterator<V> iterator2=other.items.iterator();

int counter=0;

while (iterator.hasNext() && iterator2.hasNext()) {
  V next=iterator.next();
  V next2=iterator2.next();
  if (next.equals(next2)) {
    counter++;
  }
 else   return counter;
}

return counter;

}
}
