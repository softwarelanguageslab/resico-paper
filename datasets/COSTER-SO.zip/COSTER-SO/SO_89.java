package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_89 {
public void soCodeSnippet(){
int[] indices=new int[numberOfIndices];

int[] sortedArray=array.clone();

Arrays.sort(sortedArray);

ArrayUtils.reverse(sortedArray);

double oldValue=0d;

int skip=0;

for (int i=0; i < numberOfIndices; i++) {
  if (sortedArray[i] == oldValue) {
    skip++;
  }
 else {
    skip=0;
    oldValue=sortedArray[i];
  }
  int maxIndex=getIndexOfValue(array,sortedArray[i],skip);
  if (maxIndex == -1) {
    return indices;
  }
  indices[i]=maxIndex;
}

return indices;

}
}
