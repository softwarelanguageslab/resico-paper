package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_5 {
public void soCodeSnippet(){
BufferedImage scaled=new BufferedImage(size,size,BufferedImage.TYPE_BYTE_GRAY);

Graphics g=scaled.getGraphics();

g.drawImage(image,0,0,size,size,null);

g.dispose();

Raster raster=scaled.getRaster();

double[][] pixels=new double[size][size];

for (int i=0; i < size; ++i) {
  for (int j=0; j < size; ++j) {
    pixels[i][j]=raster.getSampleDouble(i,j,0);
  }
}

int[][] trans=copy(mult(dctt2,pixels,null),lowSize,lowSize);

int sum=0;

for (int i=0; i < lowSize; ++i) {
  for (int j=0; j < lowSize; ++j) {
    if ((i | j) != 0)     sum+=trans[i][j];
  }
}

long hash=0;

int average=sum / (lowSize * lowSize - 1);

long bit=1;

for (int i=0; i < lowSize; ++i) {
  for (int j=0; j < lowSize; ++j, bit<<=1) {
    if (trans[i][j] >= average)     hash|=bit;
  }
}

return hash;

}
}
