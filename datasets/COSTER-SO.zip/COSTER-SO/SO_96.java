package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_96 {
public void soCodeSnippet(){
if (this == obj) return true;

if (obj == null) return false;

if (getClass() != obj.getClass()) return false;

Row other=(Row)obj;

if (column1 == null) {
  if (other.column1 != null)   return false;
}
 else if (!column1.equals(other.column1)) return false;

if (column2 == null) {
  if (other.column2 != null)   return false;
}
 else if (!column2.equals(other.column2)) return false;

if (column3 == null) {
  if (other.column3 != null)   return false;
}
 else if (!column3.equals(other.column3)) return false;

if (column4 != other.column4) return false;

return true;

}
}
