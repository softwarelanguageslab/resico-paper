package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_125 {
public void soCodeSnippet(){
if (Xt == XT_ARRAY_DOUBLE) return (double[])cont;

if (Xt == XT_DOUBLE) {
  double[] d=new double[1];
  d[0]=asDouble();
  return d;
}

if (Xt == XT_INT) {
  double[] d=new double[1];
  d[0]=((Integer)cont).doubleValue();
  return d;
}

if (Xt == XT_ARRAY_INT) {
  int[] i=asIntArray();
  if (i == null)   return null;
  double[] d=new double[i.length];
  int j=0;
  while (j < i.length) {
    d[j]=(double)i[j];
    j++;
  }
  return d;
}

return null;

}
}
