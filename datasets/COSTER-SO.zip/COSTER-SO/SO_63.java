package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_63 {
public void soCodeSnippet(){
PersonnageService p=new PersonnageContract(new PersonnageImpl());

p.init("totoro",501,445,255,20,9950,10,20,65);

System.err.println("au début pts de vie = " + p.pointsDeVie());

p.depot(100);

System.err.println("apres depot(100) = " + p.pointsDeVie());

p.retrait(50);

System.err.println("apres retrait(50) = " + p.pointsDeVie());

}
}
