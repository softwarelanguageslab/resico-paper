package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_153 {
public void soCodeSnippet(){
if (!Rengine.versionCheck()) {
  REngineFacade.log.error("R Version mismatch - Java files don't match library version.");
  throw new IllegalArgumentException("R Version mismatch - Java files don't match library version.");
}

REngineFacade.log.info("Creating Rengine (with arguments)");

final Rengine re=new Rengine(new String[]{"--vanilla"},false,new TextConsole());

REngineFacade.log.info("Rengine created, waiting for R");

if (!re.waitForR()) {
  REngineFacade.log.error("Cannot load R");
  throw new IllegalArgumentException("Cannot load R");
}

return re;

}
}
