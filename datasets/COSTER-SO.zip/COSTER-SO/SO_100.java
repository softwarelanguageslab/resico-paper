package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_100 {
public void soCodeSnippet(){
if (value == null || value.equals(null)) {
  return "null";
}

if (value instanceof JSONString) {
  Object object;
  try {
    object=((JSONString)value).toJSONString();
  }
 catch (  Exception e) {
    throw new JSONException(e);
  }
  if (object instanceof String) {
    return (String)object;
  }
  throw new JSONException("Bad value from toJSONString: " + object);
}

if (value instanceof Number) {
  return numberToString((Number)value);
}

if (value instanceof Boolean || value instanceof JSONObject || value instanceof JSONArray) {
  return value.toString();
}

if (value instanceof Map) {
  return new JSONObject((Map<String,Object>)value).toString();
}

if (value instanceof Collection) {
  return new JSONArray((Collection<Object>)value).toString();
}

if (value.getClass().isArray()) {
  return new JSONArray(value).toString();
}

return quote(value.toString());

}
}
