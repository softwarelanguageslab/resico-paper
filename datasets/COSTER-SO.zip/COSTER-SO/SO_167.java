package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_167 {
public void soCodeSnippet(){
if ((bearing == -1 && newBearing == -1)) return true;

if (!isLegalMove(newBearing)) {
  return false;
}

double radialBearing=newBearing % 360;

radialBearing=(radialBearing - 90) * Math.PI / 180;

double newx=this.x + (Math.cos(radialBearing) * VELOCITY);

double newy=this.y + (Math.sin(radialBearing) * VELOCITY);

if (newx < 0 || newx > 100) {
  System.err.println("Error! new x-coordinate position " + newx + " is out of bounds!");
  return false;
}

if (newy < 0 || newy > 100) {
  System.err.println("Error! new y-coordinate position " + newy + " is out of bounds!");
  return false;
}

this.x=newx;

this.y=newy;

this.bearing=newBearing;

return true;

}
}
