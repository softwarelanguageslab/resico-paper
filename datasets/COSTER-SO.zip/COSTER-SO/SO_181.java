package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_181 {
public void soCodeSnippet(){
if (uris.isEmpty()) {
  throw new RuntimeException("URL not specified");
}

List<Object> list=new ArrayList<Object>();

list.add(uris);

list.add(options.serialize());

list.add(position);

AddUriTask task=new AddUriTask(list);

task.setDownloadName(uris.get(0));

addTask(task);

}
}
