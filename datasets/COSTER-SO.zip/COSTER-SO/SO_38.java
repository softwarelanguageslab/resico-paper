package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_38 {
public void soCodeSnippet(){
ByteBuffer buf=ByteBuffer.allocate((encoded.length() / 4 + 1) * 3);

int concat=0;

int count=0;

for (char c : encoded.toCharArray()) {
  int current=getValue(c);
  if (current == -1)   continue;
  concat=(concat << 6) | current;
  count+=6;
  if (count == 24) {
    buf.put((byte)(concat >> 16));
    buf.put((byte)(concat >> 8));
    buf.put((byte)concat);
    count=0;
    concat=0;
  }
}

if (count == 12) {
  buf.put((byte)(concat >> 4));
}

if (count == 18) {
  buf.put((byte)(concat >> 10));
  buf.put((byte)(concat >> 2));
}

return buf.array();

}
}
