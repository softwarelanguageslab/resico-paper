package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_322 {
public void soCodeSnippet(){
if (JSONzip.probe) {
  int integer=find(value);
  if (integer >= 0) {
    JSONzip.log("\nDuplicate key " + value);
  }
}

if (this.length >= this.capacity) {
  compact();
}

this.list[this.length]=value;

this.map.put(value,this.length);

this.ticks[this.length]=1;

if (JSONzip.probe) {
  JSONzip.log("<" + this.length + " "+ value+ "> ");
}

this.length+=1;

}
}
