package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_340 {
public void soCodeSnippet(){
long startTime=System.currentTimeMillis();

File imageFile=new File(TEST_IMAGE);

try {
  BufferedImage image=ImageIO.read(imageFile);
  String result=AmazonInterface.upload(image);
  System.out.println(result);
}
 catch (IOException e) {
  e.printStackTrace();
}

long endTime=System.currentTimeMillis();

System.out.println(endTime - startTime);

}
}
