package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_344 {
public void soCodeSnippet(){
if (!authReq) return;

if (!connected || rt == null) throw new RSrvException(this,"Not connected");

if (authType == AT_crypt) {
  if (Key == null)   Key="rs";
  Rpacket rp=rt.request(Rtalk.CMD_login,user + "\n" + JCrypt.crypt(Key,pwd));
  if (rp != null && rp.isOk())   return;
  try {
    s.close();
  }
 catch (  Exception e) {
  }
  ;
  is=null;
  os=null;
  s=null;
  connected=false;
  throw new RSrvException(this,"login failed",rp);
}

Rpacket rp=rt.request(Rtalk.CMD_login,user + "\n" + pwd);

if (rp != null && rp.isOk()) return;

try {
  s.close();
}
 catch (Exception e) {
}

;

is=null;

os=null;

s=null;

connected=false;

throw new RSrvException(this,"login failed",rp);

}
}
