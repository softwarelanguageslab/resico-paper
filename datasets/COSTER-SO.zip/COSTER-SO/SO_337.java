package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_337 {
public void soCodeSnippet(){
String winnersMessage="Winner!";

int cardIndex=-1;

for (OpponentPanel panel : panels.values()) {
  panel.showCards();
}

if (winners.size() > 1) {
  winnersMessage="Split pot";
}

for (PlayerHand winningHand : winners) {
  Player winner=winningHand.getPlayer();
  OpponentPanel panel=panels.get(winner);
  for (  Card card : winningHand.getHand()) {
    if ((cardIndex=communityCards.indexOf(card)) >= 0) {
      communityLabels.get(cardIndex).setBorder(UIConstants.CARD_HIGHLIGHT);
    }
    int userIndex=userPlayer.getCards().indexOf(card);
    if (userIndex == 0) {
      userCardOne.setBorder(UIConstants.CARD_HIGHLIGHT);
    }
 else     if (userIndex == 1) {
      userCardTwo.setBorder(UIConstants.CARD_HIGHLIGHT);
    }
  }
  if (panel == null) {
    lblUserCards.setText(winnersMessage);
  }
 else {
    panel.setWinner(winningHand,winnersMessage);
  }
}

advanceGame.setPreferredSize(advanceGame.getPreferredSize());

advanceGame.setText("New Hand");

}
}
