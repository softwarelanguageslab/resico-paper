package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_250 {
public void soCodeSnippet(){
if (deck.size() != 52) {
  throw new GameException("Attempted to shuffle partial deck of size = " + deck.size());
}

long seedOne=19237643987l;

Random random=new Random(seedOne);

long seedTwo=new Date().getTime();

Collections.shuffle(deck,random);

Collections.shuffle(deck,new Random(seedTwo));

Collections.shuffle(deck,random);

}
}
