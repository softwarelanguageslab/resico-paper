package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_98 {
public void soCodeSnippet(){
double dist=0;

int len=vector1.length;

if (vector2.length != len) return -1;

for (int i=0; i < len; i++) {
  double temp=vector2[i] - vector1[i];
  dist+=Math.pow(temp,2);
}

return Math.sqrt(dist);

}
}
