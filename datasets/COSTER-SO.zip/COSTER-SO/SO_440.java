package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_440 {
public void soCodeSnippet(){
String nom="foo";

int largeur=50;

int hauteur=-5;

int profondeur=20;

int force=50;

int pointsDeVie=1001;

ObjetService obj=new ObjetContract(new ObjetImpl());

obj.init(Tresor.CHAINEDEVELO);

int x=1;

int y=0;

int z=0;

System.out.println(SpecTestStrings.SPEC_TEST_NAME + new Object(){
}
.getClass().getEnclosingMethod().getName());

System.out.println(SpecTestStrings.SPEC_TEST_OPERATIONS);

System.out.println("gangster.init(\"" + nom + "\", "+ largeur+ ", "+ hauteur+ ", "+ profondeur+ ", "+ force+ ", "+ pointsDeVie+ ", "+ x+ ", "+ y+ ", "+ z+ ");");

System.out.println(SpecTestStrings.SPEC_TEST_ORACLE);

System.out.println("gangster = null");

try {
  gangster.init(nom,largeur,hauteur,profondeur,force,pointsDeVie,x,y,z,obj);
  assertTrue(false);
}
 catch (ContractError e) {
  assertTrue(true);
}

}
}
