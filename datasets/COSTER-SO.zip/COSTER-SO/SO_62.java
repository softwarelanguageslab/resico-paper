package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_62 {
public void soCodeSnippet(){
log.debug("Requested Url :" + request.getURL());

XMLConfiguration xmlResponse=null;

HttpURLConnection conn=(HttpURLConnection)new URL(request.getURL()).openConnection();

conn.setRequestMethod("POST");

long opStartTime=System.currentTimeMillis();

Properties headerProps=request.getHeaderProperties();

for (String propName : headerProps.stringPropertyNames()) {
  conn.setRequestProperty(propName,headerProps.getProperty(propName));
}

conn.setDoOutput(true);

BufferedOutputStream bos=new BufferedOutputStream(conn.getOutputStream());

String bodyStr=request.getRequestBody() != null ? request.getRequestBody() : "Sending output";

log.debug("Request body:" + bodyStr);

bos.write(bodyStr.getBytes());

bos.flush();

if (conn.getResponseCode() == HttpURLConnection.HTTP_CREATED || conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
  xmlResponse=new XMLConfiguration();
  xmlResponse.load(conn.getInputStream());
}
 else {
  QcException qcException=new QcException("Response code :" + conn.getResponseCode() + ", Error message :"+ QcUtil.readData(conn.getErrorStream()));
  throw qcException;
}

long opEndTime=System.currentTimeMillis();

log.debug("Time taken to process QC request: {} secs",(opEndTime - opStartTime) / 1000);

if (log.isTraceEnabled()) {
  log.trace("POST Response XML data :\n" + ConfigurationUtils.toString(xmlResponse));
}

return xmlResponse;

}
}
