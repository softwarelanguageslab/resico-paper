package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_14 {
public void soCodeSnippet(){
GestionCombatService gc=new GestionCombatContract(new GestionCombatImpl());

gc.init(20,10,10);

System.out.println(gc.toString());

for (int i=0; i < 4; i++) {
  gc.gerer(Commande.DROITE,Commande.BAS);
  System.out.println(gc.toString());
}

for (int i=0; i < 10; i++) {
  gc.gerer(Commande.GAUCHE,Commande.DROITE);
  System.out.println(gc.toString());
}

gc.gerer(Commande.FRAPPE,Commande.FRAPPE);

System.out.println(gc.toString());

for (int i=0; i < 8; i++) {
  gc.gerer(Commande.BAS,Commande.HAUT);
  System.out.println(gc.toString());
}

for (int i=0; i < 10; i++) {
  gc.gerer(Commande.BAS,Commande.DROITE);
  System.out.println(gc.toString());
}

gc.gerer(Commande.FRAPPE,Commande.FRAPPE);

System.out.println(gc.toString());

for (int i=0; i < 4; i++) {
  gc.gerer(Commande.HAUT,Commande.BAS);
  System.out.println(gc.toString());
}

gc.gerer(Commande.FRAPPE,Commande.FRAPPE);

System.out.println(gc.toString());

}
}
