package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_53 {
public void soCodeSnippet(){
int largeur=30;

int hauteur=10;

int profondeur=10;

System.out.println(SpecTestStrings.SPEC_TEST_NAME + new Object(){
}
.getClass().getEnclosingMethod().getName());

System.out.println(SpecTestStrings.SPEC_TEST_OPERATIONS);

System.out.println("moteur.init(" + largeur + ","+ hauteur+ ","+ profondeur+ ");");

moteur.init(largeur,hauteur,profondeur);

System.out.println(SpecTestStrings.SPEC_TEST_ORACLE);

System.out.println("moteur.combat().getTerrain().nbBlocLargeur() = " + largeur);

System.out.println("moteur.combat().getTerrain().nbBlocHauteur() = " + hauteur);

System.out.println("moteur.combat().getTerrain().nbBlocProfondeur() = " + profondeur);

testInvariants();

assertEquals(moteur.combat().getTerrain().nbBlocLargeur(),largeur);

assertEquals(moteur.combat().getTerrain().nbBlocHauteur(),hauteur);

assertEquals(moteur.combat().getTerrain().nbBlocProfondeur(),profondeur);

}
}
