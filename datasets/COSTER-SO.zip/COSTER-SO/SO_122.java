package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_122 {
public void soCodeSnippet(){
Media m=Media.Factory.newInstance();

Attachment att=m.addNewContent();

Base64Binary data=att.addNewData();

Path path=FileSystems.getDefault().getPath(media.getParentFile().getAbsolutePath(),media.getName());

att.addNewContentType().setValue(Files.probeContentType(path));

att.addNewTitle().setValue(media.getName());

data.setValue(this.base64encode(media));

att.setData(data);

m.addNewSubject().addNewReference().setValue("media/med-1");

MediaDocument doc=MediaDocument.Factory.newInstance();

doc.setMedia(m);

return m;

}
}
