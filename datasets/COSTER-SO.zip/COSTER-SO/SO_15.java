package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_15 {
public void soCodeSnippet(){
this.fields=new ArrayList<XMLFieldDTO>(map.getHeight() * map.getWidth());

map.foreachField((x,y,type) -> this.fields.add(new XMLFieldDTO(x,y,type)));

this.items=map.getStartItems().stream().map(i -> new XMLItemDTO(i.getX(),i.getY(),i.getType())).collect(Collectors.toList());

for (int i=0; i < map.getPlayerSpawns().size(); i++) {
  this.spawns.add(new XMLSpawnDTO(map.getPlayerSpawns().get(i)[0],map.getPlayerSpawns().get(i)[1],map.getPlayerGlassSpawns().get(i)[0],map.getPlayerGlassSpawns().get(i)[1],i));
}

this.width=map.getWidth();

this.height=map.getHeight();

this.id=map.getMapId();

}
}
