package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_158 {
public void soCodeSnippet(){
g2.setStroke(new BasicStroke(5,BasicStroke.JOIN_ROUND,BasicStroke.CAP_ROUND));

g2.setColor(Color.BLACK);

g2.drawLine(x,y,x + width,y + height);

g2.drawLine(x + width,y,x,y + height);

g2.setColor(color);

g2.setStroke(new BasicStroke(3,BasicStroke.JOIN_ROUND,BasicStroke.CAP_ROUND));

g2.drawLine(x,y,x + width,y + height);

g2.drawLine(x + width,y,x,y + height);

}
}
