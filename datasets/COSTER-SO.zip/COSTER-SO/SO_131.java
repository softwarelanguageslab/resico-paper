package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_131 {
public void soCodeSnippet(){
program.add("LBL MOVE_TO_FOOD");

program.add("MOV");

program.add("LOK MOVE_TO_FOOD");

program.add("LBL SEARCH");

program.add("TCW");

program.add("LOK MOVE_TO_FOOD");

program.add("JMP SEARCH");

}
}
