package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_1 {
public void soCodeSnippet(){
ArrayList<Card> highFour=new ArrayList<Card>();

highFour.add(new Card(Card.Suit.SPADE,14));

highFour.add(new Card(Card.Suit.HEART,14));

highFour.add(new Card(Card.Suit.DIAMOND,14));

highFour.add(new Card(Card.Suit.SPADE,14));

highFour.add(new Card(Card.Suit.CLUB,13));

ArrayList<Card> lowStraightFlush=new ArrayList<Card>();

lowStraightFlush.add(new Card(Card.Suit.SPADE,14));

lowStraightFlush.add(new Card(Card.Suit.SPADE,2));

lowStraightFlush.add(new Card(Card.Suit.SPADE,3));

lowStraightFlush.add(new Card(Card.Suit.SPADE,4));

lowStraightFlush.add(new Card(Card.Suit.SPADE,5));

assertTrue(HandRanking.rankHand(lowStraightFlush) > HandRanking.rankHand(highFour));

}
}
