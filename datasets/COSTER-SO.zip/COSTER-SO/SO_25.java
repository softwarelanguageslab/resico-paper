package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_25 {
public void soCodeSnippet(){
this.parent=parent;

GridLayout g=new GridLayout();

g.setColumns(7);

g.setRows(0);

this.setLayout(g);

for (int i=0; i < 7; i++) {
  JLabel wd=new JLabel(parent.getString("week." + i,""));
  wd.setHorizontalAlignment(SwingConstants.CENTER);
  if (i == 0)   wd.setForeground(Color.RED);
 else   if (i == 6)   wd.setForeground(Color.gray);
  this.add(wd);
}

setDaysOfMonth(c);

this.setPreferredSize(new Dimension(200,120));

}
}
