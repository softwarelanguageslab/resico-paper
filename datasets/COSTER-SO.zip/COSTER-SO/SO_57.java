package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_57 {
public void soCodeSnippet(){
ArrayList<Card> highTwoPair=new ArrayList<Card>();

highTwoPair.add(new Card(Card.Suit.SPADE,14));

highTwoPair.add(new Card(Card.Suit.HEART,14));

highTwoPair.add(new Card(Card.Suit.DIAMOND,13));

highTwoPair.add(new Card(Card.Suit.SPADE,13));

highTwoPair.add(new Card(Card.Suit.CLUB,12));

ArrayList<Card> lowTrip=new ArrayList<Card>();

lowTrip.add(new Card(Card.Suit.SPADE,2));

lowTrip.add(new Card(Card.Suit.HEART,2));

lowTrip.add(new Card(Card.Suit.DIAMOND,2));

lowTrip.add(new Card(Card.Suit.SPADE,3));

lowTrip.add(new Card(Card.Suit.CLUB,4));

assertTrue(HandRanking.rankHand(lowTrip) > HandRanking.rankHand(highTwoPair));

}
}
