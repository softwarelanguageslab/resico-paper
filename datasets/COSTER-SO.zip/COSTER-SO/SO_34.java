package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_34 {
public void soCodeSnippet(){
Configuration configData=QcConfigDataHandler.getConfigDataHandler().getConfigData();

String testName=configData.getString("qc.test.name");

String testInstanceName=configData.getString("qc.test.instancename");

String testsetName=configData.getString("qc.testset.name");

String strTestStatus=configData.getString("qc.test.status");

testName=(!QcUtil.isEmpty(testName) ? testName : null);

testInstanceName=(!QcUtil.isEmpty(testInstanceName) ? testInstanceName : null);

testsetName=(!QcUtil.isEmpty(testsetName) ? testsetName : null);

strTestStatus=(!QcUtil.isEmpty(strTestStatus) ? strTestStatus : null);

List<String> fileNames=(!QcUtil.isEmpty(configData.getString("qc.log.filenames")) ? configData.getList("qc.log.filenames") : null);

QcTestStatus testStatus=QcTestStatus.fromValue(strTestStatus);

if (fileNames != null) {
  for (  String fileName : fileNames) {
    File file=new File(fileName);
    if (!(file.exists() && file.isFile())) {
      log.error("File is not found :" + fileName);
      System.exit(-1);
    }
  }
}

boolean success=postResult2Qc(testsetName,testName,testInstanceName,testStatus,fileNames);

if (!success) {
  System.exit(-1);
}

}
}
