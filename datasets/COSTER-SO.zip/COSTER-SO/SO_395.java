package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_395 {
public void soCodeSnippet(){
Toolkit tk=Toolkit.getDefaultToolkit();

Clipboard clip=tk.getSystemClipboard();

Transferable clipData=clip.getContents(clip);

if (clipData.isDataFlavorSupported(DataFlavor.stringFlavor)) {
  try {
    return (String)(clipData.getTransferData(DataFlavor.stringFlavor));
  }
 catch (  UnsupportedFlavorException e) {
    throw new SwingObjectRunException(ErrorSeverity.SEVERE,this.getClass());
  }
catch (  IOException e) {
    throw new SwingObjectRunException(ErrorSeverity.SEVERE,this.getClass());
  }
}

return "";

}
}
