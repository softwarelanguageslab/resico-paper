package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_156 {
public void soCodeSnippet(){
Tresor myTresor=Tresor.CINQUANTECENTIMES;

Type myType=Type.VIDE;

System.out.println(SpecTestStrings.SPEC_TEST_NAME + new Object(){
}
.getClass().getEnclosingMethod().getName());

System.out.println(SpecTestStrings.SPEC_TEST_COND_INIT);

System.out.println("objet.init(" + myTresor + ");");

objet.init(myTresor);

System.out.println(SpecTestStrings.SPEC_TEST_OPERATIONS);

System.out.println("bloc.init(" + myType + ", objet);");

System.out.println(SpecTestStrings.SPEC_TEST_ORACLE);

bloc.init(myType,objet);

testInvariants();

assertEquals(bloc.getObjet().getTresor(),myTresor);

assertEquals(bloc.getType(),myType);

}
}
