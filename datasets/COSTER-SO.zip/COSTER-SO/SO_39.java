package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_39 {
public void soCodeSnippet(){
JXErrorPane errorPane=new JXErrorPane();

ImageIcon imageIcon=null;

switch (e.getErrorSeverity()) {
case SEVERE:
  imageIcon=new javax.swing.ImageIcon(CommonUI.class.getResource("/images/error.png"));
errorPane.setErrorReporter(new InfoGatherErrorReporterFrame());
break;
case ERROR:
imageIcon=new javax.swing.ImageIcon(CommonUI.class.getResource("/images/error.png"));
break;
case WARNING:
imageIcon=new javax.swing.ImageIcon(CommonUI.class.getResource("/images/warning.png"));
break;
case INFO:
imageIcon=new javax.swing.ImageIcon(CommonUI.class.getResource("/images/info.png"));
break;
}

String detailedMessage=e.getDetailedMessage(false);

errorPane.setIcon(imageIcon);

errorPane.setErrorInfo(new ErrorInfo(e.getErrorSeverity().toString(),e.getDetailedMessage(true),detailedMessage,null,(Throwable)e,e.getErrorSeverity().getJavaLoggingLevel(),null));

errorPane.setPreferredSize(new Dimension(CommonUI.getFractionedWidth(35),CommonUI.getFractionedHeight(22)));

JXErrorPane.showFrame(null,errorPane);

}
}
