package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_380 {
public void soCodeSnippet(){
super();

register(observer);

screen=new JDialog();

screen.addWindowFocusListener(this);

screen.setSize(200,200);

screen.setResizable(false);

screen.setModal(true);

screen.getRootPane().setWindowDecorationStyle(JRootPane.QUESTION_DIALOG);

screen.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

screen.getContentPane().setLayout(new BorderLayout());

calendar=new GregorianCalendar();

setSelectedDate(selecteddate);

Calendar c=calendar;

if (selectedDate != null) c=selectedDate;

updateScreen(c);

screen.getContentPane().add(navPanel,BorderLayout.NORTH);

screen.setTitle(getString("program.title","Date Picker"));

screen.setIconImage(new javax.swing.ImageIcon(DatePicker.class.getResource("/images/calendar.png")).getImage());

}
}
