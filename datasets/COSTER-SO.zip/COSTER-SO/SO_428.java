package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_428 {
public void soCodeSnippet(){
Row r=sheet.getRow(0);

int patchColumn=-1;

for (int cn=0; cn < r.getLastCellNum(); cn++) {
  Cell c=r.getCell(cn);
  if (c == null || c.getCellType() == Cell.CELL_TYPE_BLANK) {
    continue;
  }
  if (c.getCellType() == Cell.CELL_TYPE_STRING) {
    String text=c.getStringCellValue();
    if (name.getColumnName().equals(text)) {
      patchColumn=cn;
      break;
    }
  }
}

Cell cell=row.getCell(patchColumn);

if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
  return cell.getStringCellValue();
}

if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
  return cell.getNumericCellValue() + "";
}

return "";

}
}
