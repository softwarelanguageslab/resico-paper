package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_217 {
public void soCodeSnippet(){
StringBuilder ret=new StringBuilder();

ret.append("PersonalData (");

ret.append(siteId);

ret.append(", ");

ret.append(super.toString());

ret.append(")");

return ret.toString();

}
}
