package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_211 {
public void soCodeSnippet(){
HttpTransfer sender=new HttpTransfer();

sender.setHost(this.getHost());

sender.setPort(this.getPort());

int code=sender.send("MeasurementVisualFieldHumphrey",reportText,this.authenticationUsername,this.authenticationPassword);

if (code > -1) {
  this.generateCommsLog(code,DbUtils.FHIR_RESOURCE_TYPE_DIAGNOSTIC_REPORT,fieldReport,sender.getResponse());
  if (code == 200) {
    boolean moved=file.renameTo(new File(this.archiveDir,file.getName()));
    if (!moved) {
      log.log(Level.WARNING,"Unable to move {0}",file.getAbsolutePath());
    }
  }
}

}
}
