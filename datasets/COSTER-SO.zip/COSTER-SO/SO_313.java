package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_313 {
public void soCodeSnippet(){
StringBuffer sb=new StringBuffer("{levels=(");

if (val == null) sb.append("null");
 else for (int i=0; i < val.size(); i++) {
  sb.append((i > 0) ? ",\"" : "\"");
  sb.append((String)val.elementAt(i));
  sb.append("\"");
}

;

sb.append("),ids=(");

if (id == null) sb.append("null");
 else for (int i=0; i < id.size(); i++) {
  if (i > 0)   sb.append(",");
  sb.append((Integer)id.elementAt(i));
}

;

sb.append(")}");

return sb.toString();

}
}
