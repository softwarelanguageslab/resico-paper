package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_227 {
public void soCodeSnippet(){
Configuration configData=QcConfigDataHandler.getConfigDataHandler().getConfigData();

String resultFilename=configData.getString("qc.result.file");

String resultClass=configData.getString("qc.result.class");

String className="com.vmware.qc.file." + resultClass;

ResultFile resultFile=null;

try {
  Class clz=Class.forName(className);
  resultFile=(ResultFile)clz.newInstance();
}
 catch (ClassNotFoundException cnfe) {
  log.error("Class is not found :" + className,cnfe);
}
catch (Exception ex) {
  log.error("Unable to instantiate the class :" + className,ex);
}

resultFile.setResultFileName(resultFilename);

PostResultFile2Qc postResultFile2Qc=new PostResultFile2Qc();

postResultFile2Qc.post2Qc(resultFile);

}
}
