package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_11 {
public void soCodeSnippet(){
Vector<Cluster> nonEmptyClusters=new Vector<Cluster>();

for (Cluster cluster : clusters) {
  if (cluster.getNumberOfInstances() != 0) {
    nonEmptyClusters.add(cluster);
  }
}

Cluster[] remainingClusters=new Cluster[nonEmptyClusters.size()];

for (int i=0; i < nonEmptyClusters.size(); i++) {
  remainingClusters[i]=nonEmptyClusters.elementAt(i);
}

clusters=remainingClusters;

}
}
