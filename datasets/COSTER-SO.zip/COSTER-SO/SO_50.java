package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_50 {
public void soCodeSnippet(){
addHTTPButton.setEnabled(true);

addFileButton.setEnabled(true);

pauseButton.setEnabled(true);

unpauseButton.setEnabled(true);

removeButton.setEnabled(true);

pauseAllButton.setEnabled(true);

unpauseAllButton.setEnabled(true);

optionsButton.setEnabled(true);

connectButton.setEnabled(false);

}
}
