package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_104 {
public void soCodeSnippet(){
StringWriter writer=new StringWriter();

if (getCause() != null) {
  getCause().printStackTrace(new PrintWriter(writer,true));
}
 else {
  printStackTrace(new PrintWriter(writer,true));
}

writer.flush();

StringBuilder builder=new StringBuilder("<b>");

builder.append(HTMLUtils.convertAllLineBreaksToHtml(SwingObjProps.getApplicationProperty(getErrorCode(),(Object[])getPlaceHolderValues())));

builder.append("</b>");

if (isBasic) {
  return "<html><font family=\"times new roman\">" + builder.toString() + "</font></html>";
}

StringBuilder builder2=new StringBuilder("<html><b>Message</b> <br/> <br/>");

builder2.append(builder).append("<br/> <br/>").append("<hr>").append("<br/>").append("<b>Stacktrace</b>").append("<br/> <br/>").append(HTMLUtils.convertAllLineBreaksToHtml(writer.getBuffer().toString())).append("</html>");

return builder2.toString();

}
}
