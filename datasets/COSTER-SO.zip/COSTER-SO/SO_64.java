package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_64 {
public void soCodeSnippet(){
if (words.length != posTags.length) {
  return;
}

Map<Integer,Set<Integer>> classesWithAttributes=new HashMap<Integer,Set<Integer>>();

Map<String,Set<Integer>> nounTags=POSTagger.getTagsByPOS(posTags,POSTagger.NOUN_TAGS);

for (Map.Entry<String,Set<Integer>> nounTagPositions : nounTags.entrySet()) {
  for (  int nounTagPosition : nounTagPositions.getValue()) {
    classesWithAttributes.put(nounTagPosition,new HashSet<Integer>());
  }
}

Map<String,Set<Integer>> pronounTags=POSTagger.getTagsByPOS(posTags,POSTagger.PRONOUN_TAGS);

List<NounOwner> nounOwnershipList=new ArrayList<NounOwner>();

for (Map.Entry<String,Set<Integer>> tag : pronounTags.entrySet()) {
  for (  int tagPosition : tag.getValue()) {
    nounOwnershipList.add(NounOwner.getNounOwnership(tagPosition,posTags));
  }
}

NounOwner.getOwnersWithAttributes(nounOwnershipList,classesWithAttributes);

removeEmptyClasses(classesWithAttributes);

mergeNouns(classesWithAttributes,words);

generateFiles(classesWithAttributes,words);

}
}
