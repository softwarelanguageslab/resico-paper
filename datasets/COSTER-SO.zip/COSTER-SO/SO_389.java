package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_389 {
public void soCodeSnippet(){
BlocService b=new BlocContract(new BlocImpl());

ObjetContract o=new ObjetContract(new ObjetImpl());

o.init(Tresor.CHAINEDEVELO);

b.init(Type.VIDE,o);

System.out.println(b);

}
}
