package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_157 {
public void soCodeSnippet(){
strBuff.append(getIndent()).append("<").append(m_itemName);

if (m_xmlProps != null) {
  for (int i=0; i < m_xmlProps.length; i++) {
    m_xmlProps[i].save(strBuff);
  }
}

if (this.m_subList.size() == 0) {
  strBuff.append("/>\n");
}
 else {
  strBuff.append(">\n");
}

for (int i=0; i < m_subList.size(); i++) {
  XmlItem subItem=(XmlItem)m_subList.get(i);
  subItem.saveItem(strBuff);
}

if (this.m_subList.size() == 0) {
}
 else {
  strBuff.append(getIndent()).append("</").append(m_itemName).append(">\n");
}

}
}
