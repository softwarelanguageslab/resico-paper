package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_422 {
public void soCodeSnippet(){
EmailDetailsDto dto=new EmailDetailsDto();

dto.setBody(SwingObjProps.getApplicationProperty("swingobj.infogather.emailbody",HTMLUtils.convertAllLineBreaksToHtml(txtArea.getText()),((SwingObjectsExceptions)info.getErrorException()).getDetailedMessage(false).replaceAll("<html>|</html>","")));

dto.setEmailID(EncoderDecoder.decrypt(SwingObjProps.getApplicationProperty("ssuserid")));

dto.setPassword(EncoderDecoder.decrypt(SwingObjProps.getApplicationProperty("sspassword")));

dto.setTo(SwingObjProps.getSwingObjProperty("sendemailto"));

dto.setFromName("Error In Application");

dto.setSubj("Error in Application");

EmailHelper.sendMail(dto);

}
}
