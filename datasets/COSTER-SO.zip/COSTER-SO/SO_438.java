package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_438 {
public void soCodeSnippet(){
boolean b=false;

Iterator<String> keys=jo.keys();

String string;

StringBuilder sb=new StringBuilder();

while (keys.hasNext()) {
  string=keys.next();
  if (!jo.isNull(string)) {
    if (b) {
      sb.append(';');
    }
    sb.append(Cookie.escape(string));
    sb.append("=");
    sb.append(Cookie.escape(jo.getString(string)));
    b=true;
  }
}

return sb.toString();

}
}
