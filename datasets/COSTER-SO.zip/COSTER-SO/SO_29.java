package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_29 {
public void soCodeSnippet(){
Command publicCommand=mock(Command.class);

Command privateCommand=mock(Command.class);

commands.put("public_command",publicCommand);

commands.put("private_command",privateCommand);

when(session.hasLoggedInUser()).thenReturn(true);

when(publicCommand.isPrivate()).thenReturn(false);

when(privateCommand.isPrivate()).thenReturn(true);

commandMenu.listOptions();

verify(printStream).println("public_command");

verify(printStream).println("private_command");

}
}
