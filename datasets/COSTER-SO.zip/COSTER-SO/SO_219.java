package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_219 {
public void soCodeSnippet(){
this.requestFocusInWindow();

this.setBorder(highlightBorder);

this.repaint();

this.revalidate();

this.getParent().repaint();

((JPanel)this.getParent()).revalidate();

}
}
