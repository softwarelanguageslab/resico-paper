package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_75 {
public void soCodeSnippet(){
Map<String,Set<Integer>> tagPositionMap=new HashMap<String,Set<Integer>>();

if (posList == null || posList.isEmpty()) {
  return tagPositionMap;
}

int tagArrayLength=tags.length;

for (int currentIndex=0; currentIndex < tagArrayLength; currentIndex++) {
  if (!posList.contains(tags[currentIndex])) {
    continue;
  }
  Set<Integer> tagPositionList=tagPositionMap.get(tags[currentIndex]);
  if (tagPositionList == null) {
    tagPositionList=new HashSet<Integer>();
  }
  tagPositionList.add(currentIndex);
  tagPositionMap.put(tags[currentIndex],tagPositionList);
}

return tagPositionMap;

}
}
