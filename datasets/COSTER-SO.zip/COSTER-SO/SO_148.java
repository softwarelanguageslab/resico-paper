package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_148 {
public void soCodeSnippet(){
StringBuffer strBuff=new StringBuffer();

strBuff.append("<?xml version=\"1.0\"?>");

strBuff.append("\r\n");

saveItem(strBuff);

return strBuff.toString();

}
}
