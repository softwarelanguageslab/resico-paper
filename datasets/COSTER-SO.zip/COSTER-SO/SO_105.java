package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_105 {
public void soCodeSnippet(){
setup();

ISortingTest sortingTest=null;

List<Record> sortedByFormatTitle=sortingTest.sortRecordsByFormatAndTitle(records);

System.out.println("Sorted Records by Format and Title:");

List<Record> sortedByNameAndSubtitle=sortingTest.sortRecordsByTitleAndSubtitle(records);

System.out.println("Sorted Records by Name and Subtitle:");

}
}
