package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_116 {
public void soCodeSnippet(){
int indexOfUserData=content.indexOf("globals.user");

if (indexOfUserData < 0) {
  return lepraContext;
}

content=content.substring(indexOfUserData);

content=content.substring(0,content.indexOf("};"));

content=content.substring(content.indexOf("{")) + "};";

JSONObject obj=new JSONObject(content);

lepraContext.getUser().setLogin(obj.getString("login"));

lepraContext.getUser().setId(obj.getInt("id"));

lepraContext.getUser().setGender(obj.getString("gender"));

lepraContext.getUser().setKarma(obj.getInt("karma"));

lepraContext.setCsrfToken(obj.getString("csrf_token"));

lepraContext.getUser().setCreated(new Date(obj.getLong("created") * 1000));

lepraContext.getUser().setInvitedById(obj.getInt("invited_by_id"));

return lepraContext;

}
}
