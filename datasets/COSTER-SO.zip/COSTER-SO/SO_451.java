package fold10;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_451 {
public void soCodeSnippet(){
ArrayList<Card> highStraight=new ArrayList<Card>();

highStraight.add(new Card(Card.Suit.SPADE,14));

highStraight.add(new Card(Card.Suit.HEART,13));

highStraight.add(new Card(Card.Suit.DIAMOND,12));

highStraight.add(new Card(Card.Suit.SPADE,11));

highStraight.add(new Card(Card.Suit.CLUB,10));

ArrayList<Card> lowFlush=new ArrayList<Card>();

lowFlush.add(new Card(Card.Suit.SPADE,2));

lowFlush.add(new Card(Card.Suit.SPADE,4));

lowFlush.add(new Card(Card.Suit.SPADE,5));

lowFlush.add(new Card(Card.Suit.SPADE,6));

lowFlush.add(new Card(Card.Suit.SPADE,7));

assertTrue(HandRanking.rankHand(lowFlush) > HandRanking.rankHand(highStraight));

}
}
