package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_402 {
public void soCodeSnippet(){
if (names == null) return super.removeAll(c);

boolean changed=false;

Iterator it=c.iterator();

while (it.hasNext()) changed|=remove(it.next());

return changed;

}
}
