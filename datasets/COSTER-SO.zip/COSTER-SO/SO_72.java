package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_72 {
public void soCodeSnippet(){
if (!connected || rt == null) throw new RSrvException(this,"Not connected");

int rl=r.getBinaryLength();

byte[] symn=sym.getBytes();

int sl=symn.length + 1;

if ((sl & 3) > 0) sl=(sl & 0xfffffc) + 4;

byte[] rq=new byte[sl + rl + ((rl > 0xfffff0) ? 12 : 8)];

int ic;

for (ic=0; ic < symn.length; ic++) rq[ic + 4]=symn[ic];

while (ic < sl) {
  rq[ic + 4]=0;
  ic++;
}

;

Rtalk.setHdr(Rtalk.DT_STRING,sl,rq,0);

Rtalk.setHdr(Rtalk.DT_SEXP,rl,rq,sl + 4);

r.getBinaryRepresentation(rq,sl + ((rl > 0xfffff0) ? 12 : 8));

Rpacket rp=rt.request(Rtalk.CMD_setSEXP,rq);

if (rp != null && rp.isOk()) return;

throw new RSrvException(this,"assign failed",rp);

}
}
