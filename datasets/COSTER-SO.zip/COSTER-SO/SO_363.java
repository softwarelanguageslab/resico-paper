package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_363 {
public void soCodeSnippet(){
System.out.println("Select an entry:");

System.out.println("=======================");

System.out.println("\tq: Quit");

System.out.println("\t0: None");

for (int i=0; i < day_entries.size(); i++) {
  DayEntry day_entry=day_entries.get(i);
  System.out.println("\t" + (i + 1) + ": "+ day_entry.getNotes());
}

Scanner scan=new Scanner(System.in);

String option="";

while (true) {
  System.out.print("\nChoose an entry:");
  option=scan.next();
  if (option.equalsIgnoreCase("q")) {
    System.out.println("Good bye!");
    System.exit(0);
  }
  if (!Pattern.matches("[0-9]+",option)) {
    System.out.println("You must to enter a number");
    continue;
  }
  int index=Integer.parseInt(option);
  if (index < 0 || index > day_entries.size()) {
    System.out.println("Option out of range");
    continue;
  }
  if (index == 0)   return null;
  return day_entries.get(index - 1);
}

}
}
