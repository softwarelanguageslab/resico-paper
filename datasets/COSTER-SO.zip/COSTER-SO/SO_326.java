package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_326 {
public void soCodeSnippet(){
Double d;

if (string.equals("")) {
  return string;
}

if (string.equalsIgnoreCase("true")) {
  return Boolean.TRUE;
}

if (string.equalsIgnoreCase("false")) {
  return Boolean.FALSE;
}

if (string.equalsIgnoreCase("null")) {
  return JSONObject.NULL;
}

char b=string.charAt(0);

if ((b >= '0' && b <= '9') || b == '-') {
  try {
    if (string.indexOf('.') > -1 || string.indexOf('e') > -1 || string.indexOf('E') > -1) {
      d=Double.valueOf(string);
      if (!d.isInfinite() && !d.isNaN()) {
        return d;
      }
    }
 else {
      Long myLong=new Long(string);
      if (string.equals(myLong.toString())) {
        if (myLong == myLong.intValue()) {
          return myLong.intValue();
        }
 else {
          return myLong;
        }
      }
    }
  }
 catch (  Exception ignore) {
  }
}

return string;

}
}
