package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_350 {
public void soCodeSnippet(){
final REngineFacade r2=REngineFacade.getInstance("/Library/Frameworks/R.framework/Versions/2.14/Resources/library");

r2.loadLibrary("tseries");

System.out.println(">>>>");

this.r.rEvalAsync(".libPaths(\"/Library/Frameworks/R.framework/Versions/2.14/Resources/library\")",new IREvalCallbackHandler(){
  @Override public void newREXP(  final REXP rExp){
    System.out.println(".libPaths(..path...)) >> " + rExp);
  }
}
);

try {
  Thread.sleep(1000);
}
 catch (final InterruptedException e) {
  e.printStackTrace();
}

this.r.rEvalAsync(".libPaths()",new IREvalCallbackHandler(){
  @Override public void newREXP(  final REXP rExp){
    System.out.println(".libPaths()) >> " + rExp);
  }
}
);

this.r.rEvalAsync("library(tseries)",new IREvalCallbackHandler(){
  @Override public void newREXP(  final REXP rExp){
    System.out.println("library(tse... >> " + rExp);
  }
}
);

try {
  Thread.sleep(1000);
}
 catch (final InterruptedException e) {
  e.printStackTrace();
}

this.r.rEvalAsync("(.packages())",new IREvalCallbackHandler(){
  @Override public void newREXP(  final REXP rExp){
    System.out.println("(.packages()) >> " + rExp);
  }
}
);

}
}
