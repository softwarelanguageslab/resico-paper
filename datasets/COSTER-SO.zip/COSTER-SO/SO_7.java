package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_7 {
public void soCodeSnippet(){
super(text,new ImageIcon(LabelButton.class.getResource(image)),JLabel.LEFT);

this.setFocusable(true);

if (bgColor != null) {
  this.setBackground(bgColor);
}

this.text=text;

this.icon=getIcon();

this.addMouseListener(this);

}
}
