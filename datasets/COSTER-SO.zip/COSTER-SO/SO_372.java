package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_372 {
public void soCodeSnippet(){
ArrayList<Card> highHighCard=new ArrayList<Card>();

highHighCard.add(new Card(Card.Suit.SPADE,14));

highHighCard.add(new Card(Card.Suit.HEART,13));

highHighCard.add(new Card(Card.Suit.DIAMOND,12));

highHighCard.add(new Card(Card.Suit.SPADE,11));

highHighCard.add(new Card(Card.Suit.CLUB,9));

ArrayList<Card> lowPair=new ArrayList<Card>();

lowPair.add(new Card(Card.Suit.SPADE,2));

lowPair.add(new Card(Card.Suit.HEART,2));

lowPair.add(new Card(Card.Suit.DIAMOND,3));

lowPair.add(new Card(Card.Suit.SPADE,4));

lowPair.add(new Card(Card.Suit.CLUB,5));

assertTrue(HandRanking.rankHand(lowPair) > HandRanking.rankHand(highHighCard));

}
}
