package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_186 {
public void soCodeSnippet(){
if (qName.equalsIgnoreCase("player")) {
  currentPlayer=new Player();
  currPlayerIdentifier=new PlayerIdentifier();
  currentPlayer.setPlayerIdentifier(currPlayerIdentifier);
}

if (qName.equalsIgnoreCase("fideid")) {
  fideId=true;
}

if (qName.equalsIgnoreCase("name")) {
  name=true;
}

if (qName.equalsIgnoreCase("title")) {
  title=true;
}

if (qName.equalsIgnoreCase("rating")) {
  rating=true;
}

if (qName.equalsIgnoreCase("country")) {
  country=true;
}

if (qName.equalsIgnoreCase("birthday")) {
  birthday=true;
}

}
}
