package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_220 {
public void soCodeSnippet(){
request.setCharacterEncoding("UTF-8");

ServletOutputStream sos=response.getOutputStream();

response.setContentType("text/html; charset=UTF-8");

String retInfo=null;

try {
  Params params=new Params(request,response);
  retInfo=doPostWork(params);
}
 catch (Exception ex) {
  ex.printStackTrace();
  retInfo=WebUtil.error("Exception:" + ex.getMessage());
}

if (retInfo != null) {
  if (WebConfig.SupportJsonP) {
    String callback=request.getParameter("callback");
    if (callback != null) {
      retInfo=callback + "(" + retInfo+ ");";
    }
  }
  sos.write(retInfo.getBytes("UTF-8"));
}

}
}
