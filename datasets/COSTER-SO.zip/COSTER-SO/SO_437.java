package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_437 {
public void soCodeSnippet(){
final ITimeSeries<Double> history=this.getTsOriginal();

final ITimeSeries<Double> tsFC=this.prepareForecastTS();

List<Double> allHistory=new ArrayList<Double>(history.getValues());

Double[] histValuesNotNull=MeanForecasterJava.removeNullValues(allHistory);

final double mean=StatUtils.mean(ArrayUtils.toPrimitive(histValuesNotNull));

final Double[] forecastValues=new Double[numForecastSteps];

Arrays.fill(forecastValues,mean);

tsFC.appendAll(forecastValues);

return new ForecastResult<Double>(tsFC,this.getTsOriginal());

}
}
