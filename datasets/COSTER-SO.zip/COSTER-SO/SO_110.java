package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_110 {
public void soCodeSnippet(){
productManager=new SimpleProductManager();

products=new ArrayList<Product>();

Product product=new Product();

product.setDescription("Chair");

product.setPrice(CHAIR_PRICE);

products.add(product);

product=new Product();

product.setDescription("Table");

product.setPrice(TABLE_PRICE);

products.add(product);

ProductDao productDao=new InMemoryProductDao(products);

}
}
