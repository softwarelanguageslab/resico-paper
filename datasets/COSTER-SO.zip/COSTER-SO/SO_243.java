package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_243 {
public void soCodeSnippet(){
if (!(other instanceof JSONArray)) {
  return false;
}

int len=this.length();

if (len != ((JSONArray)other).length()) {
  return false;
}

for (int i=0; i < len; i+=1) {
  Object valueThis=this.get(i);
  Object valueOther=((JSONArray)other).get(i);
  if (valueThis instanceof JSONObject) {
    if (!((JSONObject)valueThis).similar(valueOther)) {
      return false;
    }
  }
 else   if (valueThis instanceof JSONArray) {
    if (!((JSONArray)valueThis).similar(valueOther)) {
      return false;
    }
  }
 else   if (!valueThis.equals(valueOther)) {
    return false;
  }
}

return true;

}
}
