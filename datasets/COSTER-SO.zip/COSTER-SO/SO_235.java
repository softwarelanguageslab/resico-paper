package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_235 {
public void soCodeSnippet(){
GangsterService g=new GangsterContract(new GangsterImpl());

ObjetService o=new ObjetContract(new ObjetImpl());

o.init(Tresor.CHAINEDEVELO);

g.init("poutine",41,11,89,1,120,0,1,3,o);

System.err.println(g);

g.depot(50);

System.err.println(g);

g.retrait(50);

System.err.println(g);

}
}
