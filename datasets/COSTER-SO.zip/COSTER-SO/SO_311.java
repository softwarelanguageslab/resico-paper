package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_311 {
public void soCodeSnippet(){
int length=jo.length();

if (length == 0) {
  return null;
}

Iterator<String> iterator=jo.keys();

String[] names=new String[length];

int i=0;

while (iterator.hasNext()) {
  names[i]=iterator.next();
  i+=1;
}

return names;

}
}
