package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_134 {
public void soCodeSnippet(){
Map<String,String> parameters=new HashMap<String,String>();

parameters.put("username",username);

parameters.put("password",password);

parameters.put("forever",forever ? "1" : "0");

if (!StringUtils.isBlank(recaptchaChallengeField)) {
  parameters.put("recaptcha_challenge_field",recaptchaChallengeField);
}

if (!StringUtils.isBlank(recaptchaResponseField)) {
  parameters.put("recaptcha_response_field",recaptchaResponseField);
}

LepraUser lepraUser=httpClient.loadContent(LepraURI.LOGIN,parameters,LepraLoginResponseParser.getInstance());

ctx=new LepraContext(lepraUser);

httpClient.loadContent(LepraURI.getProfileURI(lepraUser.getLogin()),new CurrentUserInfoParser(ctx));

return lepraUser;

}
}
