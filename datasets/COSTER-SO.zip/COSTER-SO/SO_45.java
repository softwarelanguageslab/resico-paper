package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_45 {
public void soCodeSnippet(){
String stringRepresentation=getData().toString() + ":[";

for (GenericTreeNode<$TreeData> node : getChildren()) {
  stringRepresentation+=node.getData().toString() + ", ";
}

Pattern pattern=Pattern.compile(", $",Pattern.DOTALL);

Matcher matcher=pattern.matcher(stringRepresentation);

stringRepresentation=matcher.replaceFirst("");

stringRepresentation+="]";

return stringRepresentation;

}
}
