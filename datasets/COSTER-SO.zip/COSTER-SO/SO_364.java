package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_364 {
public void soCodeSnippet(){
Command privateCommand=mock(Command.class);

commands.put("private_command",privateCommand);

when(session.hasLoggedInUser()).thenReturn(false);

when(privateCommand.isPrivate()).thenReturn(true);

commandMenu.listOptions();

verify(printStream,never()).println("private_command");

}
}
