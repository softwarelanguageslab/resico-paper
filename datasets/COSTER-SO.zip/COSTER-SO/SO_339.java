package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_339 {
public void soCodeSnippet(){
byte[] bytes=new byte[1024];

int len=0;

while ((len=is.read(bytes)) != -1) {
  os.write(bytes,0,len);
}

if (os != null) os.close();

if (is != null) is.close();

}
}
