package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_56 {
public void soCodeSnippet(){
id=new Vector();

val=new Vector();

int j;

if (i != null && i.length > 0) for (j=0; j < i.length; j++) id.addElement(new Integer(i[j] - 1));

if (v != null && v.size() > 0) for (j=0; j < v.size(); j++) {
  REXP x=(REXP)v.elementAt(j);
  val.addElement((x == null || x.Xt != REXP.XT_STR) ? null : (String)x.cont);
}

;

}
}
