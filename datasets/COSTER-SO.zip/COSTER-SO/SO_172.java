package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_172 {
public void soCodeSnippet(){
NameValuePair[] parameters=new NameValuePair[formAttributes.size()];

String[] keys=new String[formAttributes.size()];

formAttributes.keySet().toArray(keys);

String[] values=new String[formAttributes.size()];

formAttributes.values().toArray(values);

for (int i=0; i < formAttributes.size(); i++) {
  parameters[i]=new BasicNameValuePair(keys[i],values[i]);
}

HttpUriRequest req=RequestBuilder.post().setUri(uri).addParameters(parameters).build();

return req;

}
}
