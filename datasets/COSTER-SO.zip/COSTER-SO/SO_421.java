package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_421 {
public void soCodeSnippet(){
while (salt.length() < 2) salt+="A";

StringBuffer buffer=new StringBuffer("             ");

char charZero=salt.charAt(0);

char charOne=salt.charAt(1);

buffer.setCharAt(0,charZero);

buffer.setCharAt(1,charOne);

int Eswap0=con_salt[(int)charZero];

int Eswap1=con_salt[(int)charOne] << 4;

byte key[]=new byte[8];

for (int i=0; i < key.length; i++) key[i]=(byte)0;

for (int i=0; i < key.length && i < original.length(); i++) {
  int iChar=(int)original.charAt(i);
  key[i]=(byte)(iChar << 1);
}

int schedule[]=des_set_key(key);

int out[]=body(schedule,Eswap0,Eswap1);

byte b[]=new byte[9];

intToFourBytes(out[0],b,0);

intToFourBytes(out[1],b,4);

b[8]=0;

for (int i=2, y=0, u=0x80; i < 13; i++) {
  for (int j=0, c=0; j < 6; j++) {
    c<<=1;
    if (((int)b[y] & u) != 0)     c|=1;
    u>>>=1;
    if (u == 0) {
      y++;
      u=0x80;
    }
    buffer.setCharAt(i,(char)cov_2char[c]);
  }
}

return (buffer.toString());

}
}
