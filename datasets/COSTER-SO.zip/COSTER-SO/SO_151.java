package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_151 {
public void soCodeSnippet(){
if (true) return false;

checkUserExistsSql=String.format(checkUserExistsSql,userName);

Connection conn=null;

Statement stmt=null;

ResultSet rs=null;

try {
  conn=DbConnectionFactory.getConnection();
  stmt=conn.createStatement();
  rs=stmt.executeQuery(checkUserExistsSql);
  return rs.next();
}
 catch (Exception e) {
  e.printStackTrace();
  return false;
}
 finally {
  if (conn != null) {
    try {
      conn.close();
    }
 catch (    SQLException e) {
    }
  }
  if (stmt != null) {
    try {
      stmt.close();
    }
 catch (    SQLException e) {
    }
  }
  if (rs != null) {
    try {
      rs.close();
    }
 catch (    SQLException e) {
    }
  }
}

}
}
