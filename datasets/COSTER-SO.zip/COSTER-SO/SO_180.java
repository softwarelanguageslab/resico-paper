package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_180 {
public void soCodeSnippet(){
String parsed=new String(ch,start,length).trim();

if (fideId) {
  currPlayerIdentifier.setFideId(Long.parseLong(parsed));
  fideId=false;
}

if (name) {
  currentPlayer.setName(parsed);
  name=false;
}

if (title) {
  currentPlayer.setTitle(parsed);
  title=false;
}

if (rating) {
  currentPlayer.setFideRating(Integer.parseInt(parsed));
  rating=false;
}

if (country) {
  currentPlayer.setFederation(parsed);
  country=false;
}

if (birthday) {
  currentPlayer.setBirthday(parsed);
  birthday=false;
}

}
}
