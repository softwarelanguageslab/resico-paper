package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_128 {
public void soCodeSnippet(){
List<Object> list=new ArrayList<Object>();

list.add(offset);

list.add(num);

list.add(keys);

TellWaitingTask task=new TellWaitingTask(list);

addTask(task);

}
}
