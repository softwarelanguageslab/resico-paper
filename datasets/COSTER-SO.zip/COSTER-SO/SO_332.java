package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_332 {
public void soCodeSnippet(){
String user="lqy3411@163.com";

String password="liangqingyu1229";

Properties prop=System.getProperties();

prop.put("mail.store.protocol","imap");

prop.put("mail.imap.host","imap.163.com");

Session session=Session.getInstance(prop);

int total=0;

IMAPStore store=(IMAPStore)session.getStore("imap");

store.connect(user,password);

IMAPFolder folder=(IMAPFolder)store.getFolder("INBOX");

folder.open(Folder.READ_WRITE);

total=folder.getMessageCount();

System.out.println("-----------------共有邮件：" + total + " 封--------------");

System.out.println("未读邮件数：" + folder.getUnreadMessageCount());

Message[] messages=folder.getMessages();

int messageNumber=0;

for (Message message : messages) {
  System.out.println("发送时间：" + message.getSentDate());
  System.out.println("主题：" + message.getSubject());
  System.out.println("内容：" + message.getContent());
  Flags flags=message.getFlags();
  if (flags.contains(Flags.Flag.SEEN)) {
    System.out.println("这是一封已读邮件");
  }
 else {
    System.out.println("这是一封未读邮件");
    System.out.println("发送时间：" + message.getSentDate());
    System.out.println("主题：" + message.getSubject());
    System.out.println("内容：" + message.getContent());
    Object content=message.getContent();
    if (content instanceof MimeMultipart) {
      MimeMultipart multipart=(MimeMultipart)content;
      parseMultipart(multipart);
      message.setFlag(Flags.Flag.SEEN,true);
    }
  }
  System.out.println("========================================================");
  System.out.println("========================================================");
}

if (folder != null) folder.close(true);

if (store != null) store.close();

}
}
