package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_118 {
public void soCodeSnippet(){
System.out.println("1. Buy new field");

System.out.println("2. Process field");

System.out.println("3. Buy new equipment");

System.out.println("4. Clean all equipment");

System.out.println("5. Print farm info to file");

System.out.println("0. Exit");

}
}
