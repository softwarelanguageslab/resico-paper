package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_152 {
public void soCodeSnippet(){
Double double1=supportCache.get(itemset);

if (double1 != null) {
  return double1;
}

int occurrenceCount=0;

Iterator<ItemSet<V>> transactionIterator=transactions.iterator();

while (transactionIterator.hasNext()) {
  ItemSet<V> transaction=transactionIterator.next();
  if (transaction.intersection(itemset).size() == itemset.size()) {
    occurrenceCount++;
  }
}

double d=((double)occurrenceCount) / transactions.size();

supportCache.put(itemset,d);

return d;

}
}
