package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_301 {
public void soCodeSnippet(){
PersonnageService p=new PersonnageContract(new PersonnageImpl());

p.init("totoro",501,445,255,20,9950,10,20,65);

System.err.println(p.estEquipe());

BlocService b=new BlocContract(new BlocImpl());

ObjetService tresor=new ObjetContract(new ObjetImpl());

tresor.init(Tresor.POUBELLEMETALLIQUE);

b.init(Type.VIDE,tresor);

p.ramasser(b);

System.err.println("apres ramasser : isEquipe= " + p.estEquipe());

p.jeter(b);

System.err.println("apres jeter : isEquipe= " + p.estEquipe());

}
}
