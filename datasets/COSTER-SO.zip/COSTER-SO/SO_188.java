package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_188 {
public void soCodeSnippet(){
Book book=new Book("Harry Potter",1995,true,"J.K. Rowling");

bookList.add(book);

when(reader.readLine()).thenReturn("Harry Potter");

library.returnItem(bookList);

verify(printStream).println("Thank you for returning the item");

}
}
