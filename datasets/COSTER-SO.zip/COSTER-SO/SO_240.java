package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_240 {
public void soCodeSnippet(){
if (str1 == null || str2 == null) return false;

str1=str1.replace(" ","").toLowerCase();

str2=str2.replace(" ","").toLowerCase();

char[] chars=str1.toCharArray();

List<Character> str1CharacterList=new ArrayList<Character>(chars.length);

for (char chr : chars) str1CharacterList.add(chr);

Collections.sort(str1CharacterList);

chars=str2.toCharArray();

for (char chr : chars) str1CharacterList.remove(new Character(chr));

return str1CharacterList.isEmpty();

}
}
