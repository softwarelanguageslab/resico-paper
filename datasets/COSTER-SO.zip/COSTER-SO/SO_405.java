package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_405 {
public void soCodeSnippet(){
String remoteServiceName=remoteServiceChecker.getClass().getCanonicalName();

String monitorName=ExponentialBackoffMonitor.class.getCanonicalName();

System.out.println("Starting monitor thread - " + monitorName);

while (!isInterrupted) {
  try {
    remoteServiceChecker.checkHealth();
    isRemoteServiceHealthy=true;
    numberOfFailedAttempts=0;
    System.out.println("Monitor '" + monitorName + "' found remote Service '"+ remoteServiceName+ "'"+ " health: UP");
  }
 catch (  TimeoutException e) {
    isRemoteServiceHealthy=false;
    numberOfFailedAttempts++;
    System.out.println("Monitor '" + monitorName + "' found remote Service '"+ remoteServiceName+ "'"+ " health: DOWN");
  }
  try {
    int sleepInterval=getSleepInterval();
    Thread.sleep(sleepInterval);
  }
 catch (  InterruptedException e) {
    e.printStackTrace();
    setInterrupted(true);
  }
}

System.out.println("Stopping monitor thread - " + monitorName);

}
}
