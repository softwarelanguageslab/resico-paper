package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_430 {
public void soCodeSnippet(){
log.debug("Inside doGet method");

String startLocation=request.getParameter("startLocation");

String destination=request.getParameter("destination");

TravelSearchResponse travel=null;

ITravel ts=new Rome2RioTravelImpl();

if (startLocation != null && destination != null) {
  TravelSearchRequest pathRequest=new TravelSearchRequest(startLocation,destination);
  travel=ts.findTravelPaths(pathRequest);
}

if (travel == null) {
  throw new RuntimeException("Error when retrieving travel information.");
}

StringBuffer sb=new StringBuffer();

if (travel.getRoutes() != null) {
  sb.append(prepareCurrentStatus(travel));
}

response.setCharacterEncoding("UTF-8");

response.setContentType("text/plain");

response.getWriter().write(sb.toString());

response.flushBuffer();

log.debug("Exiting doGet method");

}
}
