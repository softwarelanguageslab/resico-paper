package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_111 {
public void soCodeSnippet(){
Directory directory=null;

session=HibernateUtil.getSessionFactory().getCurrentSession();

Query query=session.createQuery("from Directory where dir_path = :dir_path ");

query.setParameter("dir_path",path);

List list=query.list();

if (!list.isEmpty()) {
  directory=(Directory)list.get(0);
}

return directory;

}
}
