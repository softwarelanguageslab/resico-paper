package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_159 {
public void soCodeSnippet(){
try {
  if (connected)   s.close();
  s=null;
}
 catch (Exception e) {
  throw new RSrvException(this,"Cannot connect: " + e.getMessage());
}

if (session != null) {
  host=session.host;
  port=session.port;
}

connected=false;

this.host=host;

this.port=port;

try {
  s=new Socket(host,port);
  s.setTcpNoDelay(true);
}
 catch (Exception sce) {
  throw new RSrvException(this,"Cannot connect: " + sce.getMessage());
}

try {
  is=s.getInputStream();
  os=s.getOutputStream();
}
 catch (Exception gse) {
  throw new RSrvException(this,"Cannot get io stream: " + gse.getMessage());
}

rt=new Rtalk(is,os);

if (session == null) {
  byte[] IDs=new byte[32];
  int n=-1;
  try {
    n=is.read(IDs);
  }
 catch (  Exception sre) {
    throw new RSrvException(this,"Error while receiving data: " + sre.getMessage());
  }
  try {
    if (n != 32) {
      throw new RSrvException(this,"Handshake failed: expected 32 bytes header, got " + n);
    }
    String ids=new String(IDs);
    if (ids.substring(0,4).compareTo("Rsrv") != 0)     throw new RSrvException(this,"Handshake failed: Rsrv signature expected, but received \"" + ids + "\" instead.");
    try {
      rsrvVersion=Integer.parseInt(ids.substring(4,8));
    }
 catch (    Exception px) {
    }
    if (rsrvVersion > 103)     throw new RSrvException(this,"Handshake failed: The server uses more recent protocol than this client.");
    if (ids.substring(8,12).compareTo("QAP1") != 0)     throw new RSrvException(this,"Handshake failed: unupported transfer protocol (" + ids.substring(8,12) + "), I talk only QAP1.");
    for (int i=12; i < 32; i+=4) {
      String attr=ids.substring(i,i + 4);
      if (attr.compareTo("ARpt") == 0) {
        if (!authReq) {
          authReq=true;
          authType=AT_plain;
        }
      }
      if (attr.compareTo("ARuc") == 0) {
        authReq=true;
        authType=AT_crypt;
      }
      if (attr.charAt(0) == 'K') {
        Key=attr.substring(1,3);
      }
    }
  }
 catch (  RSrvException innerX) {
    try {
      s.close();
    }
 catch (    Exception ex01) {
    }
    ;
    is=null;
    os=null;
    s=null;
    throw innerX;
  }
}
 else {
  try {
    os.write(session.key,0,32);
  }
 catch (  Exception sre) {
    throw new RSrvException(this,"Error while sending session key: " + sre.getMessage());
  }
  rsrvVersion=session.rsrvVersion;
}

connected=true;

lastError="OK";

}
}
