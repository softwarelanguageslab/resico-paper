package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_201 {
public void soCodeSnippet(){
InputStream file=resource.getInputStream();

HSSFWorkbook workbook=new HSSFWorkbook(file);

HSSFSheet sheet=workbook.getSheetAt(0);

Iterator<Row> rowIterator=sheet.iterator();

rowIterator.next();

while (rowIterator.hasNext()) {
  Row row=rowIterator.next();
  Player player=readPlayer(sheet,row);
  players.add(player);
}

}
}
