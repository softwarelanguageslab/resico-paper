package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_166 {
public void soCodeSnippet(){
AssociationRule<V> rule=new AssociationRule<V>(frequentItemSet,consequent);

Double support=supportCache.get(frequentItemSet.union(consequent));

Double LHSsupport=supportCache.get(frequentItemSet);

if (support != null) {
  rule.setSupport(support);
  rule.setConfidence(support / LHSsupport);
}

rules.add(rule);

}
}
