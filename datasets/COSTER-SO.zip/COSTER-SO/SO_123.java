package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_123 {
public void soCodeSnippet(){
String nom="foo";

int largeur=10;

int hauteur=50;

int profondeur=20;

int force=50;

int pointsDeVie=1001;

int x=1;

int y=0;

int z=0;

int inc=-5;

System.out.println(SpecTestStrings.SPEC_TEST_NAME + new Object(){
}
.getClass().getEnclosingMethod().getName());

System.out.println(SpecTestStrings.SPEC_TEST_COND_INIT);

System.out.println("personnage.init(\"" + nom + "\", "+ largeur+ ", "+ hauteur+ ", "+ profondeur+ ", "+ force+ ", "+ pointsDeVie+ ", "+ x+ ", "+ y+ ", "+ z+ ");");

System.out.println(SpecTestStrings.SPEC_TEST_OPERATIONS);

System.out.println("personnage.retrait(" + inc + ")");

System.out.println(SpecTestStrings.SPEC_TEST_ORACLE);

System.out.println("fail");

personnage.init(nom,largeur,hauteur,profondeur,force,pointsDeVie,x,y,z);

testInvariants();

try {
  personnage.retrait(inc);
  assertTrue(false);
}
 catch (ContractError e) {
  assertTrue(true);
}

}
}
