package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_321 {
public void soCodeSnippet(){
Book book=new Book("Harry Potter",1995,false,"J.K. Rowling");

bookList.add(book);

int longestBook="Harry Potter".length() + 4;

int longestAuthor="J.K. Rowling".length() + 4;

library.displayBooks();

String format="%-" + longestBook + "s"+ "%-"+ longestAuthor+ "s"+ "%s";

String output=String.format(format,"Harry Potter","J.K. Rowling",1995);

verify(printStream).println(output);

}
}
