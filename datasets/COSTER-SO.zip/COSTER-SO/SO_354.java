package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_354 {
public void soCodeSnippet(){
GenericTreeNode<String> root=new GenericTreeNode<String>("root");

GenericTreeNode<String> A=new GenericTreeNode<String>("A");

root.addChild(A);

GenericTreeNode<String> R=new GenericTreeNode<String>("R");

A.addChild(new GenericTreeNode<String>("T")).addChild(R);

A=new GenericTreeNode<String>("A1");

A.addChild(new GenericTreeNode<String>("T1")).addChild(R);

root.addChild(R);

assertEquals("[root, A, T, R, A1, T1, R, R]",new GenericTree<String>(A).build(GenericTreeTraversalOrderEnum.PRE_ORDER).toString());

}
}
