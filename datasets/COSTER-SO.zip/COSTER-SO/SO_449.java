package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_449 {
public void soCodeSnippet(){
JLabel label=communityLabels.get(communityCards.size());

communityCards.add(card);

label.setIcon(Util.getScaledImage(card));

label.setVisible(true);

label.invalidate();

label.repaint();

}
}
