package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_305 {
public void soCodeSnippet(){
List<GangsterService> badguys=new ArrayList<GangsterService>(gangster());

badguys.add(slick());

List<GangsterService> attackers=new ArrayList<GangsterService>();

for (GangsterService g : badguys) {
  int gx=g.getX();
  int gy=g.getY();
  int gz=g.getZ();
  if ((Math.abs(p.getX() - gx) <= 1) && (Math.abs(p.getY() - gy) <= 1) && (Math.abs(p.getZ() - gz) <= 1)) {
    attackers.add(g);
  }
}

return attackers;

}
}
