package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_144 {
public void soCodeSnippet(){
int increase=((PriceIncrease)command).getPercentage();

logger.info("Increasing prices by " + increase + "%.");

productManager.increasePrice(increase);

logger.info("returning from PriceIncreaseForm view to " + getSuccessView());

return new ModelAndView(new RedirectView(getSuccessView()));

}
}
