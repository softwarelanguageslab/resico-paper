package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_247 {
public void soCodeSnippet(){
if (key == null) {
  add(value);
  return null;
}

if (names != null) {
  int p=names.indexOf(key);
  if (p >= 0)   return super.set(p,value);
}

int i=size();

add(value);

if (names == null) names=new Vector(i + 1);

while (names.size() < i) names.add(null);

names.add(key);

return null;

}
}
