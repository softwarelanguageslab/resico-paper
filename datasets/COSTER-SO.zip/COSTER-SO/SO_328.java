package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_328 {
public void soCodeSnippet(){
ArrayList<Card> highFlush=new ArrayList<Card>();

highFlush.add(new Card(Card.Suit.SPADE,14));

highFlush.add(new Card(Card.Suit.SPADE,13));

highFlush.add(new Card(Card.Suit.SPADE,12));

highFlush.add(new Card(Card.Suit.SPADE,11));

highFlush.add(new Card(Card.Suit.SPADE,9));

ArrayList<Card> lowFullHouse=new ArrayList<Card>();

lowFullHouse.add(new Card(Card.Suit.SPADE,2));

lowFullHouse.add(new Card(Card.Suit.HEART,2));

lowFullHouse.add(new Card(Card.Suit.DIAMOND,2));

lowFullHouse.add(new Card(Card.Suit.SPADE,3));

lowFullHouse.add(new Card(Card.Suit.CLUB,3));

assertTrue(HandRanking.rankHand(lowFullHouse) > HandRanking.rankHand(highFlush));

}
}
