package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_139 {
public void soCodeSnippet(){
Tresor myTresor=Tresor.CINQUANTECENTIMES;

System.out.println(SpecTestStrings.SPEC_TEST_NAME + new Object(){
}
.getClass().getEnclosingMethod().getName());

System.out.println(SpecTestStrings.SPEC_TEST_OPERATIONS);

System.out.println("objet.init(" + myTresor + ");");

objet.init(myTresor);

System.out.println(SpecTestStrings.SPEC_TEST_ORACLE);

System.out.println("objet.getTresor() = " + myTresor);

testInvariants();

assertEquals(myTresor,objet.getTresor());

}
}
