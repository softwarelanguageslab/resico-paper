package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_65 {
public void soCodeSnippet(){
if (!hasNext()) {
  return;
}

stop();

executorService=Executors.newSingleThreadExecutor();

f=executorService.submit(new Runnable(){
  public void run(){
    suncLoad();
  }
}
);

executorService.shutdown();

}
}
