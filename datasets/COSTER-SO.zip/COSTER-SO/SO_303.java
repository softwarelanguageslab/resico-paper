package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_303 {
public void soCodeSnippet(){
Pattern pattern=Pattern.compile("^[a-zA-Z0-9]*$");

Matcher matcher=pattern.matcher(userName);

if (!matcher.matches()) return "Only alphanumeric characters permitted in user name";

if (userName.length() < 5) return "User name should have at least 5 characters.";

if (userDAO.userExists(userName)) return "User name already registered";

return null;

}
}
