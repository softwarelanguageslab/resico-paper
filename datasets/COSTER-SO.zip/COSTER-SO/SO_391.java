package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_391 {
public void soCodeSnippet(){
BASE64Encoder encoder=new BASE64Encoder();

String reportText="<MeasurementVisualFieldHumphrey><patient_id value=\"" + patientRef + "\"/>"+ "<study_datetime value=\""+ fieldReport.getStudyDate()+ " "+ fieldReport.getStudyTime()+ "\"/>"+ "<eye value=\""+ fieldReport.getEye()+ "\"/>"+ "<file_reference value=\""+ fieldReport.getFileReference()+ "\"/>"+ "<pattern value=\""+ fieldReport.getTestName()+ "\"/>"+ "<strategy value=\""+ fieldReport.getTestType()+ "\"/>"+ "<image_scan_data contentType=\"text/html\" value=\""+ encodedData+ "\"/>"+ "<image_scan_crop_data value=\""+ encodedDataThumb+ "\"/>";

if (this.isIncludeSource()) {
  reportText+="<xml_file_data value=\"" + encoder.encode(IOUtils.toByteArray(new FileInputStream(xmlFile))) + "\"/>";
}

reportText+="</MeasurementVisualFieldHumphrey>";

return reportText;

}
}
