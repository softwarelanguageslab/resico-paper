package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_386 {
public void soCodeSnippet(){
int[][] blobs=new int[(int)Board.toScreenSpace(101)][(int)Board.toScreenSpace(101)];

BufferedImage im=new BufferedImage((int)Board.toScreenSpace(101),(int)Board.toScreenSpace(101),BufferedImage.TYPE_INT_RGB);

this.paint(im.getGraphics());

Raster ra=im.getRaster();

int nblob=1;

for (int i=0; i < (int)Board.toScreenSpace(101); i++) {
  for (int j=0; j < (int)Board.toScreenSpace(101); j++) {
    double[] px=null;
    blobs[i][j]=-1;
    px=ra.getPixel(i,j,px);
    if (px[0] == 0 && px[1] == 0 && px[2] == 0) {
      if (i > 0 && blobs[i - 1][j] > 0) {
        blobs[i][j]=blobs[i - 1][j];
        if (j > 0 && blobs[i][j - 1] > 0 && blobs[i][j - 1] != blobs[i][j]) {
          blobs=replaceVals(blobs,blobs[i][j],blobs[i][j - 1]);
        }
      }
 else       if (j > 0 && blobs[i][j - 1] > 0) {
        blobs[i][j]=blobs[i][j - 1];
        if (i > 0 && blobs[i - 1][j] > 0 && blobs[i - 1][j] != blobs[i][j]) {
          blobs=replaceVals(blobs,blobs[i][j],blobs[i - 1][j]);
        }
      }
 else {
        blobs[i][j]=nblob;
        nblob++;
      }
    }
  }
}

int blobNum=blobs[0][0];

int i=0;

while (blobNum < 0) {
  i++;
  blobNum=blobs[i][i];
}

for (i=0; i < blobs.length; i++) {
  for (int j=0; j < blobs[0].length; j++) {
    if (blobs[i][j] != blobNum && blobs[i][j] != -1) {
      return false;
    }
  }
}

return true;

}
}
