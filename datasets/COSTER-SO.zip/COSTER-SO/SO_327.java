package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_327 {
public void soCodeSnippet(){
if (classNames == null || classNames.isEmpty()) {
  return;
}

File targetFile=new File(getFullFilePath((classNames.get(0))));

File parent=targetFile.getParentFile();

if (!parent.exists() && !parent.mkdirs()) {
  throw new IllegalStateException("Couldn't create dir: " + parent);
}

for (String className : classNames) {
  List<String> linesInFile=new ArrayList<String>();
  String formattedClassName=new StringBuilder(className.substring(0,1).toUpperCase()).append(className.substring(1)).toString();
  linesInFile.add(new StringBuilder().append("public class ").append(formattedClassName).append("{").toString());
  linesInFile.add("}");
  FileUtils.writeLines(new File(getFullFilePath(formattedClassName)),linesInFile);
}

}
}
