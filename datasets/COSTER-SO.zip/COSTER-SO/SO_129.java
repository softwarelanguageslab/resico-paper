package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_129 {
public void soCodeSnippet(){
char c;

StringBuilder sb;

do {
  c=next();
}
 while (Character.isWhitespace(c));

if (c == 0) {
  return null;
}

if (c == '<') {
  return XML.LT;
}

sb=new StringBuilder();

for (; ; ) {
  if (c == '<' || c == 0) {
    back();
    return sb.toString().trim();
  }
  if (c == '&') {
    sb.append(nextEntity(c));
  }
 else {
    sb.append(c);
  }
  c=next();
}

}
}
