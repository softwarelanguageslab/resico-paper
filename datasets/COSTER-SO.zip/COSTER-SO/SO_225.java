package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_225 {
public void soCodeSnippet(){
StringBuilder sb=new StringBuilder();

for (; ; ) {
  char c=next();
  if (Character.isLetterOrDigit(c) || c == '#') {
    sb.append(Character.toLowerCase(c));
  }
 else   if (c == ';') {
    break;
  }
 else {
    throw syntaxError("Missing ';' in XML entity: &" + sb);
  }
}

String string=sb.toString();

Object object=entity.get(string);

return object != null ? object : ampersand + string + ";";

}
}
