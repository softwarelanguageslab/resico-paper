package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_416 {
public void soCodeSnippet(){
Map<Object,Integer> m1=order.get(o1), m2=order.get(o2);

if (m1 == null || m2 == null) throw new IllegalArgumentException(o1 + " " + o2);

if (m1.containsKey(o2)) return m1.get(o2);

Set<Object> mutual=new HashSet<>(m1.keySet());

mutual.retainAll(m2.keySet());

for (Object key : mutual) {
  if (m1.get(key) == -m2.get(key)) {
    int ret=m1.get(key);
    m1.put(o2,ret);
    m2.put(o1,-ret);
    return ret;
  }
}

add(o1,o2);

return -1;

}
}
