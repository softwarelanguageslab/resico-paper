package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_146 {
public void soCodeSnippet(){
List<Object> list=new ArrayList<Object>();

list.add(String.valueOf(gid));

RemoveDownloadResultTask task=new RemoveDownloadResultTask(list);

task.setDownloadGid(gid);

addTask(task);

}
}
