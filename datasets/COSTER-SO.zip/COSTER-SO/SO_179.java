package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_179 {
public void soCodeSnippet(){
String md5sum=MD5sum.getHash(this.m_sourcePath.toString() + "/" + fileName,"MD5");

Object fileDataObject=fetchFileData(fileName);

if (fileDataObject instanceof JSONObject) {
  System.out.println("***********JSONObject ");
  JSONObject fileDataJSON=(JSONObject)fileDataObject;
  FileData fileData=(FileData)JSONObject.toJavaObject(fileDataJSON,FileData.class);
  fileData.setMd5Sum(md5sum);
  addFileData(fileData);
}
 else {
  System.out.println("***********FileData Object");
  FileData fileData=(FileData)fileDataObject;
  fileData.setMd5Sum(md5sum);
  addFileData(fileData);
}

savePropFile();

return md5sum;

}
}
