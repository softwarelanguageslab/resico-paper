package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_127 {
public void soCodeSnippet(){
DiagnosticReport report=DiagnosticReport.Factory.newInstance();

ResourceReference subject=report.addNewSubject();

subject.addNewReference().setValue("patient/pat-" + patientRef);

DiagnosticReportImage image=report.addNewImage();

ResourceReference imageRef=image.addNewLink();

org.hl7.fhir.String ref=imageRef.addNewReference();

ref.setValue(reference);

for (int i=0; i < attachments.length; i++) {
  ResourceReference resref=report.addNewResult();
  resref.addNewReference().setValue("#r" + (i + 1));
  ResourceInline inline=report.addNewContained();
  Observation o=inline.addNewObservation();
  o.setId("r" + (i + 1));
  Attachment att=o.addNewValueAttachment();
  Base64Binary binary=att.addNewData();
  Path path=FileSystems.getDefault().getPath(attachments[i].getParentFile().getAbsolutePath(),attachments[i].getName());
  att.addNewContentType().setValue(Files.probeContentType(path));
  att.addNewTitle().setValue(attachments[i].getName());
  binary.setValue(this.base64encode(attachments[i]));
  att.setData(binary);
}

DiagnosticReportDocument doc=DiagnosticReportDocument.Factory.newInstance();

doc.setDiagnosticReport(report);

return report;

}
}
