package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_376 {
public void soCodeSnippet(){
double dx=x1 - x2;

double dy=y1 - y2;

double bearing=Math.atan2(dy,dx) * 180 / Math.PI - 90;

if (bearing < 0) bearing+=360;

return bearing;

}
}
