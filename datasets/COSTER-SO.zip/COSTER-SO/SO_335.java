package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_335 {
public void soCodeSnippet(){
setResizable(false);

contentPane=new JPanel();

buttonCancel=new JButton();

buttonCancel.setText("Exit");

errorText=new JLabel("New label");

JProgressBar progressBar=new JProgressBar();

progressBar.setIndeterminate(true);

progressBar.setStringPainted(false);

GroupLayout gl_contentPane=new GroupLayout(contentPane);

gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane.createSequentialGroup().addContainerGap().addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addComponent(errorText,GroupLayout.DEFAULT_SIZE,280,Short.MAX_VALUE).addComponent(buttonCancel,Alignment.TRAILING).addComponent(progressBar,GroupLayout.DEFAULT_SIZE,280,Short.MAX_VALUE)).addContainerGap()));

gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(Alignment.TRAILING,gl_contentPane.createSequentialGroup().addContainerGap().addComponent(errorText).addPreferredGap(ComponentPlacement.RELATED).addComponent(progressBar,GroupLayout.PREFERRED_SIZE,GroupLayout.DEFAULT_SIZE,GroupLayout.PREFERRED_SIZE).addPreferredGap(ComponentPlacement.RELATED,71,Short.MAX_VALUE).addComponent(buttonCancel).addContainerGap()));

contentPane.setLayout(gl_contentPane);

setContentPane(contentPane);

setModal(true);

getRootPane().setDefaultButton(buttonCancel);

buttonCancel.addActionListener(new ActionListener(){
  @Override public void actionPerformed(  ActionEvent e){
    onCancel();
  }
}
);

setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

addWindowListener(new WindowAdapter(){
  @Override public void windowClosing(  WindowEvent e){
    onCancel();
  }
}
);

contentPane.registerKeyboardAction(new ActionListener(){
  @Override public void actionPerformed(  ActionEvent e){
    onCancel();
  }
}
,KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE,0),JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

}
}
