package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_307 {
public void soCodeSnippet(){
final FileDialog fd=new FileDialog(new Frame(),(newFile == 0) ? "Select a file" : "Select a new file",(newFile == 0) ? FileDialog.LOAD : FileDialog.SAVE);

fd.show();

String res=null;

if (fd.getDirectory() != null) {
  res=fd.getDirectory();
}

if (fd.getFile() != null) {
  res=(res == null) ? fd.getFile() : (res + fd.getFile());
}

return res;

}
}
