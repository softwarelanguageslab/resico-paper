package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_213 {
public void soCodeSnippet(){
char c;

char q;

StringBuilder sb=new StringBuilder();

do {
  c=next();
}
 while (Character.isWhitespace(c));

if (c == '"' || c == '\'') {
  q=c;
  for (; ; ) {
    c=next();
    if (c < ' ') {
      throw syntaxError("Unterminated string.");
    }
    if (c == q) {
      return sb.toString();
    }
    sb.append(c);
  }
}

for (; ; ) {
  if (c == 0 || Character.isWhitespace(c)) {
    return sb.toString();
  }
  sb.append(c);
  c=next();
}

}
}
