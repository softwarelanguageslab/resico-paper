package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_115 {
public void soCodeSnippet(){
if (StringUtils.isBlank(content) || "null".equalsIgnoreCase(content.trim())) {
  throw new LepraLoginException();
}

JSONObject obj=new JSONObject(content);

String status=obj.getString("status");

if (status == null || !"OK".equalsIgnoreCase(status)) {
  JSONArray errors=obj.optJSONArray("errors");
  if (errors != null && errors.length() > 0) {
    for (int i=0; i < errors.length(); i++) {
      JSONObject error=errors.getJSONObject(i);
      if (error != null && StringUtils.equalsIgnoreCase(error.getString("code"),"invalid_password")) {
        throw new LepraInvalidLoginPasswordException();
      }
      if (error != null && StringUtils.equalsIgnoreCase(error.getString("code"),"captcha_required")) {
        throw new LepraCaptchaRequired();
      }
    }
  }
  throw new LepraLoginException();
}

JSONObject user=obj.getJSONObject("user");

return new LepraUser(user.getInt("id"),user.getString("login"),user.getString("gender"),user.getInt("karma"));

}
}
