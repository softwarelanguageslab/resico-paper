package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_199 {
public void soCodeSnippet(){
ICircuitBreaker circuitBreaker=CircuitBreakerFactory.get();

IExternalService externalService=new IntermittentExternalService();

circuitBreaker.startRemoteServiceRecurrentMonitor(externalService);

for (int i=0; i < 400; i++) makeCall(circuitBreaker,externalService);

System.out.println(String.format("numTimeouts %s , numSuccessful %s , numSuccessfullyCaughtUnhealthy %s ",numTimeouts,numSuccessful,numSuccessfullyCaughtUnhealthy));

circuitBreaker.stopRemoteServiceRecurrentMonitor(externalService);

circuitBreaker.startRemoteServiceExponentialBackoffMonitor(externalService);

for (int i=0; i < 400; i++) makeCall(circuitBreaker,externalService);

System.out.println(String.format("numTimeouts %s , numSuccessful %s , numSuccessfullyCaughtUnhealthy %s ",numTimeouts,numSuccessful,numSuccessfullyCaughtUnhealthy));

circuitBreaker.stopRemoteServiceExponentialBackoffMonitor(externalService);

}
}
