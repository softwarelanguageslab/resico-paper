package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_310 {
public void soCodeSnippet(){
boolean b;

char c;

int i;

int j;

int offset=0;

int length=to.length();

char[] circle=new char[length];

for (i=0; i < length; i+=1) {
  c=next();
  if (c == 0) {
    return false;
  }
  circle[i]=c;
}

for (; ; ) {
  j=offset;
  b=true;
  for (i=0; i < length; i+=1) {
    if (circle[j] != to.charAt(i)) {
      b=false;
      break;
    }
    j+=1;
    if (j >= length) {
      j-=length;
    }
  }
  if (b) {
    return true;
  }
  c=next();
  if (c == 0) {
    return false;
  }
  circle[offset]=c;
  offset+=1;
  if (offset >= length) {
    offset-=length;
  }
}

}
}
