package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_150 {
public void soCodeSnippet(){
String attachmentId=req.getParameter("attachment");

String timelineItemId=req.getParameter("timelineItem");

if (attachmentId == null || timelineItemId == null) {
  LOG.warning("attempted to load image attachment with missing IDs");
  resp.sendError(400);
}

Credential credential=AuthUtil.getCredential(req);

String contentType=MirrorClient.getAttachmentContentType(credential,timelineItemId,attachmentId);

InputStream attachmentInputStream=MirrorClient.getAttachmentInputStream(credential,timelineItemId,attachmentId);

resp.setContentType(contentType);

ByteStreams.copy(attachmentInputStream,resp.getOutputStream());

}
}
