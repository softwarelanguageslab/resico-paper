package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_40 {
public void soCodeSnippet(){
int l=0;

int rxt=Xt;

if (Xt == XT_LIST || Xt == XT_LIST_TAG || Xt == XT_LIST_NOTAG) rxt=(asList() != null && asList().isNamed()) ? XT_LIST_TAG : XT_LIST_NOTAG;

if (Xt == XT_VECTOR_STR) rxt=XT_ARRAY_STR;

if (Xt == XT_VECTOR && asList() != null && asList().isNamed()) setAttribute("names",new REXP(asList().keys()));

boolean hasAttr=false;

RList al=null;

if (attr != null) al=attr.asList();

if (al != null && al.size() > 0) hasAttr=true;

if (hasAttr) l+=attr.getBinaryLength();

switch (rxt) {
case XT_NULL:
case XT_S4:
  break;
case XT_INT:
l+=4;
break;
case XT_DOUBLE:
l+=8;
break;
case XT_STR:
case XT_SYMNAME:
l+=(cont == null) ? 1 : ((String)cont).length() + 1;
if ((l & 3) > 0) l=l - (l & 3) + 4;
break;
case XT_ARRAY_INT:
l+=(cont == null) ? 0 : ((int[])cont).length * 4;
break;
case XT_ARRAY_DOUBLE:
l+=(cont == null) ? 0 : ((double[])cont).length * 8;
break;
case XT_ARRAY_CPLX:
l+=(cont == null) ? 0 : ((double[])cont).length * 8;
break;
case XT_LIST_TAG:
case XT_LIST_NOTAG:
case XT_LIST:
case XT_VECTOR:
if (asList() != null) {
RList lst=asList();
int i=0;
while (i < lst.size()) {
REXP x=lst.at(i);
l+=(x == null) ? 4 : x.getBinaryLength();
if (rxt == XT_LIST_TAG) {
int pl=l;
String s=lst.keyAt(i);
l+=4;
l+=(s == null) ? 1 : (s.length() + 1);
if ((l & 3) > 0) l=l - (l & 3) + 4;
}
i++;
}
if ((l & 3) > 0) l=l - (l & 3) + 4;
}
break;
case XT_VECTOR_STR:
if (cont != null) {
String sa[]=(String[])cont;
int i=0;
while (i < sa.length) {
l+=4;
l+=(sa[i] == null) ? 1 : (sa[i].length() + 1);
if ((l & 3) > 0) l=l - (l & 3) + 4;
i++;
}
break;
}
case XT_ARRAY_STR:
if (cachedBinaryLength < 0) {
if (cont == null) cachedBinaryLength=4;
 else {
String sa[]=(String[])cont;
int i=0, io=0;
while (i < sa.length) {
if (sa[i] != null) {
try {
byte b[]=sa[i].getBytes(Rconnection.transferCharset);
io+=b.length;
b=null;
}
 catch (java.io.UnsupportedEncodingException uex) {
}
}
io++;
i++;
}
while ((io & 3) != 0) io++;
cachedBinaryLength=io + 4;
if (cachedBinaryLength > 0xfffff0) cachedBinaryLength+=4;
}
}
return l + (int)cachedBinaryLength;
}

if (l > 0xfffff0) l+=4;

return l + 4;

}
}
