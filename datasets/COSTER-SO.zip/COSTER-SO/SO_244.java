package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_244 {
public void soCodeSnippet(){
final int prime=31;

int result=1;

result=prime * result + ((column1 == null) ? 0 : column1.hashCode());

result=prime * result + ((column2 == null) ? 0 : column2.hashCode());

result=prime * result + ((column3 == null) ? 0 : column3.hashCode());

result=prime * result + (column4 ? 1231 : 1237);

return result;

}
}
