package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_412 {
public void soCodeSnippet(){
List<TestInstanceInfo> allTestInstances=new ArrayList<TestInstanceInfo>();

List<TestInstanceInfo> testInstances=null;

int startIndex=1;

do {
  testInstances=getTestInstances(testSetIds,startIndex);
  if (testInstances != null && !testInstances.isEmpty()) {
    allTestInstances.addAll(testInstances);
    startIndex=startIndex + testInstances.size();
  }
}
 while (testInstances != null && testInstances.size() >= 500);

return (allTestInstances != null && !allTestInstances.isEmpty() ? allTestInstances : null);

}
}
