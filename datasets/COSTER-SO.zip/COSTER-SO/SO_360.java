package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_360 {
public void soCodeSnippet(){
this();

char c;

String key;

if (x.nextClean() != '{') {
  throw x.syntaxError("A JSONObject text must begin with '{'");
}

for (; ; ) {
  c=x.nextClean();
switch (c) {
case 0:
    throw x.syntaxError("A JSONObject text must end with '}'");
case '}':
  return;
default :
x.back();
key=x.nextValue().toString();
}
c=x.nextClean();
if (c != ':') {
throw x.syntaxError("Expected a ':' after a key");
}
this.putOnce(key,x.nextValue());
switch (x.nextClean()) {
case ';':
case ',':
if (x.nextClean() == '}') {
return;
}
x.back();
break;
case '}':
return;
default :
throw x.syntaxError("Expected a ',' or '}'");
}
}

}
}
