package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_388 {
public void soCodeSnippet(){
number=(number - 1);

double phi=1.618033988;

double psi=-0.618033988;

double fibNumber=(Math.pow(phi,number) - Math.pow(psi,number)) / (Math.sqrt(5));

double fibValue=Math.ceil(fibNumber);

return (new Double(fibValue)).intValue();

}
}
