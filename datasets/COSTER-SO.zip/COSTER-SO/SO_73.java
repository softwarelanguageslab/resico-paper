package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_73 {
public void soCodeSnippet(){
if (!content.contains("{")) {
  System.out.println(content);
  return null;
}

content=content.substring(content.indexOf("{"));

Integer newOffset=null;

String template=null;

try {
  JSONObject obj=new JSONObject(content);
  template=obj.getString("template");
  if (!obj.isNull("offset")) {
    newOffset=obj.getInt("offset");
  }
}
 catch (JSONException e) {
  e.printStackTrace();
}

if (StringUtils.isBlank(template)) {
  return null;
}

String[] rawPostArray=template.split(POST_SEPARATOR,-1);

for (String rawPost : rawPostArray) {
  if (StringUtils.isNotBlank(rawPost)) {
    handler.processContent(postParser(rawPost));
  }
}

return newOffset;

}
}
