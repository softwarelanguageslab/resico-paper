package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_309 {
public void soCodeSnippet(){
out.beginObject();

out.name(siteToken).value(value.getWebsiteId());

out.name(dataToken).value(value.getId());

for (Entry<String,String> entry : value.entrySet()) {
  out.name(entry.getKey()).value(entry.getValue());
}

out.endObject();

}
}
