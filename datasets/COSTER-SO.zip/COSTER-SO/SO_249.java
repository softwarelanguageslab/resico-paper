package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_249 {
public void soCodeSnippet(){
String instruction=bug.getInstruction(pc);

String[] tokens=instruction.split(" ");

String cmd=tokens[0];

if ("MOV".equals(cmd)) {
  bug.move();
  pc++;
}
 else if ("TCW".equals(cmd)) {
  bug.turnClockwise();
  pc++;
}
 else if ("TCC".equals(cmd)) {
  bug.turnCounterClockwise();
  pc++;
}
 else if ("LOK".equals(cmd)) {
  if (bug.canSeeFood()) {
    String label=tokens[1];
    pc=labels.get(label);
  }
 else {
    pc++;
  }
}
 else if ("END".equals(cmd)) {
  return 1;
}
 else if ("LBL".equals(cmd)) {
  if (tokens.length < 2) {
    System.out.println("Error: LBL must specify a label name");
    return 1;
  }
 else {
    String label=tokens[1];
    labels.put(label,pc);
    pc++;
  }
}
 else if ("JMP".equals(cmd)) {
  if (tokens.length < 2) {
    System.out.println("Error: LBL must specify a label name");
    return 1;
  }
 else {
    String label=tokens[1];
    pc=labels.get(label);
  }
}
 else if ("STO".equals(cmd)) {
  if (tokens.length < 3) {
    System.out.println("Error: STO must specify a variable name and a integer value");
    return 1;
  }
 else {
    String variableName=tokens[1];
    Integer value=Integer.valueOf(tokens[2]);
    bug.setVariable(variableName,value);
    pc++;
  }
}
 else if ("INC".equals(cmd)) {
  if (tokens.length < 2) {
    System.out.println("Error: INC must specify a variable name");
    return 1;
  }
 else {
    String variableName=tokens[1];
    bug.incrementVariable(variableName);
    pc++;
  }
}
 else if ("DEC".equals(cmd)) {
  if (tokens.length < 2) {
    System.out.println("Error: DEC must specify a variable name");
    return 1;
  }
 else {
    String variableName=tokens[1];
    bug.decrementVariable(variableName);
    pc++;
  }
}
 else if ("BEQ".equals(cmd)) {
  if (tokens.length < 4) {
    System.out.println("Error: BEQ must specify a variable name, an integer value, and a label to jump to if they are equal");
    return 1;
  }
 else {
    String variableName=tokens[1];
    Integer value=Integer.valueOf(tokens[2]);
    String label=tokens[3];
    if (bug.getVariable(variableName).equals(value)) {
      if (labels.containsKey(label)) {
        pc=labels.get(label);
      }
 else {
        System.out.println("Error: BEQ specified a non-existent label " + label);
        return 1;
      }
    }
 else {
      pc++;
    }
  }
}
 else if ("BRD".equals(cmd)) {
  if (tokens.length < 3) {
    System.out.println("Error: BRD must specify a variable name and an integer value");
    return 1;
  }
 else {
    String variableName=tokens[1];
    Integer value=Integer.valueOf(tokens[2]);
    bug.breedWhenReady(variableName,value);
  }
  pc++;
}
 else if ("WAI".equals(cmd)) {
  bug.waitForOneCycle();
}
 else {
  System.out.println("Unknown instruction " + cmd + " at pc "+ pc);
  pc++;
}

return 0;

}
}
