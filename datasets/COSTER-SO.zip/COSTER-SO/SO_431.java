package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_431 {
public void soCodeSnippet(){
CommandMenu commandMenu=mock(CommandMenu.class);

PrintStream printStream=mock(PrintStream.class);

BibliotecaApp bibliotechaApp=new BibliotecaApp(commandMenu,printStream);

when(commandMenu.promptUser()).thenReturn("list books").thenReturn("quit");

bibliotechaApp.start();

InOrder inOrder=inOrder(printStream,commandMenu);

inOrder.verify(printStream).println("Welcome to the library!");

inOrder.verify(commandMenu).listOptions();

inOrder.verify(commandMenu,times(2)).promptUser();

inOrder.verify(commandMenu,times(1)).executeCommand(anyString());

}
}
