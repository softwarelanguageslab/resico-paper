package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_77 {
public void soCodeSnippet(){
if (size == null) {
  return "";
}

String s="";

double num=0;

if (size < 1024) {
  num=size;
}
 else if (size < (1024 * 1024)) {
  num=(double)size / 1024;
  s="Kb";
}
 else if (size < (1024 * 1024 * 1024)) {
  num=(double)size / (1024 * 1024);
  s="Mb";
}
 else {
  num=(double)size / (1024 * 1024 * 1024);
  s="Gb";
}

DecimalFormat oneDec=new DecimalFormat("0.0");

return oneDec.format(num) + " " + s;

}
}
