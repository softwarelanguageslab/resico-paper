package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_355 {
public void soCodeSnippet(){
request.setHeader("Accept","application/json");

request.setHeader("Content-Type","application/json");

request.setHeader("Authorization","Basic " + Base64.encodeBase64String(credentials.getBytes()).trim());

if (parameters != null) {
  StringEntity reqentity=new StringEntity(parameters);
  if (request instanceof HttpEntityEnclosingRequestBase)   ((HttpEntityEnclosingRequestBase)request).setEntity(reqentity);
 else   throw new ClientProtocolException("Method not allowed. Don't send parameters or use POST or PUT");
}

HttpResponse response=httpclient.execute(request);

System.out.println(response.getStatusLine());

if (response.getStatusLine().getStatusCode() == 404) {
  System.out.println("Service not found");
  return null;
}

ByteArrayOutputStream bos=new ByteArrayOutputStream();

HttpEntity entity=response.getEntity();

if (entity != null) entity.writeTo(bos);

Header[] locations=response.getHeaders("Location");

if (locations == null || locations.length == 0) return new ByteArrayInputStream(bos.toByteArray());

String uri="https://" + HOST;

uri+=locations[0].getValue();

HttpGet get=new HttpGet(uri);

return send(httpclient,get,null);

}
}
