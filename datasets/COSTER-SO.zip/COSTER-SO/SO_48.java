package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_48 {
public void soCodeSnippet(){
StringBuilder builder=new StringBuilder();

builder.append("\n");

builder.append("Error Code:" + errorCode);

builder.append("\n");

builder.append("Error Description:" + SwingObjProps.getApplicationProperty(errorCode,placeHolderValues));

builder.append("\n");

builder.append("Error Severity:" + errorSeverity.toString());

builder.append("\n");

builder.append("Message:" + message);

builder.append("\n");

return builder.toString();

}
}
