package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_228 {
public void soCodeSnippet(){
ColumnInfo info=new ColumnInfo();

info.setFieldName(field.getName());

info.setIndex(column.index());

if (AnnotationConstants.COLUMN_NAME_USE_KEY.name().equals(column.name())) {
  info.setHeading(SwingObjProps.getApplicationProperty(column.key()));
}
 else {
  info.setHeading(column.name());
}

info.setEditable(column.editable());

if (column.editable()) {
  isTableEditable=true;
}

if (column.type() == Class.class) {
  info.setType(ClassUtils.primitiveToWrapper(field.getType()));
}
 else {
  info.setType(column.type());
}

columns.put(column.index(),info);

}
}
