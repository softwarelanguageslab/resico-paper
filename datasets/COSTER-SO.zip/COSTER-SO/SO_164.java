package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_164 {
public void soCodeSnippet(){
HashMap<PlayerHand,Long> ranks=new HashMap<PlayerHand,Long>();

ArrayList<Card> allSeven=new ArrayList<Card>();

for (Player player : players) {
  allSeven.clear();
  allSeven.addAll(visible);
  allSeven.addAll(player.getCards());
  ICombinatoricsVector<Card> originalVector=Factory.createVector(allSeven);
  Generator<Card> gen=Factory.createSimpleCombinationGenerator(originalVector,5);
  long bestRank=0;
  ArrayList<Card> bestHand=null;
  for (  ICombinatoricsVector<Card> combination : gen) {
    ArrayList<Card> tempHand=new ArrayList<Card>(combination.getVector());
    long tempRank=HandRanking.rankHand(tempHand);
    if (tempRank > bestRank) {
      bestRank=tempRank;
      bestHand=tempHand;
    }
  }
  ranks.put(new PlayerHand(player,bestHand),bestRank);
}

Vector<PlayerHand> winners=new Vector<PlayerHand>();

long highHand=0;

for (Entry<PlayerHand,Long> entry : ranks.entrySet()) {
  long playerScore=entry.getValue();
  if (playerScore > highHand) {
    winners.clear();
    winners.add(entry.getKey());
    highHand=playerScore;
  }
 else   if (playerScore == highHand) {
    winners.add(entry.getKey());
  }
}

return winners;

}
}
