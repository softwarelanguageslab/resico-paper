package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_24 {
public void soCodeSnippet(){
GraphicsConfiguration gc=component.getGraphicsConfiguration();

Rectangle bounds=gc.getBounds();

int x=(int)(bounds.getWidth() - component.getWidth()) / 2;

int y=(int)(bounds.getHeight() - component.getHeight()) / 2;

component.setLocation(x,y);

}
}
