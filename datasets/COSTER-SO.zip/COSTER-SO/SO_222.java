package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_222 {
public void soCodeSnippet(){
Iterator<String> titles=disambiguation.iterator();

FieldBuilder joinedTitleBuilder=new FieldBuilder();

while (titles.hasNext()) {
  Request request=getDisambiguationPageRequest(titles);
  joinedTitleBuilder=disambiguationSearch(joinedTitleBuilder,request);
}

Map<String,String> joinedTitles=new HashMap<>();

joinedTitleBuilder.addTo(joinedTitles);

for (Entry<String,String> title : joinedTitles.entrySet()) {
  addChangeToMap(changeMap,title.getKey(),title.getValue());
}

return changeMap;

}
}
