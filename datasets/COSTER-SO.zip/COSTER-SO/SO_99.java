package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_99 {
public void soCodeSnippet(){
String ak, vardas, pavarde, model;

ResultSet rs=null;

Connection postGresConn=DbHelper.getConnection();

printUI();

switch (inputInt()) {
case 1:
  rs=DbHelper.queryPilots(postGresConn);
printPilots(rs);
break;
case 2:
rs=DbHelper.queryJets(postGresConn);
printJets(rs);
break;
case 3:
model=inputString();
rs=DbHelper.searchJetByModel(postGresConn,model);
printJets(rs);
break;
case 4:
ak=inputString();
int jetId=inputInt();
DbHelper.updatePilotJet(postGresConn,ak,jetId);
break;
case 5:
ak=inputString();
int pilotuoja=inputInt();
vardas=inputString();
pavarde=inputString();
int nukove=inputInt();
DbHelper.insertPilot(postGresConn,ak,pilotuoja,vardas,pavarde,nukove);
break;
case 6:
ak=inputString();
DbHelper.deletePilot(postGresConn,ak);
break;
default :
System.out.println("Wrong choice!");
break;
}

try {
  postGresConn.close();
}
 catch (SQLException e) {
  e.printStackTrace();
}

sc.close();

}
}
