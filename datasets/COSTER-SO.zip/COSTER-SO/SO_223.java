package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_223 {
public void soCodeSnippet(){
if (names == null) return null;

int i=0;

String k[]=new String[names.size()];

while (i < k.length) {
  k[i]=keyAt(i);
  i++;
}

;

return k;

}
}
