package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_323 {
public void soCodeSnippet(){
Calendar curr=new GregorianCalendar();

int currdate=curr.get(Calendar.DAY_OF_MONTH);

int currmon=curr.get(Calendar.MONTH);

int curryear=curr.get(Calendar.YEAR);

int seldate=-1;

int selmon=-1;

int selyear=-1;

if (parent.selectedDate != null) {
  seldate=parent.selectedDate.get(Calendar.DAY_OF_MONTH);
  selmon=parent.selectedDate.get(Calendar.MONTH);
  selyear=parent.selectedDate.get(Calendar.YEAR);
}

int date=c.get(Calendar.DAY_OF_MONTH);

int mon=c.get(Calendar.MONTH);

int year=c.get(Calendar.YEAR);

int day=c.get(Calendar.DAY_OF_WEEK);

int start=(7 - (date - day) % 7) % 7;

int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);

for (int i=0; i < start; i++) {
  JLabel lbl=new JLabel("");
  add(lbl);
}

int pos=start;

for (int i=1; i <= days; i++) {
  pos++;
  DayLabel lbl=new DayLabel(parent,i);
  if (seldate == i && selmon == mon && selyear == year)   lbl.setSelectedDayStyle();
  if (currdate == i && currmon == mon && curryear == year)   lbl.setCurrentDayStyle();
  if (pos % 7 == 0 || pos % 7 == 1)   lbl.setWeekendStyle();
  add(lbl);
}

}
}
