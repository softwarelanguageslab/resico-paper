package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_138 {
public void soCodeSnippet(){
if (names == null) return null;

int i=names.indexOf(key);

if (i < 0) return null;

Object o=elementAt(i);

removeElementAt(i);

names.removeElementAt(i);

return o;

}
}
