package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_88 {
public void soCodeSnippet(){
HttpEntity he=response.getEntity();

html=EntityUtils.toString(he);

Pattern p=Pattern.compile("window.location.replace\\(\"([^<>\"]+)\"\\)");

Matcher m=p.matcher(html);

Pattern p2=Pattern.compile("<a href=\"([^<>]+)\">");

Matcher m2=p2.matcher(html);

String reurl=null;

HttpGet get=null;

if (m.find()) {
  reurl=m.group(1);
  get=new HttpGet(reurl);
  response=client.execute(get);
  getRedirect(response,client);
}

if (m2.find()) {
  reurl=m2.group(1);
  System.out.println(reurl);
  get=new HttpGet(reurl);
  response=client.execute(get);
  getRedirect(response,client);
}

return html;

}
}
