package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_187 {
public void soCodeSnippet(){
File imageConverted=new File(file.getParentFile(),FilenameUtils.getBaseName(file.getName()) + ".gif");

File imageCropped=new File(file.getParentFile(),FilenameUtils.getBaseName(file.getName()) + "-cropped.gif");

transformImages(file,imageConverted,imageCropped);

BASE64Encoder encoder=new BASE64Encoder();

FileInputStream fis=new FileInputStream(imageConverted);

String encodedData=encoder.encode(IOUtils.toByteArray(fis,fis.available()));

fis=new FileInputStream(imageCropped);

String encodedDataThumb=encoder.encode(IOUtils.toByteArray(fis,fis.available()));

String reportText=this.getHumphreyMeasurement(xmlFile,"__OE_PATIENT_ID_" + String.format("%07d",new Integer(fieldReport.getPatientId())) + "__",fieldReport,encodedData,encodedDataThumb);

File f2=new File(this.getLegacyDir(),FilenameUtils.getBaseName(file.getName()) + ".fmes");

f2.createNewFile();

FileUtils.write(f2,reportText);

imageConverted.delete();

imageCropped.delete();

}
}
