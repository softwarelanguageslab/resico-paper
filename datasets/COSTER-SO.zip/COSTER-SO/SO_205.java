package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_205 {
public void soCodeSnippet(){
boolean ch=super.addAll(c);

if (names == null) return ch;

int l=size();

while (names.size() < l) names.add(null);

return ch;

}
}
