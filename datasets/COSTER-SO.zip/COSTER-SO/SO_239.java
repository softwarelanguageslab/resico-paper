package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_239 {
public void soCodeSnippet(){
BufferedReader reader=new BufferedReader(inputReader);

StringBuilder ret=new StringBuilder();

String line;

while ((line=reader.readLine()) != null) {
  ret.append(line);
  ret.append("\n");
}

reader.close();

return ret.toString();

}
}
