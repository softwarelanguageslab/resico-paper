package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_237 {
public void soCodeSnippet(){
Properties props=new Properties();

props.setProperty("mail.store.protocol","pop3");

props.setProperty("mail.pop3.host","pop3.163.com");

Session session=Session.getDefaultInstance(props);

Store store=session.getStore("pop3");

store.connect("lqy3411@163.com","liangqingyu1229");

Folder folder=store.getFolder("INBOX");

folder.open(Folder.READ_WRITE);

int messageCount=folder.getMessageCount();

System.out.println(messageCount);

Message[] messages=folder.getMessages();

for (int i=0; i < messages.length; i++) {
  Message message=messages[i];
  System.out.println("发送时间：" + message.getSentDate());
  System.out.println("主题：" + message.getSubject());
  System.out.println("内容：" + message.getContent());
  Object content=message.getContent();
  if (content instanceof MimeMultipart) {
    MimeMultipart multipart=(MimeMultipart)content;
    parseMultipart(multipart);
  }
  System.out.println("========================================================");
  System.out.println("========================================================");
}

folder.close(true);

store.close();

}
}
