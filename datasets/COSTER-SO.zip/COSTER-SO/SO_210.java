package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_210 {
public void soCodeSnippet(){
List<TestResultData> testResults=resultFile.process();

if (testResults == null || testResults.isEmpty()) {
  log.error("No test results data available");
  return;
}

if (log.isDebugEnabled()) {
  log.debug("List of TestResults data:");
  for (  TestResultData resultData : testResults) {
    log.debug(resultData + "");
  }
}

List<String> testsetNames=new ArrayList<String>();

for (TestResultData testResult : testResults) {
  String testsetName=testResult.getTestSetName();
  if (!testsetNames.contains(testsetName)) {
    testsetNames.add(testsetName);
  }
}

log.info("List of testset names :" + testsetNames);

loadTestInstances(testsetNames);

if (cacheTestInstances.isEmpty()) {
  log.error("No test instances found");
  return;
}

int failedCount=0;

PostResult2Qc postResult2Qc=PostResult2Qc.getInstance();

postResult2Qc.start();

for (TestResultData resultData : testResults) {
  String testName=resultData.getTestName();
  QcTestStatus status=resultData.getTestStatus();
  TestInstanceInfo testInstance=findTestInstance(resultData);
  if (testInstance != null) {
    TestRunInfo testrunInfo=new TestRunInfo();
    testrunInfo.setTestInstanceId(testInstance.getId());
    testrunInfo.setStatus(status);
    testrunInfo.setBugIds(resultData.getBugIds());
    testrunInfo.setUserId(QcConstants.QC_USERID);
    testrunInfo.setBuildNumbers(resultData.getBuildNumbers() == null ? QcConstants.QC_BUILD_NUMBERS : resultData.getBuildNumbers());
    testrunInfo.setCustomFields(resultData.getCustomFields());
    postResult2Qc.addToQueue(testrunInfo);
    log.debug("Testrun info :" + testrunInfo);
  }
 else {
    log.error("Couldn't find test instance id for test name :" + testName);
    failedCount++;
  }
}

postResult2Qc.stop();

for (Boolean status : postResult2Qc.getTestRunsPostedStatus().values()) {
  if (!status) {
    failedCount++;
  }
}

log.info("Total number of valid test result rows :" + testResults.size() + ", Number of test results failed to post into QC :"+ failedCount);

}
}
