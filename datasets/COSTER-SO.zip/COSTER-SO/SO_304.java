package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_304 {
public void soCodeSnippet(){
String uri="/daily/add";

InputStream content=HarvestCore.post(uri,toJson(false,this));

if (content != null) return HarvestCore.mapper.readValue(content,DayEntry.class);

System.out.println("Problems to save ");

return null;

}
}
