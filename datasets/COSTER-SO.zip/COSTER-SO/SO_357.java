package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_357 {
public void soCodeSnippet(){
super(e);

this.errorCode=errorCode;

this.errorSeverity=errorSeverity;

this.placeHolderValues=placeholders;

Logger logger=Logger.getLogger(clz);

logger.error(formatMessage(),e == null ? null : (e.getCause() == null ? e : e.getCause()));

}
}
