package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_20 {
public void soCodeSnippet(){
email.setHostName(SwingObjProps.getSwingObjProperty("emailsmtp"));

email.setAuthenticator(new DefaultAuthenticator(emailDto.getEmailID(),emailDto.getPassword()));

email.setFrom(emailDto.getEmailID(),emailDto.getFromName());

email.setDebug(true);

email.getMailSession().getProperties().put("mail.smtp.starttls.enable","true");

try {
  if (emailDto.getTo().indexOf(",") != -1) {
    String[] splitTo=emailDto.getTo().split(",");
    for (    String emailTo : splitTo) {
      email.addTo(emailTo.trim());
    }
  }
 else {
    email.addTo(emailDto.getTo().trim());
  }
  if (emailDto.getCc() != null) {
    if (emailDto.getCc().indexOf(",") != -1) {
      String[] splitCC=emailDto.getCc().split(",");
      for (      String emailCC : splitCC) {
        email.addCc(emailCC.trim());
      }
    }
 else {
      email.addCc(emailDto.getCc().trim());
    }
  }
}
 catch (EmailException e) {
  throw new SwingObjectException("swingobj.email.checkto",e,ErrorSeverity.ERROR,EmailHelper.class);
}

email.setSubject(emailDto.getSubj() == null ? "" : emailDto.getSubj());

}
}
