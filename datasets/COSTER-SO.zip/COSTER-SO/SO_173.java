package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_173 {
public void soCodeSnippet(){
String projectName=params.getParameter("project");

if (projectName == null) {
  return WebUtil.error("unknown project!");
}

Project project=Global.getInstance().getProject(projectName);

System.out.println("project name fromm params is " + projectName);

if (project == null) {
  return WebUtil.error("can not find project:" + projectName);
}

String action=params.getParameter("action");

if (action == null) {
  return WebUtil.error("unknown action!");
}

FileDatas fileDatas=project.fetchFileDatas();

if ("list".equals(action)) {
  return fileDatas.listFiles();
}
 else if ("upload".equals(action)) {
  return fileDatas.upLoadFile(params);
}
 else if ("md5sum".equals(action)) {
  String fileName=params.getValue("name");
  return fileDatas.buildFileMD5(fileName);
}
 else if ("propsupdate".equals(action)) {
  if (fileDatas.propsFileUpdate()) {
    return fileDatas.listFiles();
  }
}

return null;

}
}
