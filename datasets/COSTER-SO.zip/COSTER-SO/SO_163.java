package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_163 {
public void soCodeSnippet(){
File f=new File(fileName);

if (!(f.exists() && f.canRead())) {
  throw new FileNotFoundException(fileName + " is not found");
}

byte[] data=new byte[(int)f.length()];

InputStream inStream=new FileInputStream(f);

try {
  inStream.read(data);
}
  finally {
  inStream.close();
}

return data;

}
}
