package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_177 {
public void soCodeSnippet(){
final int x1_temp=(int)(x1 + (size / 2)) / size;

final int y1_temp=(int)(y1 + (size / 2)) / size;

final int x2_temp=(int)(x2 + (size / 2)) / size;

final int y2_temp=(int)(y2 + (size / 2)) / size;

ArrayList<Item> tempItems=new ArrayList<>(game.getGameMap().getItemsOnMap());

tempItems.forEach(i -> {
  final int ix=i.getX();
  final int iy=i.getY();
  if (((ix >= x1_temp && ix <= x2_temp) || (ix <= x1_temp && ix >= x2_temp)) && ((iy >= y1_temp && iy <= y2_temp) || (iy <= y1_temp && iy >= y2_temp))) {
    i.processEffect(game,this);
    Arrays.stream(i.getType().getItemActions()).forEach(ii -> game.getItemEffectHandler().registerEffect(ii,this,i.getType().getDuration()));
  }
}
);

if (!carriesGlass) {
  for (int i=0; i < game.getPlayers().size(); i++) {
    if (i != player - 1) {
      int[] other_base_coordinates=game.getGameMap().getPlayerGlassSpawns().get(i);
      if (((other_base_coordinates[0] >= x1_temp && other_base_coordinates[0] <= x2_temp) || (other_base_coordinates[0] <= x1_temp && other_base_coordinates[0] >= x2_temp)) && ((other_base_coordinates[1] >= y1_temp && other_base_coordinates[1] <= y2_temp) || (other_base_coordinates[1] <= y1_temp && other_base_coordinates[1] >= y2_temp))) {
        game.getPlayers().get(i).lostLife();
        carriesGlass=true;
        updatePlayerSprites();
      }
    }
  }
}
 else {
  int[] bread_coordinates=game.getGameMap().getPlayerSpawns().get(player - 1);
  if (((bread_coordinates[0] >= x1_temp && bread_coordinates[0] <= x2_temp) || (bread_coordinates[0] <= x1_temp && bread_coordinates[0] >= x2_temp)) && ((bread_coordinates[1] >= y1_temp && bread_coordinates[1] <= y2_temp) || (bread_coordinates[1] <= y1_temp && bread_coordinates[1] >= y2_temp))) {
    carriesGlass=false;
    updatePlayerSprites();
    for (    Player p : game.getPlayers()) {
      if (p != this && p.lives == 1) {
        game.setPlayerWon(this);
      }
    }
  }
}

}
}
