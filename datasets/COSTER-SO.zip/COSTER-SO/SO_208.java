package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_208 {
public void soCodeSnippet(){
if (!(drawStripes=isOpaque())) {
  super.paintComponent(g);
  return;
}

updateZebraColors();

final java.awt.Insets insets=getInsets();

final int w=getWidth() - insets.left - insets.right;

final int h=getHeight() - insets.top - insets.bottom;

final int x=insets.left;

int y=insets.top;

int rowHeight=16;

final int nItems=getRowCount();

for (int i=0; i < nItems; i++, y+=rowHeight) {
  rowHeight=getRowHeight(i);
  g.setColor(rowColors[i & 1]);
  g.fillRect(x,y,w,rowHeight);
}

final int nRows=nItems + (insets.top + h - y) / rowHeight;

for (int i=nItems; i < nRows; i++, y+=rowHeight) {
  g.setColor(rowColors[i & 1]);
  g.fillRect(x,y,w,rowHeight);
}

final int remainder=insets.top + h - y;

if (remainder > 0) {
  g.setColor(rowColors[nRows & 1]);
  g.fillRect(x,y,w,remainder);
}

setOpaque(false);

super.paintComponent(g);

setOpaque(true);

}
}
