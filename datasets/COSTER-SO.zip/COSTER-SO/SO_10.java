package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_10 {
public void soCodeSnippet(){
if ((rowColors[0]=getBackground()) == null) {
  rowColors[0]=rowColors[1]=java.awt.Color.white;
  return;
}

final java.awt.Color sel=getSelectionBackground();

if (sel == null) {
  rowColors[1]=rowColors[0];
  return;
}

final float[] bgHSB=java.awt.Color.RGBtoHSB(rowColors[0].getRed(),rowColors[0].getGreen(),rowColors[0].getBlue(),null);

final float[] selHSB=java.awt.Color.RGBtoHSB(sel.getRed(),sel.getGreen(),sel.getBlue(),null);

rowColors[1]=java.awt.Color.getHSBColor((selHSB[1] == 0.0 || selHSB[2] == 0.0) ? bgHSB[0] : selHSB[0],0.1f * selHSB[1] + 0.9f * bgHSB[1],bgHSB[2] + ((bgHSB[2] < 0.5f) ? 0.05f : -0.05f));

}
}
