package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_215 {
public void soCodeSnippet(){
Book book=new Book("Harry Potter",1995,true,"J.K. Rowling");

bookList.add(book);

when(reader.readLine()).thenReturn("Harry Potter");

library.checkOutItem(bookList);

verify(printStream).println("That item is not available.");

}
}
