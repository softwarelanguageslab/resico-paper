package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_318 {
public void soCodeSnippet(){
if (cont != null) {
  if (offset >= cont.length) {
    cont=null;
    len=0;
  }
 else   if (len > cont.length - offset)   len=cont.length - offset;
}

if (offset < 0) offset=0;

if (len < 0) len=0;

int contlen=(cont == null) ? 0 : len;

if (prefix != null && prefix.length > 0) contlen+=prefix.length;

byte[] hdr=new byte[16];

setInt(cmd,hdr,0);

setInt(contlen,hdr,4);

for (int i=8; i < 16; i++) hdr[i]=0;

try {
  if (cmd != -1) {
    os.write(hdr);
    if (prefix != null && prefix.length > 0)     os.write(prefix);
    if (cont != null && cont.length > 0)     os.write(cont,offset,len);
  }
  byte[] ih=new byte[16];
  if (is.read(ih) != 16)   return null;
  int rep=getInt(ih,0);
  int rl=getInt(ih,4);
  if (rl > 0) {
    byte[] ct=new byte[rl];
    int n=0;
    while (n < rl) {
      int rd=is.read(ct,n,rl - n);
      n+=rd;
    }
    return new Rpacket(rep,ct);
  }
  return new Rpacket(rep,null);
}
 catch (Exception e) {
  return null;
}

}
}
