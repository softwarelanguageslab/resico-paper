package fold2;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_71 {
public void soCodeSnippet(){
Set<String> foundNames=new HashSet<>();

JsonElement json=getAndParseJson(FIRST_NAME_BASE_URL,name);

for (DocNavigator navigator : firstNameNavigators) {
  foundNames.addAll(navigator.navigate(json));
}

foundNames.add(name);

Set<String> ret=new HashSet<>();

for (String found : foundNames) {
  ret.add(format(found));
}

return ret;

}
}
