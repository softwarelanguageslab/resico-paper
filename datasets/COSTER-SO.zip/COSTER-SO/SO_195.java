package fold4;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_195 {
public void soCodeSnippet(){
Command command=mock(Command.class);

commands.put("test",command);

when(reader.readLine()).thenReturn("test");

String userCommand=commandMenu.promptUser();

commandMenu.executeCommand(userCommand);

verify(command).execute();

}
}
