package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_401 {
public void soCodeSnippet(){
records=new ArrayList<Record>();

records.add(new BibliographicRecord("Harry Potter and the Deathly Hallows","","J.K Rowling","Book"));

records.add(new BibliographicRecord("Harry Potter and the Half-Blood Price","","J.K Rowling","Book"));

records.add(new BibliographicRecord("The Twilight Saga","Breaking Dawn Part 1","","DVD"));

records.add(new BibliographicRecord("The Twilight Saga","Breaking Dawn Part 2","","DVD"));

records.add(new BibliographicRecord("Last to Die","A Novel","Gerritsen, Tess","Book"));

records.add(new BibliographicRecord("Rocket Writes A Story","","Hills, Tad","eBook"));

}
}
