package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_132 {
public void soCodeSnippet(){
assertEquals(0,boundedTS.size());

int i;

int lastNumber=bounds * 2;

for (i=0; i <= lastNumber; i++) {
  boundedTS.append(i);
}

assertEquals(new Integer(lastNumber),boundedTS.getPoints().get(bounds - 1).getValue());

}
}
