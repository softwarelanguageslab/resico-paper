package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_245 {
public void soCodeSnippet(){
InventoryController controller=new InventoryController();

SimpleProductManager spm=new SimpleProductManager();

spm.setProductDao(new InMemoryProductDao(new ArrayList<Product>()));

controller.setProductManager(spm);

ModelAndView modelAndView=controller.handleRequest(null,null);

assertEquals("hello",modelAndView.getViewName());

assertNotNull(modelAndView.getModel());

Map modelMap=(Map)modelAndView.getModel().get("model");

String nowValue=(String)modelMap.get("now");

assertNotNull(nowValue);

}
}
