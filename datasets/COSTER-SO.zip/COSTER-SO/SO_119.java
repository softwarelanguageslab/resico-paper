package fold3;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_119 {
public void soCodeSnippet(){
List<String> list=new ArrayList<String>();

String url=view.getUrlText();

list.add(url);

TaskManager.getInstance().addUri(list);

view.setVisible(false);

}
}
