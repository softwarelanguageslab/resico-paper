package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_446 {
public void soCodeSnippet(){
finalizeUrl();

ConnectionStatistics.connecting(url);

URLConnection conn=url.openConnection();

setRequestMethod(conn);

addRequestHeaders(conn);

return conn;

}
}
