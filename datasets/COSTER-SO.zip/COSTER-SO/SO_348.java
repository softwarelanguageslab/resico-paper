package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_348 {
public void soCodeSnippet(){
if (!targetDirectory.exists()) throw new FileNotFoundException(targetDirectory.getAbsolutePath() + " does not exist.");

if (!targetDirectory.isDirectory()) throw new IllegalArgumentException(targetDirectory.getAbsolutePath() + " is not a directory");

Collection<File> existingLevelFiles=FileUtils.listFiles(targetDirectory,new String[]{TPBJGConfig.LEVEL_FILE_EXTENSION},false);

File targetFile=new File(targetDirectory.getAbsoluteFile() + File.separator + String.format("%03d",existingLevelFiles.size())+ "."+ TPBJGConfig.LEVEL_FILE_EXTENSION);

try (BufferedOutputStream out=new BufferedOutputStream(new FileOutputStream(targetFile),8192)){
  JAXBContext context=JAXBContext.newInstance(XMLGameMapDTO.class);
  Marshaller marshaller=context.createMarshaller();
  marshaller.marshal(new XMLGameMapDTO(map),out);
}
 catch (JAXBException|IOException e) {
  System.err.println(e.getMessage() + ": Could not save File: " + targetFile.getAbsolutePath());
  throw new RuntimeException("Error marshalling object to file: " + targetFile.getAbsolutePath(),e);
}

}
}
