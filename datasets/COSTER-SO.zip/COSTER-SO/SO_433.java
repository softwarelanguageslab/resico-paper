package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_433 {
public void soCodeSnippet(){
final int prime=31;

int result=1;

result=prime * result + ((cbCombo == null) ? 0 : cbCombo.hashCode());

result=prime * result + (chkBx ? 1231 : 1237);

result=prime * result + ((tftest == null) ? 0 : tftest.hashCode());

result=prime * result + ((tftest1 == null) ? 0 : tftest1.hashCode());

return result;

}
}
