package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_207 {
public void soCodeSnippet(){
DefaultHttpClient http=new DefaultHttpClient();

int result=-1;

String strURL="http://" + host + ":"+ port+ "/api/"+ resourceType+ "?resource_type=Patient&_format=xml";

if (requestParams != null) {
  strURL+="&" + requestParams;
}

HttpGet get=new HttpGet(strURL);

UsernamePasswordCredentials creds=new UsernamePasswordCredentials(username,password);

get.addHeader(BasicScheme.authenticate(creds,"US-ASCII",false));

try {
  get.addHeader("Content-type","text/xml");
  HttpClientBuilder builder=HttpClientBuilder.create();
  CloseableHttpClient httpclient=builder.build();
  CloseableHttpResponse httpResponse=httpclient.execute(get);
  result=httpResponse.getStatusLine().getStatusCode();
  HttpEntity entity2=httpResponse.getEntity();
  StringWriter writer=new StringWriter();
  IOUtils.copy(entity2.getContent(),writer);
  this.response=writer.toString();
  EntityUtils.consume(entity2);
}
 catch (ConnectException e) {
  e.printStackTrace();
  throw e;
}
catch (IOException e) {
  e.printStackTrace();
}
 finally {
  get.releaseConnection();
}

return result;

}
}
