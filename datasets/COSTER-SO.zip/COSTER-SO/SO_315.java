package fold7;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_315 {
public void soCodeSnippet(){
PersonnageService p=new PersonnageContract(new PersonnageImpl());

p.init("totoro",501,445,255,20,9950,10,20,65);

System.err.println(p.estVaincu());

p.retrait(999999);

System.err.println(p.estVaincu());

}
}
