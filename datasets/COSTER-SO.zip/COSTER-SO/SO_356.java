package fold8;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_356 {
public void soCodeSnippet(){
Color c=_myColor;

StringBuilder sb=new StringBuilder();

sb.append("#");

sb.append(Integer.toHexString(_myColor.getRed()));

sb.append(Integer.toHexString(_myColor.getGreen()));

sb.append(Integer.toHexString(_myColor.getBlue()));

return sb.toString();

}
}
