package fold5;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_242 {
public void soCodeSnippet(){
List<PersonnageService> goodguys=new ArrayList<PersonnageService>();

goodguys.add(ryan());

goodguys.add(alex());

List<PersonnageService> attackers=new ArrayList<PersonnageService>();

for (PersonnageService p : goodguys) {
  int px=p.getX();
  int py=p.getY();
  int pz=p.getZ();
  if ((Math.abs(g.getX() - px) <= 1) && (Math.abs(g.getY() - py) <= 1) && (Math.abs(g.getZ() - pz) <= 1)) {
    attackers.add(p);
  }
}

return attackers;

}
}
