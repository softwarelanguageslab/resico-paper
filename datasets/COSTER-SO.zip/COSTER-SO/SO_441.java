package fold9;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_441 {
public void soCodeSnippet(){
boolean ch=super.addAll(index,c);

if (names == null) return ch;

int l=c.size();

while (l > 0) names.add(index,null);

return ch;

}
}
