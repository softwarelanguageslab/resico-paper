package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_3 {
public void soCodeSnippet(){
PersonnageService[] goodguys={ryan(),alex()};

List<GangsterService> badguys=new ArrayList<GangsterService>(gangster());

badguys.add(slick());

for (PersonnageService p : goodguys) {
  List<GangsterService> g2=collisionPerso(p);
  if (g2.isEmpty()) {
    continue;
  }
  for (  GangsterService g : g2) {
    if (!((Math.abs(p.getX() - g.getX()) <= 1) && (Math.abs(p.getY() - g.getY()) <= 1) && (Math.abs(p.getZ() - g.getZ()) <= 1))) {
      throw new InvariantError("collisionPerso");
    }
  }
}

for (GangsterService g : badguys) {
  List<PersonnageService> p2=collisionGangster(g);
  if (p2.isEmpty()) {
    continue;
  }
  for (  PersonnageService p : p2) {
    if (!((Math.abs(g.getX() - p.getX()) <= 1) && (Math.abs(g.getY() - p.getY()) <= 1) && (Math.abs(g.getZ() - p.getZ()) <= 1))) {
      throw new InvariantError("collisionGangster");
    }
  }
}

}
}
