package fold1;
import org.apache.commons.*;
import org.apache.http.client.*;
import com.google.*;
import org.springframework.boot.*;
import org.apache.log4j.*;
import junit.*;

public class SO_36 {
public void soCodeSnippet(){
System.out.println("1. Parodyti visus pilotus");

System.out.println("2. Parodyti visus naikintuvus");

System.out.println("3. Ieskoti naikintuvo pagal jo modeli");

System.out.println("4. Atnaujinti piloto pilotuojama naikintuva");

System.out.println("5. Nusamdyti nauja pilota");

System.out.println("6. Atleisti esanti pilota");

}
}
